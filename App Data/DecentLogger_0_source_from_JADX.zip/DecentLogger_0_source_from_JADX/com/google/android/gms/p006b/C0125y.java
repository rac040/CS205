package com.google.android.gms.p006b;

import android.os.Binder;

public abstract class C0125y {
    private static final Object f614c = new Object();
    private static ac f615d = null;
    private static int f616e = 0;
    private static String f617f = "com.google.android.providers.gsf.permission.READ_GSERVICES";
    protected final String f618a;
    protected final Object f619b;
    private Object f620g = null;

    protected C0125y(String str, Object obj) {
        this.f618a = str;
        this.f619b = obj;
    }

    public static C0125y m738a(String str, Integer num) {
        return new aa(str, num);
    }

    public static C0125y m739a(String str, Long l) {
        return new C0161z(str, l);
    }

    public static C0125y m740a(String str, String str2) {
        return new ab(str, str2);
    }

    protected abstract Object mo172a();

    public final Object m742b() {
        Object a;
        long clearCallingIdentity;
        try {
            a = mo172a();
        } catch (SecurityException e) {
            clearCallingIdentity = Binder.clearCallingIdentity();
            a = mo172a();
        } finally {
            Binder.restoreCallingIdentity(clearCallingIdentity);
        }
        return a;
    }
}
