package com.google.android.gms.p006b;

import android.support.v4.p002c.C0035a;
import com.google.android.gms.common.api.C0129j;
import com.google.android.gms.common.api.C0172h;
import java.util.Collections;
import java.util.Map;
import java.util.Set;
import java.util.WeakHashMap;

public final class C0158u {
    static final C0140f[] f701a = new C0140f[0];
    final Set f702b = Collections.synchronizedSet(Collections.newSetFromMap(new WeakHashMap()));
    final C0159w f703c = new C0160v(this);
    C0153x f704d = null;
    private final Map f705e = new C0035a();

    public C0158u(C0172h c0172h, C0129j c0129j) {
        this.f705e.put(c0172h, c0129j);
    }
}
