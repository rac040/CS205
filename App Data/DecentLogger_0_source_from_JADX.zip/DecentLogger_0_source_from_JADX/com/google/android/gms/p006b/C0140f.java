package com.google.android.gms.p006b;

import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.internal.C0200d;
import java.util.concurrent.atomic.AtomicReference;

public abstract class C0140f extends C0137h {
    private AtomicReference f661d;

    public static void m780a() {
    }

    public final void m781a(C0159w c0159w) {
        this.f661d.set(c0159w);
    }

    public final void m782b(Status status) {
        boolean z = true;
        if (status.f754i <= 0) {
            z = false;
        }
        C0200d.m1043b(z, "Failed result must not be success");
        m772a(mo183a(status));
    }
}
