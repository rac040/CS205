package com.google.android.gms.p006b;

final class C0161z extends C0125y {
    C0161z(String str, Long l) {
        super(str, l);
    }

    protected final /* synthetic */ Object mo172a() {
        ac acVar = null;
        return acVar.m745a();
    }
}
