package com.google.android.gms.p006b;

import android.content.Context;

public final class ae {
    private static ae f622b = new ae();
    private ad f623a = null;

    public static ad m751a(Context context) {
        return f622b.m752b(context);
    }

    private synchronized ad m752b(Context context) {
        if (this.f623a == null) {
            if (context.getApplicationContext() != null) {
                context = context.getApplicationContext();
            }
            this.f623a = new ad(context);
        }
        return this.f623a;
    }
}
