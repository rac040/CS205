package com.google.android.gms.p006b;

import android.util.SparseArray;
import com.google.android.gms.common.api.Status;

public final class C0134b extends C0124a {
    public final C0140f f642c;

    public final void mo179a() {
        C0140f.m780a();
    }

    public final void mo180a(SparseArray sparseArray) {
        C0158u c0158u = (C0158u) sparseArray.get(this.a);
        if (c0158u != null) {
            C0140f c0140f = this.f642c;
            c0158u.f702b.add(c0140f);
            c0140f.m781a(c0158u.f703c);
        }
    }

    public final void mo181a(Status status) {
        this.f642c.m782b(status);
    }

    public final boolean mo182b() {
        return this.f642c.m776d();
    }
}
