package com.google.android.gms.p006b;

import android.content.Context;
import android.os.Looper;
import com.google.android.gms.common.api.C0127f;
import com.google.android.gms.common.api.C0129j;
import com.google.android.gms.common.api.C0150q;
import com.google.android.gms.common.api.C0151r;
import com.google.android.gms.common.internal.C0217v;
import com.google.android.gms.signin.internal.C0254j;

final class al extends C0127f {
    al() {
    }

    public final /* synthetic */ C0129j mo178a(Context context, Looper looper, C0217v c0217v, Object obj, C0150q c0150q, C0151r c0151r) {
        return new C0254j(context, looper, false, c0217v, null, c0150q, c0151r);
    }
}
