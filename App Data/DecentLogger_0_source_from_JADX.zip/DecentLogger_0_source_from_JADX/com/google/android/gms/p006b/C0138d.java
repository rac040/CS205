package com.google.android.gms.p006b;

import android.support.v4.p002c.C0035a;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.C0170u;
import com.google.android.gms.common.api.C0181x;
import com.google.android.gms.common.api.C0182w;
import com.google.android.gms.common.api.Status;

public final class C0138d extends C0137h {
    private int f659d;
    private boolean f660e;

    private C0181x m777b(Status status) {
        C0181x c0182w;
        synchronized (null) {
            try {
                C0035a c0035a;
                ConnectionResult connectionResult = new ConnectionResult(8);
                int i = 0;
                while (true) {
                    c0035a = null;
                    if (i >= c0035a.size()) {
                        break;
                    }
                    c0035a = null;
                    m779a((C0135c) c0035a.m305b(i), connectionResult);
                    i++;
                }
                c0035a = null;
                c0182w = c0035a.size() == 1 ? new C0182w(status) : new C0181x(status);
            } catch (Throwable th) {
            }
        }
        return c0182w;
    }

    protected final /* synthetic */ C0170u mo183a(Status status) {
        return m777b(status);
    }

    public final void m779a(C0135c c0135c, ConnectionResult connectionResult) {
        synchronized (null) {
            C0035a c0035a = null;
            try {
                c0035a.put(c0135c, connectionResult);
                this.f659d--;
                boolean b = connectionResult.m829b();
                if (!b) {
                    this.f660e = b;
                }
                if (this.f659d == 0) {
                    Status status = this.f660e ? new Status(13) : Status.f746a;
                    c0035a = null;
                    m772a(c0035a.size() == 1 ? new C0182w(status) : new C0181x(status));
                }
            } finally {
            }
        }
    }
}
