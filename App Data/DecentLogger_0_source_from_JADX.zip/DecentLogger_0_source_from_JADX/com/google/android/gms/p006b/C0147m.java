package com.google.android.gms.p006b;

import android.content.Context;
import android.os.Handler;
import android.os.Handler.Callback;
import android.os.Message;
import android.support.v4.p002c.C0035a;
import android.util.Log;
import android.util.SparseArray;
import com.google.android.gms.common.C0186b;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.C0171a;
import com.google.android.gms.common.api.C0183y;
import com.google.android.gms.common.api.Status;
import java.lang.ref.ReferenceQueue;
import java.util.Map;
import java.util.Set;

public final class C0147m implements Callback {
    private static final Object f666d = new Object();
    private static C0147m f667e;
    private long f668a;
    private long f669b;
    private long f670c;
    private final Context f671f;
    private final C0186b f672g;
    private int f673h;
    private final SparseArray f674i;
    private final Map f675j;
    private final Set f676k;
    private final Handler f677l;
    private final ReferenceQueue f678m;
    private final SparseArray f679n;
    private C0149o f680o;

    public static C0147m m789a() {
        C0147m c0147m;
        synchronized (f666d) {
            c0147m = f667e;
        }
        return c0147m;
    }

    private void m790a(int i, boolean z) {
        C0152p c0152p = (C0152p) this.f674i.get(i);
        if (c0152p != null) {
            if (!z) {
                this.f674i.delete(i);
            }
            c0152p.m813a(i, z);
            return;
        }
        Log.wtf("GoogleApiManager", "onRelease received for unknown instance: " + i, new Exception());
    }

    private void m797e() {
        for (C0152p c0152p : this.f675j.values()) {
            c0152p.f692g = null;
            c0152p.m821f();
        }
    }

    final boolean m803a(ConnectionResult connectionResult, int i) {
        if (!connectionResult.m828a() && !this.f672g.mo196a(connectionResult.f709c)) {
            return false;
        }
        this.f672g.m856a(this.f671f, connectionResult, i);
        return true;
    }

    public final void m804b() {
        this.f677l.sendMessage(this.f677l.obtainMessage(3));
    }

    public final void m805b(ConnectionResult connectionResult, int i) {
        if (!m803a(connectionResult, i)) {
            this.f677l.sendMessage(this.f677l.obtainMessage(5, i, 0));
        }
    }

    public final boolean handleMessage(Message message) {
        boolean z = false;
        C0135c c0135c;
        int i;
        C0152p c0152p;
        C0152p c0152p2;
        switch (message.what) {
            case 1:
                C0138d c0138d = (C0138d) message.obj;
                C0035a c0035a = null;
                for (C0135c c0135c2 : c0035a.keySet()) {
                    C0152p c0152p3 = (C0152p) this.f675j.get(c0135c2);
                    if (c0152p3 == null) {
                        c0138d.m774c();
                        break;
                    } else if (c0152p3.f687b.m760b()) {
                        c0138d.m779a(c0135c2, ConnectionResult.f707a);
                    } else if (c0152p3.f692g != null) {
                        c0138d.m779a(c0135c2, c0152p3.f692g);
                    } else {
                        c0152p3.f690e.add(c0138d);
                    }
                }
                break;
            case 2:
                i = message.arg1;
                c0152p = (C0152p) this.f674i.get(i);
                if (c0152p == null) {
                    Log.wtf("GoogleApiManager", "onCleanupLeakInternal received for unknown instance: " + i, new Exception());
                    break;
                }
                this.f674i.delete(i);
                C0158u c0158u = (C0158u) c0152p.f689d.get(i);
                C0153x c0154q = new C0154q(c0152p, i);
                if (c0158u.f702b.isEmpty()) {
                    c0154q.mo189a();
                }
                c0158u.f704d = c0154q;
                break;
            case 3:
                m797e();
                break;
            case 4:
                C0124a c0124a = (C0124a) message.obj;
                c0152p2 = (C0152p) this.f674i.get(c0124a.f612a);
                if (!c0152p2.f687b.m760b()) {
                    c0152p2.f686a.add(c0124a);
                    if (c0152p2.f692g != null && c0152p2.f692g.m828a()) {
                        c0152p2.mo187a(c0152p2.f692g);
                        break;
                    }
                    c0152p2.m821f();
                    break;
                }
                c0152p2.m814a(c0124a);
                c0152p2.m819d();
                break;
                break;
            case 5:
                if (this.f674i.get(message.arg1) != null) {
                    ((C0152p) this.f674i.get(message.arg1)).m816a(new Status(17, "Error resolution was canceled by the user."));
                    break;
                }
                break;
            case 6:
                C0183y c0183y = (C0183y) message.obj;
                i = message.arg1;
                c0135c2 = c0183y.f785d;
                if (!this.f675j.containsKey(c0135c2)) {
                    this.f675j.put(c0135c2, new C0152p(this, c0183y));
                }
                c0152p2 = (C0152p) this.f675j.get(c0135c2);
                SparseArray sparseArray = c0152p2.f689d;
                C0171a c0171a = c0152p2.f688c.f643a;
                if (c0171a.f758b != null) {
                    sparseArray.put(i, new C0158u(c0171a.f758b, c0152p2.f687b));
                    this.f674i.put(i, c0152p2);
                    c0152p2.m821f();
                    this.f679n.put(i, new C0148n(this, c0183y, i, this.f678m));
                    if (this.f680o == null || !this.f680o.f685c.get()) {
                        this.f680o = new C0149o(this.f678m, this.f679n);
                        this.f680o.start();
                        break;
                    }
                }
                throw new IllegalStateException("This API was constructed with null client keys. This should not be possible.");
            case 7:
                int i2 = message.arg1;
                if (message.arg2 == 1) {
                    z = true;
                }
                m790a(i2, z);
                break;
            case 8:
                if (this.f675j.containsKey(message.obj)) {
                    c0152p = (C0152p) this.f675j.get(message.obj);
                    if (c0152p.f691f) {
                        c0152p.m821f();
                        break;
                    }
                }
                break;
            case 9:
                if (this.f675j.containsKey(message.obj)) {
                    c0152p = (C0152p) this.f675j.get(message.obj);
                    if (c0152p.f691f) {
                        c0152p.m818c();
                        c0152p.m816a(c0152p.f693h.f672g.mo192a(c0152p.f693h.f671f) == 18 ? new Status(8, "Connection timed out while waiting for Google Play services update to complete.") : new Status(8, "API failed to connect while resuming due to an unknown error."));
                        c0152p.f687b.m757a();
                        break;
                    }
                }
                break;
            case 10:
                if (this.f675j.containsKey(message.obj)) {
                    ((C0152p) this.f675j.get(message.obj)).m820e();
                    break;
                }
                break;
            default:
                Log.w("GoogleApiManager", "Unknown message id: " + message.what);
                return false;
        }
        return true;
    }
}
