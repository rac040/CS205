package com.google.android.gms.p006b;

import android.util.SparseArray;
import com.google.android.gms.common.api.Status;

public abstract class C0124a {
    public final int f612a;
    public final int f613b;

    public abstract void mo179a();

    public void mo180a(SparseArray sparseArray) {
    }

    public abstract void mo181a(Status status);

    public boolean mo182b() {
        return true;
    }
}
