package com.google.android.gms.p006b;

final class ab extends C0125y {
    ab(String str, String str2) {
        super(str, str2);
    }

    protected final /* synthetic */ Object mo172a() {
        ac acVar = null;
        return acVar.m747c();
    }
}
