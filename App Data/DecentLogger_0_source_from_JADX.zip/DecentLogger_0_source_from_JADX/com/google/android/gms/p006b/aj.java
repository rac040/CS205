package com.google.android.gms.p006b;

import com.google.android.gms.common.api.C0127f;
import com.google.android.gms.common.api.C0171a;
import com.google.android.gms.common.api.C0173k;
import com.google.android.gms.common.api.Scope;

public final class aj {
    public static final C0173k f625a = new C0173k();
    public static final C0173k f626b = new C0173k();
    public static final C0127f f627c = new ak();
    static final C0127f f628d = new al();
    public static final Scope f629e = new Scope("profile");
    public static final Scope f630f = new Scope("email");
    public static final C0171a f631g = new C0171a("SignIn.API", f627c, f625a);
    public static final C0171a f632h = new C0171a("SignIn.INTERNAL_API", f628d, f626b);
}
