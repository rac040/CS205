package com.google.android.gms.p006b;

import com.google.android.gms.common.api.C0129j;

public interface am extends C0129j {
}
