package com.google.android.gms.p006b;

interface C0153x {
    void mo189a();
}
