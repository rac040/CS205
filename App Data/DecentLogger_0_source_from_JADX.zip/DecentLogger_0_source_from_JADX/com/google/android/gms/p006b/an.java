package com.google.android.gms.p006b;

import com.google.android.gms.common.api.C0133e;

public final class an implements C0133e {
    public static final an f633a = new an();
    public final boolean f634b;
    public final boolean f635c;
    public final String f636d;
    public final boolean f637e;
    public final String f638f;
    public final boolean f639g;
    public final Long f640h;
    public final Long f641i;

    static {
        ao aoVar = new ao();
    }

    private an() {
        this.f634b = false;
        this.f635c = false;
        this.f636d = null;
        this.f637e = false;
        this.f639g = false;
        this.f638f = null;
        this.f640h = null;
        this.f641i = null;
    }
}
