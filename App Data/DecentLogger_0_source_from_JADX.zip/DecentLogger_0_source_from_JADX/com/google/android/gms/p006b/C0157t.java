package com.google.android.gms.p006b;

public interface C0157t {
    Object m826a();
}
