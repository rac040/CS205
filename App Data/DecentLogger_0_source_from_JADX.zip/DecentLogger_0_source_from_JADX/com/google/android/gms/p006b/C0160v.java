package com.google.android.gms.p006b;

final class C0160v implements C0159w {
    final /* synthetic */ C0158u f706a;

    C0160v(C0158u c0158u) {
        this.f706a = c0158u;
    }
}
