package com.google.android.gms.p006b;

import com.google.android.gms.common.ConnectionResult;

public final class C0146l extends C0142g {
    protected final void mo184a() {
        C0147m c0147m = null;
        c0147m.m804b();
    }

    protected final void mo185a(ConnectionResult connectionResult, int i) {
        C0147m c0147m = null;
        c0147m.m805b(connectionResult, i);
    }
}
