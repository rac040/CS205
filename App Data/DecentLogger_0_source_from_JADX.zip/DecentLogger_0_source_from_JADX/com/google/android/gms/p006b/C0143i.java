package com.google.android.gms.p006b;

final class C0143i extends ThreadLocal {
    C0143i() {
    }

    protected final /* synthetic */ Object initialValue() {
        return Boolean.valueOf(false);
    }
}
