package com.google.android.gms.p006b;

import com.google.android.gms.common.api.C0183y;
import java.lang.ref.PhantomReference;
import java.lang.ref.ReferenceQueue;

final class C0148n extends PhantomReference {
    final int f681a;
    final /* synthetic */ C0147m f682b;

    public C0148n(C0147m c0147m, C0183y c0183y, int i, ReferenceQueue referenceQueue) {
        this.f682b = c0147m;
        super(c0183y, referenceQueue);
        this.f681a = i;
    }
}
