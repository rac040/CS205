package com.google.android.gms.p006b;

final class C0145k {
    final /* synthetic */ C0137h f665a;

    private C0145k(C0137h c0137h) {
        this.f665a = c0137h;
    }

    protected final void finalize() {
        C0137h.m768b(this.f665a.f652h);
        super.finalize();
    }
}
