package com.google.android.gms.p006b;

final class C0154q implements C0153x {
    final /* synthetic */ int f696a;
    final /* synthetic */ C0152p f697b;

    C0154q(C0152p c0152p, int i) {
        this.f697b = c0152p;
        this.f696a = i;
    }

    public final void mo189a() {
        if (this.f697b.f686a.isEmpty()) {
            this.f697b.m813a(this.f696a, false);
        }
    }
}
