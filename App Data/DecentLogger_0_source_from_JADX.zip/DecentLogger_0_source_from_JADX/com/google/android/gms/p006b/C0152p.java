package com.google.android.gms.p006b;

import android.content.Context;
import android.os.DeadObjectException;
import android.os.Looper;
import android.os.Message;
import android.support.v4.p002c.C0035a;
import android.util.Log;
import android.util.SparseArray;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.C0127f;
import com.google.android.gms.common.api.C0128g;
import com.google.android.gms.common.api.C0129j;
import com.google.android.gms.common.api.C0150q;
import com.google.android.gms.common.api.C0151r;
import com.google.android.gms.common.api.C0171a;
import com.google.android.gms.common.api.C0178p;
import com.google.android.gms.common.api.C0183y;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.internal.C0200d;
import com.google.android.gms.common.internal.C0203g;
import com.google.android.gms.common.internal.C0217v;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Map;
import java.util.Queue;
import java.util.Set;

final class C0152p implements C0150q, C0151r {
    final Queue f686a = new LinkedList();
    final C0129j f687b;
    final C0135c f688c;
    final SparseArray f689d = new SparseArray();
    final Set f690e = new HashSet();
    boolean f691f;
    ConnectionResult f692g = null;
    final /* synthetic */ C0147m f693h;
    private final C0128g f694i;
    private final SparseArray f695j = new SparseArray();

    public C0152p(C0147m c0147m, C0183y c0183y) {
        this.f693h = c0147m;
        C0171a c0171a = c0183y.f783b;
        C0200d.m1042a(c0171a.f757a != null, (Object) "This API was constructed with a SimpleClientBuilder. Use getSimpleClientBuilder");
        C0127f c0127f = c0171a.f757a;
        Context context = c0183y.f782a;
        Looper looper = this.f693h.f677l.getLooper();
        C0178p c0178p = new C0178p(c0183y.f782a);
        an anVar = an.f633a;
        if (c0178p.f770h.containsKey(aj.f631g)) {
            anVar = (an) c0178p.f770h.get(aj.f631g);
        }
        this.f687b = c0127f.mo178a(context, looper, new C0217v(c0178p.f763a, c0178p.f764b, c0178p.f769g, c0178p.f765c, c0178p.f766d, c0178p.f767e, c0178p.f768f, anVar), c0183y.f784c, this, this);
        if (this.f687b instanceof C0203g) {
            this.f694i = ((C0203g) this.f687b).f893a;
        } else {
            this.f694i = this.f687b;
        }
        this.f688c = c0183y.f785d;
    }

    private void m811b(ConnectionResult connectionResult) {
        for (C0138d a : this.f690e) {
            a.m779a(this.f688c, connectionResult);
        }
        this.f690e.clear();
    }

    public final void mo186a() {
        this.f692g = null;
        m811b(ConnectionResult.f707a);
        m818c();
        for (int i = 0; i < this.f695j.size(); i++) {
            Iterator it = ((Map) this.f695j.get(this.f695j.keyAt(i))).values().iterator();
            while (it.hasNext()) {
                it.next();
                try {
                    C0140f.m780a();
                } catch (DeadObjectException e) {
                    this.f687b.m757a();
                    mo188b();
                }
            }
        }
        while (this.f687b.m760b() && !this.f686a.isEmpty()) {
            m814a((C0124a) this.f686a.remove());
        }
        m819d();
    }

    public final void m813a(int i, boolean z) {
        Iterator it = this.f686a.iterator();
        while (it.hasNext()) {
            C0124a c0124a = (C0124a) it.next();
            if (c0124a.f612a == i && c0124a.f613b != 1 && c0124a.mo182b()) {
                it.remove();
            }
        }
        C0158u c0158u = (C0158u) this.f689d.get(i);
        for (C0140f c0140f : (C0140f[]) c0158u.f702b.toArray(C0158u.f701a)) {
            c0140f.m781a(null);
            if (c0140f.m776d()) {
                c0158u.f702b.remove(c0140f);
            }
        }
        this.f695j.delete(i);
        if (!z) {
            this.f689d.remove(i);
            this.f693h.f679n.remove(i);
            if (this.f689d.size() == 0 && this.f686a.isEmpty()) {
                m818c();
                this.f687b.m757a();
                this.f693h.f675j.remove(this.f688c);
                synchronized (C0147m.f666d) {
                    this.f693h.f676k.remove(this.f688c);
                }
            }
        }
    }

    final void m814a(C0124a c0124a) {
        c0124a.mo180a(this.f689d);
        Map map;
        if (c0124a.f613b == 3) {
            try {
                Map map2;
                map = (Map) this.f695j.get(c0124a.f612a);
                if (map == null) {
                    C0035a c0035a = new C0035a((byte) 0);
                    this.f695j.put(c0124a.f612a, c0035a);
                    map2 = c0035a;
                } else {
                    map2 = map;
                }
                C0140f c0140f = ((C0134b) c0124a).f642c;
                map2.put(((C0157t) c0140f).m826a(), c0140f);
            } catch (ClassCastException e) {
                throw new IllegalStateException("Listener registration methods must implement ListenerApiMethod");
            }
        } else if (c0124a.f613b == 4) {
            try {
                map = (Map) this.f695j.get(c0124a.f612a);
                C0157t c0157t = (C0157t) ((C0134b) c0124a).f642c;
                if (map != null) {
                    map.remove(c0157t.m826a());
                } else {
                    Log.w("GoogleApiManager", "Received call to unregister a listener without a matching registration call.");
                }
            } catch (ClassCastException e2) {
                throw new IllegalStateException("Listener unregistration methods must implement ListenerApiMethod");
            }
        }
        try {
            c0124a.mo179a();
        } catch (DeadObjectException e3) {
            this.f687b.m757a();
            mo188b();
        }
    }

    public final void mo187a(ConnectionResult connectionResult) {
        this.f692g = null;
        this.f693h.f673h = -1;
        m811b(connectionResult);
        int keyAt = this.f689d.keyAt(0);
        if (this.f686a.isEmpty()) {
            this.f692g = connectionResult;
            return;
        }
        synchronized (C0147m.f666d) {
            null;
        }
        if (!this.f693h.m803a(connectionResult, keyAt)) {
            if (connectionResult.f709c == 18) {
                this.f691f = true;
            }
            if (this.f691f) {
                this.f693h.f677l.sendMessageDelayed(Message.obtain(this.f693h.f677l, 8, this.f688c), this.f693h.f668a);
                return;
            }
            String valueOf = String.valueOf(this.f688c.f643a.f759c);
            m816a(new Status(17, new StringBuilder(String.valueOf(valueOf).length() + 38).append("API: ").append(valueOf).append(" is not available on this device.").toString()));
        }
    }

    final void m816a(Status status) {
        for (C0124a a : this.f686a) {
            a.mo181a(status);
        }
        this.f686a.clear();
    }

    public final void mo188b() {
        this.f692g = null;
        this.f691f = true;
        this.f693h.f677l.sendMessageDelayed(Message.obtain(this.f693h.f677l, 8, this.f688c), this.f693h.f668a);
        this.f693h.f677l.sendMessageDelayed(Message.obtain(this.f693h.f677l, 9, this.f688c), this.f693h.f669b);
        this.f693h.f673h = -1;
    }

    final void m818c() {
        if (this.f691f) {
            this.f693h.f677l.removeMessages(9, this.f688c);
            this.f693h.f677l.removeMessages(8, this.f688c);
            this.f691f = false;
        }
    }

    final void m819d() {
        this.f693h.f677l.removeMessages(10, this.f688c);
        this.f693h.f677l.sendMessageDelayed(this.f693h.f677l.obtainMessage(10, this.f688c), this.f693h.f670c);
    }

    final void m820e() {
        if (this.f687b.m760b() && this.f695j.size() == 0) {
            for (int i = 0; i < this.f689d.size(); i++) {
                Object obj;
                for (C0140f b : (C0140f[]) ((C0158u) this.f689d.get(this.f689d.keyAt(i))).f702b.toArray(C0158u.f701a)) {
                    if (!b.m773b()) {
                        obj = 1;
                        break;
                    }
                }
                obj = null;
                if (obj != null) {
                    m819d();
                    return;
                }
            }
            this.f687b.m757a();
        }
    }

    final void m821f() {
        if (!this.f687b.m760b() && !this.f687b.m761c()) {
            if (this.f693h.f673h != 0) {
                this.f693h.f673h = this.f693h.f672g.mo192a(this.f693h.f671f);
                if (this.f693h.f673h != 0) {
                    mo187a(new ConnectionResult(this.f693h.f673h, null));
                    return;
                }
            }
            this.f687b.m758a(new C0156r(this.f693h, this.f687b, this.f688c));
        }
    }
}
