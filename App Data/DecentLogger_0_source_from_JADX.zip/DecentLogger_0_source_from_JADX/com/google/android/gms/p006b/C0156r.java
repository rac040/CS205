package com.google.android.gms.p006b;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.C0129j;
import com.google.android.gms.common.internal.C0155p;
import java.util.Collections;

final class C0156r implements C0155p {
    final /* synthetic */ C0147m f698a;
    private final C0129j f699b;
    private final C0135c f700c;

    public C0156r(C0147m c0147m, C0129j c0129j, C0135c c0135c) {
        this.f698a = c0147m;
        this.f699b = c0129j;
        this.f700c = c0135c;
    }

    public final void mo190a(ConnectionResult connectionResult) {
        if (connectionResult.m829b()) {
            this.f699b.m759a(Collections.emptySet());
        } else {
            ((C0152p) this.f698a.f675j.get(this.f700c)).mo187a(connectionResult);
        }
    }
}
