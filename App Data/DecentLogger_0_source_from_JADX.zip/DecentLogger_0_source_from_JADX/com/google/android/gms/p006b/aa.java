package com.google.android.gms.p006b;

final class aa extends C0125y {
    aa(String str, Integer num) {
        super(str, num);
    }

    protected final /* synthetic */ Object mo172a() {
        ac acVar = null;
        return acVar.m746b();
    }
}
