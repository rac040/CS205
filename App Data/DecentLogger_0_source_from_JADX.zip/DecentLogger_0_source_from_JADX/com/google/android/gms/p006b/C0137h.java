package com.google.android.gms.p006b;

import android.os.Looper;
import android.util.Pair;
import com.google.android.gms.common.api.C0136s;
import com.google.android.gms.common.api.C0170u;
import com.google.android.gms.common.api.C0177o;
import com.google.android.gms.common.api.C0179t;
import com.google.android.gms.common.api.C0180v;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.internal.C0200d;
import com.google.android.gms.common.internal.an;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.concurrent.CountDownLatch;

public abstract class C0137h extends C0136s {
    static final ThreadLocal f645a = new C0143i();
    protected final C0144j f646b = new C0144j(Looper.getMainLooper());
    protected final WeakReference f647c = new WeakReference(null);
    private final Object f648d = new Object();
    private final CountDownLatch f649e = new CountDownLatch(1);
    private final ArrayList f650f = new ArrayList();
    private C0180v f651g;
    private C0170u f652h;
    private C0145k f653i;
    private volatile boolean f654j;
    private boolean f655k;
    private boolean f656l;
    private an f657m;
    private boolean f658n = false;

    @Deprecated
    C0137h() {
    }

    private boolean m767a() {
        boolean z;
        synchronized (this.f648d) {
            z = this.f655k;
        }
        return z;
    }

    public static void m768b(C0170u c0170u) {
        if (!(c0170u instanceof C0179t)) {
        }
    }

    private void m769c(C0170u c0170u) {
        this.f652h = c0170u;
        this.f657m = null;
        this.f649e.countDown();
        this.f652h.mo191a();
        if (this.f655k) {
            this.f651g = null;
        } else if (this.f651g != null) {
            this.f646b.removeMessages(2);
            C0144j c0144j = this.f646b;
            c0144j.sendMessage(c0144j.obtainMessage(1, new Pair(this.f651g, m770e())));
        } else if (this.f652h instanceof C0179t) {
            this.f653i = new C0145k();
        }
        Iterator it = this.f650f.iterator();
        while (it.hasNext()) {
            it.next();
        }
        this.f650f.clear();
    }

    private C0170u m770e() {
        C0170u c0170u;
        boolean z = true;
        synchronized (this.f648d) {
            if (this.f654j) {
                z = false;
            }
            C0200d.m1042a(z, (Object) "Result has already been consumed.");
            C0200d.m1042a(m773b(), (Object) "Result is not ready.");
            c0170u = this.f652h;
            this.f652h = null;
            this.f651g = null;
            this.f654j = true;
        }
        return c0170u;
    }

    protected abstract C0170u mo183a(Status status);

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void m772a(com.google.android.gms.common.api.C0170u r6) {
        /*
        r5 = this;
        r0 = 1;
        r1 = 0;
        r3 = r5.f648d;
        monitor-enter(r3);
        r2 = r5.f656l;	 Catch:{ all -> 0x002f }
        if (r2 != 0) goto L_0x002d;
    L_0x0009:
        r2 = r5.f655k;	 Catch:{ all -> 0x002f }
        if (r2 != 0) goto L_0x002d;
    L_0x000d:
        r2 = r5.m773b();	 Catch:{ all -> 0x002f }
        if (r2 == 0) goto L_0x0013;
    L_0x0013:
        r2 = r5.m773b();	 Catch:{ all -> 0x002f }
        if (r2 != 0) goto L_0x0032;
    L_0x0019:
        r2 = r0;
    L_0x001a:
        r4 = "Results have already been set";
        com.google.android.gms.common.internal.C0200d.m1042a(r2, r4);	 Catch:{ all -> 0x002f }
        r2 = r5.f654j;	 Catch:{ all -> 0x002f }
        if (r2 != 0) goto L_0x0034;
    L_0x0023:
        r1 = "Result has already been consumed";
        com.google.android.gms.common.internal.C0200d.m1042a(r0, r1);	 Catch:{ all -> 0x002f }
        r5.m769c(r6);	 Catch:{ all -> 0x002f }
        monitor-exit(r3);	 Catch:{ all -> 0x002f }
    L_0x002c:
        return;
    L_0x002d:
        monitor-exit(r3);	 Catch:{ all -> 0x002f }
        goto L_0x002c;
    L_0x002f:
        r0 = move-exception;
        monitor-exit(r3);	 Catch:{ all -> 0x002f }
        throw r0;
    L_0x0032:
        r2 = r1;
        goto L_0x001a;
    L_0x0034:
        r0 = r1;
        goto L_0x0023;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.b.h.a(com.google.android.gms.common.api.u):void");
    }

    public final boolean m773b() {
        return this.f649e.getCount() == 0;
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void m774c() {
        /*
        r2 = this;
        r1 = r2.f648d;
        monitor-enter(r1);
        r0 = r2.f655k;	 Catch:{ all -> 0x001b }
        if (r0 != 0) goto L_0x000b;
    L_0x0007:
        r0 = r2.f654j;	 Catch:{ all -> 0x001b }
        if (r0 == 0) goto L_0x000d;
    L_0x000b:
        monitor-exit(r1);	 Catch:{ all -> 0x001b }
    L_0x000c:
        return;
    L_0x000d:
        r0 = 1;
        r2.f655k = r0;	 Catch:{ all -> 0x001b }
        r0 = com.google.android.gms.common.api.Status.f750e;	 Catch:{ all -> 0x001b }
        r0 = r2.mo183a(r0);	 Catch:{ all -> 0x001b }
        r2.m769c(r0);	 Catch:{ all -> 0x001b }
        monitor-exit(r1);	 Catch:{ all -> 0x001b }
        goto L_0x000c;
    L_0x001b:
        r0 = move-exception;
        monitor-exit(r1);	 Catch:{ all -> 0x001b }
        throw r0;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.b.h.c():void");
    }

    public final void m775c(Status status) {
        synchronized (this.f648d) {
            if (!m773b()) {
                m772a(mo183a(status));
                this.f656l = true;
            }
        }
    }

    public final boolean m776d() {
        boolean a;
        synchronized (this.f648d) {
            if (((C0177o) this.f647c.get()) == null || !this.f658n) {
                m774c();
            }
            a = m767a();
        }
        return a;
    }
}
