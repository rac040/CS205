package com.google.android.gms.p006b;

import android.os.Process;
import android.util.SparseArray;
import java.lang.ref.ReferenceQueue;
import java.util.concurrent.atomic.AtomicBoolean;

final class C0149o extends Thread {
    private final ReferenceQueue f683a;
    private final SparseArray f684b;
    private final AtomicBoolean f685c = new AtomicBoolean();

    public C0149o(ReferenceQueue referenceQueue, SparseArray sparseArray) {
        super("GoogleApiCleanup");
        this.f683a = referenceQueue;
        this.f684b = sparseArray;
    }

    public final void run() {
        this.f685c.set(true);
        Process.setThreadPriority(10);
        while (this.f685c.get()) {
            try {
                C0148n c0148n = (C0148n) this.f683a.remove();
                this.f684b.remove(c0148n.f681a);
                c0148n.f682b.f677l.sendMessage(c0148n.f682b.f677l.obtainMessage(2, c0148n.f681a, 2));
            } catch (InterruptedException e) {
            } finally {
                this.f685c.set(false);
            }
        }
    }
}
