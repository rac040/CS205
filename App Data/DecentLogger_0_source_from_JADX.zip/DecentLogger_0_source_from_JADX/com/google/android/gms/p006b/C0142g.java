package com.google.android.gms.p006b;

import android.content.DialogInterface;
import android.content.DialogInterface.OnCancelListener;
import com.google.android.gms.common.ConnectionResult;

public abstract class C0142g extends C0141s implements OnCancelListener {
    protected boolean f662a;
    private ConnectionResult f663b;
    private int f664c;

    protected abstract void mo184a();

    protected abstract void mo185a(ConnectionResult connectionResult, int i);

    public void onCancel(DialogInterface dialogInterface) {
        mo185a(new ConnectionResult(13, null), this.f664c);
        this.f664c = -1;
        this.f662a = false;
        this.f663b = null;
        mo184a();
    }
}
