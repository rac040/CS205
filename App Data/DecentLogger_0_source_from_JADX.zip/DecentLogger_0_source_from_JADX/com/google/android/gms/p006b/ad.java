package com.google.android.gms.p006b;

import android.annotation.TargetApi;
import android.app.AppOpsManager;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import com.google.android.gms.common.util.C0232f;

public final class ad {
    protected final Context f621a;

    public ad(Context context) {
        this.f621a = context;
    }

    public final ApplicationInfo m748a(String str, int i) {
        return this.f621a.getPackageManager().getApplicationInfo(str, i);
    }

    public final PackageInfo m749a(String str) {
        return this.f621a.getPackageManager().getPackageInfo(str, 64);
    }

    @TargetApi(19)
    public final boolean m750a(int i, String str) {
        if (C0232f.m1115a(19)) {
            try {
                ((AppOpsManager) this.f621a.getSystemService("appops")).checkPackage(i, str);
                return true;
            } catch (SecurityException e) {
                return false;
            }
        }
        String[] packagesForUid = this.f621a.getPackageManager().getPackagesForUid(i);
        if (packagesForUid == null) {
            return false;
        }
        for (Object equals : packagesForUid) {
            if (str.equals(equals)) {
                return true;
            }
        }
        return false;
    }
}
