package com.google.android.gms.p006b;

import com.google.android.gms.common.api.C0130b;
import com.google.android.gms.common.api.C0171a;
import com.google.android.gms.common.internal.C0198b;
import java.util.Arrays;

public final class C0135c {
    final C0171a f643a;
    private final C0130b f644b;

    public final boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof C0135c)) {
            return false;
        }
        C0135c c0135c = (C0135c) obj;
        return C0198b.m1037a(this.f643a, c0135c.f643a) && C0198b.m1037a(this.f644b, c0135c.f644b);
    }

    public final int hashCode() {
        return Arrays.hashCode(new Object[]{this.f643a, this.f644b});
    }
}
