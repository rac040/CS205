package com.google.android.gms.auth.api.signin;

import android.net.Uri;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.api.Scope;
import com.google.android.gms.common.internal.ReflectedParcelable;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import com.google.android.gms.common.util.C0228b;
import com.google.android.gms.common.util.C0229c;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONObject;

public class GoogleSignInAccount extends AbstractSafeParcelable implements ReflectedParcelable {
    public static final Creator CREATOR = new C0123b();
    public static C0228b f598a = C0229c.m1112a();
    private static Comparator f599n = new C0122a();
    final int f600b;
    String f601c;
    String f602d;
    String f603e;
    String f604f;
    Uri f605g;
    String f606h;
    long f607i;
    String f608j;
    List f609k;
    String f610l;
    String f611m;

    GoogleSignInAccount(int i, String str, String str2, String str3, String str4, Uri uri, String str5, long j, String str6, List list, String str7, String str8) {
        this.f600b = i;
        this.f601c = str;
        this.f602d = str2;
        this.f603e = str3;
        this.f604f = str4;
        this.f605g = uri;
        this.f606h = str5;
        this.f607i = j;
        this.f608j = str6;
        this.f609k = list;
        this.f610l = str7;
        this.f611m = str8;
    }

    private JSONObject m732a() {
        JSONObject jSONObject = new JSONObject();
        try {
            if (this.f601c != null) {
                jSONObject.put("id", this.f601c);
            }
            if (this.f602d != null) {
                jSONObject.put("tokenId", this.f602d);
            }
            if (this.f603e != null) {
                jSONObject.put("email", this.f603e);
            }
            if (this.f604f != null) {
                jSONObject.put("displayName", this.f604f);
            }
            if (this.f610l != null) {
                jSONObject.put("givenName", this.f610l);
            }
            if (this.f611m != null) {
                jSONObject.put("familyName", this.f611m);
            }
            if (this.f605g != null) {
                jSONObject.put("photoUrl", this.f605g.toString());
            }
            if (this.f606h != null) {
                jSONObject.put("serverAuthCode", this.f606h);
            }
            jSONObject.put("expirationTime", this.f607i);
            jSONObject.put("obfuscatedIdentifier", this.f608j);
            JSONArray jSONArray = new JSONArray();
            Collections.sort(this.f609k, f599n);
            for (Scope scope : this.f609k) {
                jSONArray.put(scope.f745b);
            }
            jSONObject.put("grantedScopes", jSONArray);
            return jSONObject;
        } catch (Throwable e) {
            throw new RuntimeException(e);
        }
    }

    public boolean equals(Object obj) {
        return !(obj instanceof GoogleSignInAccount) ? false : ((GoogleSignInAccount) obj).m732a().toString().equals(m732a().toString());
    }

    public void writeToParcel(Parcel parcel, int i) {
        C0123b.m733a(this, parcel, i);
    }
}
