package com.google.android.gms.auth.api.signin;

import android.net.Uri;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.api.Scope;
import com.google.android.gms.common.internal.safeparcel.C0212a;
import com.google.android.gms.common.internal.safeparcel.C0213b;
import com.google.android.gms.common.internal.safeparcel.C0214c;
import java.util.List;

public final class C0123b implements Creator {
    static void m733a(GoogleSignInAccount googleSignInAccount, Parcel parcel, int i) {
        int a = C0214c.m1078a(parcel, 20293);
        C0214c.m1079a(parcel, 1, googleSignInAccount.f600b);
        C0214c.m1085a(parcel, 2, googleSignInAccount.f601c);
        C0214c.m1085a(parcel, 3, googleSignInAccount.f602d);
        C0214c.m1085a(parcel, 4, googleSignInAccount.f603e);
        C0214c.m1085a(parcel, 5, googleSignInAccount.f604f);
        C0214c.m1083a(parcel, 6, googleSignInAccount.f605g, i);
        C0214c.m1085a(parcel, 7, googleSignInAccount.f606h);
        C0214c.m1080a(parcel, 8, googleSignInAccount.f607i);
        C0214c.m1085a(parcel, 9, googleSignInAccount.f608j);
        C0214c.m1086a(parcel, 10, googleSignInAccount.f609k);
        C0214c.m1085a(parcel, 11, googleSignInAccount.f610l);
        C0214c.m1085a(parcel, 12, googleSignInAccount.f611m);
        C0214c.m1090b(parcel, a);
    }

    public final /* synthetic */ Object createFromParcel(Parcel parcel) {
        int a = C0212a.m1064a(parcel);
        int i = 0;
        String str = null;
        String str2 = null;
        String str3 = null;
        String str4 = null;
        Uri uri = null;
        String str5 = null;
        long j = 0;
        String str6 = null;
        List list = null;
        String str7 = null;
        String str8 = null;
        while (parcel.dataPosition() < a) {
            int readInt = parcel.readInt();
            switch (65535 & readInt) {
                case 1:
                    i = C0212a.m1070c(parcel, readInt);
                    break;
                case 2:
                    str = C0212a.m1074f(parcel, readInt);
                    break;
                case 3:
                    str2 = C0212a.m1074f(parcel, readInt);
                    break;
                case 4:
                    str3 = C0212a.m1074f(parcel, readInt);
                    break;
                case 5:
                    str4 = C0212a.m1074f(parcel, readInt);
                    break;
                case 6:
                    uri = (Uri) C0212a.m1065a(parcel, readInt, Uri.CREATOR);
                    break;
                case 7:
                    str5 = C0212a.m1074f(parcel, readInt);
                    break;
                case 8:
                    j = C0212a.m1073e(parcel, readInt);
                    break;
                case 9:
                    str6 = C0212a.m1074f(parcel, readInt);
                    break;
                case 10:
                    list = C0212a.m1071c(parcel, readInt, Scope.CREATOR);
                    break;
                case 11:
                    str7 = C0212a.m1074f(parcel, readInt);
                    break;
                case 12:
                    str8 = C0212a.m1074f(parcel, readInt);
                    break;
                default:
                    C0212a.m1066a(parcel, readInt);
                    break;
            }
        }
        if (parcel.dataPosition() == a) {
            return new GoogleSignInAccount(i, str, str2, str3, str4, uri, str5, j, str6, list, str7, str8);
        }
        throw new C0213b("Overread allowed size end=" + a, parcel);
    }

    public final /* synthetic */ Object[] newArray(int i) {
        return new GoogleSignInAccount[i];
    }
}
