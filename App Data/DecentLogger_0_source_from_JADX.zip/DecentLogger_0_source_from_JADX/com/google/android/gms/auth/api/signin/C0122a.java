package com.google.android.gms.auth.api.signin;

import com.google.android.gms.common.api.Scope;
import java.util.Comparator;

final class C0122a implements Comparator {
    C0122a() {
    }

    public final /* synthetic */ int compare(Object obj, Object obj2) {
        return ((Scope) obj).f745b.compareTo(((Scope) obj2).f745b);
    }
}
