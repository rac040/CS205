package com.google.android.gms.signin.internal;

import android.os.IInterface;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.Status;

public interface C0247c extends IInterface {
    void mo265a(ConnectionResult connectionResult, AuthAccountResult authAccountResult);

    void mo266a(Status status);

    void mo267a(Status status, GoogleSignInAccount googleSignInAccount);

    void mo268a(SignInResponse signInResponse);

    void mo269b(Status status);
}
