package com.google.android.gms.signin.internal;

import android.content.Context;
import android.os.Bundle;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Looper;
import com.google.android.gms.common.api.C0150q;
import com.google.android.gms.common.api.C0151r;
import com.google.android.gms.common.internal.C0217v;
import com.google.android.gms.common.internal.ab;
import com.google.android.gms.p006b.am;
import com.google.android.gms.p006b.an;

public final class C0254j extends ab implements am {
    private final boolean f967a;
    private final C0217v f968h;
    private final Bundle f969i;
    private Integer f970j;

    public C0254j(Context context, Looper looper, C0217v c0217v, C0150q c0150q, C0151r c0151r) {
        an anVar = c0217v.f913e;
        Integer num = c0217v.f914f;
        Bundle bundle = new Bundle();
        bundle.putParcelable("com.google.android.gms.signin.internal.clientRequestedAccount", c0217v.f909a);
        if (num != null) {
            bundle.putInt("com.google.android.gms.common.internal.ClientSettings.sessionId", num.intValue());
        }
        if (anVar != null) {
            bundle.putBoolean("com.google.android.gms.signin.internal.offlineAccessRequested", anVar.f634b);
            bundle.putBoolean("com.google.android.gms.signin.internal.idTokenRequested", anVar.f635c);
            bundle.putString("com.google.android.gms.signin.internal.serverClientId", anVar.f636d);
            bundle.putBoolean("com.google.android.gms.signin.internal.usePromptModeForAuthCode", true);
            bundle.putBoolean("com.google.android.gms.signin.internal.forceCodeForRefreshToken", anVar.f637e);
            bundle.putString("com.google.android.gms.signin.internal.hostedDomain", anVar.f638f);
            bundle.putBoolean("com.google.android.gms.signin.internal.waitForAccessTokenRefresh", anVar.f639g);
            if (anVar.f640h != null) {
                bundle.putLong("com.google.android.gms.signin.internal.authApiSignInModuleVersion", anVar.f640h.longValue());
            }
            if (anVar.f641i != null) {
                bundle.putLong("com.google.android.gms.signin.internal.realClientLibraryVersion", anVar.f641i.longValue());
            }
        }
        this(context, looper, true, c0217v, bundle, c0150q, c0151r);
    }

    public C0254j(Context context, Looper looper, boolean z, C0217v c0217v, Bundle bundle, C0150q c0150q, C0151r c0151r) {
        super(context, looper, c0217v, c0150q, c0151r);
        this.f967a = z;
        this.f968h = c0217v;
        this.f969i = bundle;
        this.f970j = c0217v.f914f;
    }

    protected final /* synthetic */ IInterface mo257a(IBinder iBinder) {
        return C0251g.m1142a(iBinder);
    }

    protected final String mo258d() {
        return "com.google.android.gms.signin.service.START";
    }

    protected final String mo259e() {
        return "com.google.android.gms.signin.internal.ISignInService";
    }

    protected final Bundle mo280g() {
        if (!this.f837d.getPackageName().equals(this.f968h.f911c)) {
            this.f969i.putString("com.google.android.gms.signin.internal.realClientPackageName", this.f968h.f911c);
        }
        return this.f969i;
    }

    public final boolean mo281i() {
        return this.f967a;
    }
}
