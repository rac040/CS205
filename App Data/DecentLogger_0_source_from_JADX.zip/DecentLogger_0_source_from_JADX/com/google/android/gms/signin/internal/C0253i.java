package com.google.android.gms.signin.internal;

import android.accounts.Account;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.api.Scope;
import com.google.android.gms.common.internal.safeparcel.C0212a;
import com.google.android.gms.common.internal.safeparcel.C0213b;
import com.google.android.gms.common.internal.safeparcel.C0214c;

public final class C0253i implements Creator {
    static void m1153a(RecordConsentRequest recordConsentRequest, Parcel parcel, int i) {
        int a = C0214c.m1078a(parcel, 20293);
        C0214c.m1079a(parcel, 1, recordConsentRequest.f956a);
        C0214c.m1083a(parcel, 2, recordConsentRequest.f957b, i);
        C0214c.m1088a(parcel, 3, recordConsentRequest.f958c, i);
        C0214c.m1085a(parcel, 4, recordConsentRequest.f959d);
        C0214c.m1090b(parcel, a);
    }

    public final /* synthetic */ Object createFromParcel(Parcel parcel) {
        int a = C0212a.m1064a(parcel);
        Scope[] scopeArr = null;
        Account account = null;
        int i = 0;
        String str = null;
        while (parcel.dataPosition() < a) {
            int readInt = parcel.readInt();
            switch (65535 & readInt) {
                case 1:
                    i = C0212a.m1070c(parcel, readInt);
                    break;
                case 2:
                    account = (Account) C0212a.m1065a(parcel, readInt, Account.CREATOR);
                    break;
                case 3:
                    scopeArr = (Scope[]) C0212a.m1069b(parcel, readInt, Scope.CREATOR);
                    break;
                case 4:
                    str = C0212a.m1074f(parcel, readInt);
                    break;
                default:
                    C0212a.m1066a(parcel, readInt);
                    break;
            }
        }
        if (parcel.dataPosition() == a) {
            return new RecordConsentRequest(i, account, scopeArr, str);
        }
        throw new C0213b("Overread allowed size end=" + a, parcel);
    }

    public final /* synthetic */ Object[] newArray(int i) {
        return new RecordConsentRequest[i];
    }
}
