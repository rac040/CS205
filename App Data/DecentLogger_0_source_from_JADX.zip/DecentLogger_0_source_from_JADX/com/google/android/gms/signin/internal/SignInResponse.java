package com.google.android.gms.signin.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.internal.ResolveAccountResponse;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;

public class SignInResponse extends AbstractSafeParcelable {
    public static final Creator CREATOR = new C0256l();
    final int f962a;
    final ConnectionResult f963b;
    final ResolveAccountResponse f964c;

    SignInResponse(int i, ConnectionResult connectionResult, ResolveAccountResponse resolveAccountResponse) {
        this.f962a = i;
        this.f963b = connectionResult;
        this.f964c = resolveAccountResponse;
    }

    public void writeToParcel(Parcel parcel, int i) {
        C0256l.m1160a(this, parcel, i);
    }
}
