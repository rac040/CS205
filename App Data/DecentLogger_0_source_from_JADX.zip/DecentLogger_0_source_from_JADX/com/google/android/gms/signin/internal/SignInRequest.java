package com.google.android.gms.signin.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.ResolveAccountRequest;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;

public class SignInRequest extends AbstractSafeParcelable {
    public static final Creator CREATOR = new C0255k();
    final int f960a;
    final ResolveAccountRequest f961b;

    SignInRequest(int i, ResolveAccountRequest resolveAccountRequest) {
        this.f960a = i;
        this.f961b = resolveAccountRequest;
    }

    public void writeToParcel(Parcel parcel, int i) {
        C0255k.m1159a(this, parcel, i);
    }
}
