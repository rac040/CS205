package com.google.android.gms.signin.internal;

import android.content.Intent;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.api.C0170u;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;

public class AuthAccountResult extends AbstractSafeParcelable implements C0170u {
    public static final Creator CREATOR = new C0245a();
    final int f950a;
    int f951b;
    Intent f952c;

    public AuthAccountResult() {
        this((byte) 0);
    }

    private AuthAccountResult(byte b) {
        this(2, 0, null);
    }

    AuthAccountResult(int i, int i2, Intent intent) {
        this.f950a = i;
        this.f951b = i2;
        this.f952c = intent;
    }

    public final Status mo191a() {
        return this.f951b == 0 ? Status.f746a : Status.f750e;
    }

    public void writeToParcel(Parcel parcel, int i) {
        C0245a.m1119a(this, parcel, i);
    }
}
