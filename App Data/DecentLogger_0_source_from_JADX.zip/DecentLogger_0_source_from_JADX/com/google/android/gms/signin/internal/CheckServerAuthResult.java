package com.google.android.gms.signin.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import java.util.List;

public class CheckServerAuthResult extends AbstractSafeParcelable {
    public static final Creator CREATOR = new C0246b();
    final int f953a;
    final boolean f954b;
    final List f955c;

    CheckServerAuthResult(int i, boolean z, List list) {
        this.f953a = i;
        this.f954b = z;
        this.f955c = list;
    }

    public void writeToParcel(Parcel parcel, int i) {
        C0246b.m1120a(this, parcel);
    }
}
