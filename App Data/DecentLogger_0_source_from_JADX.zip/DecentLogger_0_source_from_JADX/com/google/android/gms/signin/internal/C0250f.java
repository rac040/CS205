package com.google.android.gms.signin.internal;

import android.accounts.Account;
import android.os.IInterface;
import com.google.android.gms.common.internal.AuthAccountRequest;
import com.google.android.gms.common.internal.ResolveAccountRequest;
import com.google.android.gms.common.internal.ak;
import com.google.android.gms.common.internal.aw;

public interface C0250f extends IInterface {
    void mo270a(int i);

    void mo271a(int i, Account account, C0247c c0247c);

    void mo272a(AuthAccountRequest authAccountRequest, C0247c c0247c);

    void mo273a(ResolveAccountRequest resolveAccountRequest, aw awVar);

    void mo274a(ak akVar, int i, boolean z);

    void mo275a(CheckServerAuthResult checkServerAuthResult);

    void mo276a(RecordConsentRequest recordConsentRequest, C0247c c0247c);

    void mo277a(SignInRequest signInRequest, C0247c c0247c);

    void mo278a(C0247c c0247c);

    void mo279a(boolean z);
}
