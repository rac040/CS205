package com.google.android.gms.signin.internal;

import android.accounts.Account;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.api.Scope;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;

public class RecordConsentRequest extends AbstractSafeParcelable {
    public static final Creator CREATOR = new C0253i();
    final int f956a;
    final Account f957b;
    final Scope[] f958c;
    final String f959d;

    RecordConsentRequest(int i, Account account, Scope[] scopeArr, String str) {
        this.f956a = i;
        this.f957b = account;
        this.f958c = scopeArr;
        this.f959d = str;
    }

    public void writeToParcel(Parcel parcel, int i) {
        C0253i.m1153a(this, parcel, i);
    }
}
