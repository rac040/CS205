package com.google.android.gms.dynamite.descriptors.com.google.android.gms.flags;

import com.google.android.gms.common.util.DynamiteApi;

@DynamiteApi
public class ModuleDescriptor {
    public static final String MODULE_ID = "com.google.android.gms.flags";
    public static final int MODULE_VERSION = 1;
}
