package com.google.android.gms;

public final class C0163c {
    public static final int common_google_play_services_enable_button = 2131230720;
    public static final int common_google_play_services_enable_text = 2131230721;
    public static final int common_google_play_services_enable_title = 2131230722;
    public static final int common_google_play_services_install_button = 2131230723;
    public static final int common_google_play_services_install_text_phone = 2131230724;
    public static final int common_google_play_services_install_text_tablet = 2131230725;
    public static final int common_google_play_services_install_title = 2131230726;
    public static final int common_google_play_services_notification_ticker = 2131230727;
    public static final int common_google_play_services_unknown_issue = 2131230728;
    public static final int common_google_play_services_unsupported_text = 2131230729;
    public static final int common_google_play_services_unsupported_title = 2131230730;
    public static final int common_google_play_services_update_button = 2131230731;
    public static final int common_google_play_services_update_text = 2131230732;
    public static final int common_google_play_services_update_title = 2131230733;
    public static final int common_google_play_services_updating_text = 2131230734;
    public static final int common_google_play_services_updating_title = 2131230735;
    public static final int common_google_play_services_wear_update_text = 2131230736;
    public static final int common_open_on_phone = 2131230737;
    public static final int common_signin_button_text = 2131230738;
    public static final int common_signin_button_text_long = 2131230739;
}
