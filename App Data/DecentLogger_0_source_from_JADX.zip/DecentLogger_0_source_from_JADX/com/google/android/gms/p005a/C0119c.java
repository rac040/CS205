package com.google.android.gms.p005a;

import android.os.IBinder;

public final class C0119c implements C0117a {
    private IBinder f596a;

    public C0119c(IBinder iBinder) {
        this.f596a = iBinder;
    }

    public final IBinder asBinder() {
        return this.f596a;
    }
}
