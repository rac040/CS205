package com.google.android.gms.p005a;

import android.os.IInterface;

public interface C0117a extends IInterface {
}
