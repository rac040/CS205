package com.google.android.gms.common.api;

import com.google.android.gms.common.internal.C0155p;
import java.util.Set;

public interface C0129j extends C0128g {
    void m757a();

    void m758a(C0155p c0155p);

    void m759a(Set set);

    boolean m760b();

    boolean m761c();
}
