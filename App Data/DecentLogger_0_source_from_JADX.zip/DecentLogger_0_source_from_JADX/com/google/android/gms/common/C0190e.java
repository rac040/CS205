package com.google.android.gms.common;

import android.app.PendingIntent;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C0212a;
import com.google.android.gms.common.internal.safeparcel.C0213b;
import com.google.android.gms.common.internal.safeparcel.C0214c;

public final class C0190e implements Creator {
    static void m873a(ConnectionResult connectionResult, Parcel parcel, int i) {
        int a = C0214c.m1078a(parcel, 20293);
        C0214c.m1079a(parcel, 1, connectionResult.f708b);
        C0214c.m1079a(parcel, 2, connectionResult.f709c);
        C0214c.m1083a(parcel, 3, connectionResult.f710d, i);
        C0214c.m1085a(parcel, 4, connectionResult.f711e);
        C0214c.m1090b(parcel, a);
    }

    public final /* synthetic */ Object createFromParcel(Parcel parcel) {
        int a = C0212a.m1064a(parcel);
        PendingIntent pendingIntent = null;
        int i = 0;
        int i2 = 0;
        String str = null;
        while (parcel.dataPosition() < a) {
            int readInt = parcel.readInt();
            switch (65535 & readInt) {
                case 1:
                    i2 = C0212a.m1070c(parcel, readInt);
                    break;
                case 2:
                    i = C0212a.m1070c(parcel, readInt);
                    break;
                case 3:
                    pendingIntent = (PendingIntent) C0212a.m1065a(parcel, readInt, PendingIntent.CREATOR);
                    break;
                case 4:
                    str = C0212a.m1074f(parcel, readInt);
                    break;
                default:
                    C0212a.m1066a(parcel, readInt);
                    break;
            }
        }
        if (parcel.dataPosition() == a) {
            return new ConnectionResult(i2, i, pendingIntent, str);
        }
        throw new C0213b("Overread allowed size end=" + a, parcel);
    }

    public final /* synthetic */ Object[] newArray(int i) {
        return new ConnectionResult[i];
    }
}
