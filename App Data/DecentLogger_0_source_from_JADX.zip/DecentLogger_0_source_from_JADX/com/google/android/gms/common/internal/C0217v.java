package com.google.android.gms.common.internal;

import android.accounts.Account;
import android.view.View;
import com.google.android.gms.p006b.an;
import java.util.Collections;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public final class C0217v {
    public final Account f909a;
    final Set f910b;
    public final String f911c;
    final String f912d;
    public final an f913e;
    public Integer f914f;
    private final Set f915g;
    private final Map f916h;
    private final int f917i;
    private final View f918j;

    public C0217v(Account account, Set set, Map map, int i, View view, String str, String str2, an anVar) {
        this.f909a = account;
        this.f915g = set == null ? Collections.EMPTY_SET : Collections.unmodifiableSet(set);
        if (map == null) {
            map = Collections.EMPTY_MAP;
        }
        this.f916h = map;
        this.f918j = view;
        this.f917i = i;
        this.f911c = str;
        this.f912d = str2;
        this.f913e = anVar;
        Set hashSet = new HashSet(this.f915g);
        for (C0218w c0218w : this.f916h.values()) {
            hashSet.addAll(c0218w.f919a);
        }
        this.f910b = Collections.unmodifiableSet(hashSet);
    }
}
