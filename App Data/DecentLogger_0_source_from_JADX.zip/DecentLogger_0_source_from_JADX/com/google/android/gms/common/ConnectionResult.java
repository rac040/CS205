package com.google.android.gms.common;

import android.app.PendingIntent;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import android.support.wearable.C0107c;
import com.google.android.gms.common.internal.C0198b;
import com.google.android.gms.common.internal.C0199c;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import java.util.Arrays;

public final class ConnectionResult extends AbstractSafeParcelable {
    public static final Creator CREATOR = new C0190e();
    public static final ConnectionResult f707a = new ConnectionResult(0);
    final int f708b;
    public final int f709c;
    public final PendingIntent f710d;
    final String f711e;

    public ConnectionResult(int i) {
        this(i, null, (byte) 0);
    }

    ConnectionResult(int i, int i2, PendingIntent pendingIntent, String str) {
        this.f708b = i;
        this.f709c = i2;
        this.f710d = pendingIntent;
        this.f711e = str;
    }

    public ConnectionResult(int i, PendingIntent pendingIntent) {
        this(i, pendingIntent, (byte) 0);
    }

    private ConnectionResult(int i, PendingIntent pendingIntent, byte b) {
        this(1, i, pendingIntent, null);
    }

    public final boolean m828a() {
        return (this.f709c == 0 || this.f710d == null) ? false : true;
    }

    public final boolean m829b() {
        return this.f709c == 0;
    }

    public final boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof ConnectionResult)) {
            return false;
        }
        ConnectionResult connectionResult = (ConnectionResult) obj;
        return this.f709c == connectionResult.f709c && C0198b.m1037a(this.f710d, connectionResult.f710d) && C0198b.m1037a(this.f711e, connectionResult.f711e);
    }

    public final int hashCode() {
        return Arrays.hashCode(new Object[]{Integer.valueOf(this.f709c), this.f710d, this.f711e});
    }

    public final String toString() {
        Object obj;
        C0199c a = C0198b.m1036a(this);
        String str = "statusCode";
        int i = this.f709c;
        switch (i) {
            case -1:
                obj = "UNKNOWN";
                break;
            case 0:
                obj = "SUCCESS";
                break;
            case 1:
                obj = "SERVICE_MISSING";
                break;
            case 2:
                obj = "SERVICE_VERSION_UPDATE_REQUIRED";
                break;
            case 3:
                obj = "SERVICE_DISABLED";
                break;
            case 4:
                obj = "SIGN_IN_REQUIRED";
                break;
            case 5:
                obj = "INVALID_ACCOUNT";
                break;
            case 6:
                obj = "RESOLUTION_REQUIRED";
                break;
            case 7:
                obj = "NETWORK_ERROR";
                break;
            case 8:
                obj = "INTERNAL_ERROR";
                break;
            case 9:
                obj = "SERVICE_INVALID";
                break;
            case 10:
                obj = "DEVELOPER_ERROR";
                break;
            case 11:
                obj = "LICENSE_CHECK_FAILED";
                break;
            case 13:
                obj = "CANCELED";
                break;
            case 14:
                obj = "TIMEOUT";
                break;
            case C0107c.ActionPage_imageScaleMode /*15*/:
                obj = "INTERRUPTED";
                break;
            case C0107c.ActionPage_buttonRippleColor /*16*/:
                obj = "API_UNAVAILABLE";
                break;
            case C0107c.ActionPage_pressedButtonTranslationZ /*17*/:
                obj = "SIGN_IN_FAILED";
                break;
            case 18:
                obj = "SERVICE_UPDATING";
                break;
            case 19:
                obj = "SERVICE_MISSING_PERMISSION";
                break;
            case 20:
                obj = "RESTRICTED_PROFILE";
                break;
            case 21:
                obj = "API_VERSION_UPDATE_REQUIRED";
                break;
            case 42:
                obj = "UPDATE_ANDROID_WEAR";
                break;
            case 99:
                obj = "UNFINISHED";
                break;
            case 1500:
                obj = "DRIVE_EXTERNAL_STORAGE_REQUIRED";
                break;
            default:
                obj = "UNKNOWN_ERROR_CODE(" + i + ")";
                break;
        }
        return a.m1038a(str, obj).m1038a("resolution", this.f710d).m1038a("message", this.f711e).toString();
    }

    public final void writeToParcel(Parcel parcel, int i) {
        C0190e.m873a(this, parcel, i);
    }
}
