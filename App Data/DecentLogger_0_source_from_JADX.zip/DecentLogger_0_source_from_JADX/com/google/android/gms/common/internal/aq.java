package com.google.android.gms.common.internal;

import android.os.Bundle;
import android.os.IBinder;
import android.os.IInterface;

public interface aq extends IInterface {
    void mo209a(int i, Bundle bundle);

    void mo210a(int i, IBinder iBinder, Bundle bundle);
}
