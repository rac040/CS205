package com.google.android.gms.common.api;

import android.app.PendingIntent;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C0212a;
import com.google.android.gms.common.internal.safeparcel.C0213b;
import com.google.android.gms.common.internal.safeparcel.C0214c;

public final class aa implements Creator {
    static void m839a(Status status, Parcel parcel, int i) {
        int a = C0214c.m1078a(parcel, 20293);
        C0214c.m1079a(parcel, 1, status.f754i);
        C0214c.m1085a(parcel, 2, status.f755j);
        C0214c.m1083a(parcel, 3, status.f756k, i);
        C0214c.m1079a(parcel, 1000, status.f753h);
        C0214c.m1090b(parcel, a);
    }

    public final /* synthetic */ Object createFromParcel(Parcel parcel) {
        PendingIntent pendingIntent = null;
        int a = C0212a.m1064a(parcel);
        int i = 0;
        int i2 = 0;
        String str = null;
        while (parcel.dataPosition() < a) {
            int readInt = parcel.readInt();
            switch (65535 & readInt) {
                case 1:
                    i = C0212a.m1070c(parcel, readInt);
                    break;
                case 2:
                    str = C0212a.m1074f(parcel, readInt);
                    break;
                case 3:
                    pendingIntent = (PendingIntent) C0212a.m1065a(parcel, readInt, PendingIntent.CREATOR);
                    break;
                case 1000:
                    i2 = C0212a.m1070c(parcel, readInt);
                    break;
                default:
                    C0212a.m1066a(parcel, readInt);
                    break;
            }
        }
        if (parcel.dataPosition() == a) {
            return new Status(i2, i, str, pendingIntent);
        }
        throw new C0213b("Overread allowed size end=" + a, parcel);
    }

    public final /* synthetic */ Object[] newArray(int i) {
        return new Status[i];
    }
}
