package com.google.android.gms.common.internal;

import android.content.ComponentName;
import android.content.ServiceConnection;
import android.os.IBinder;

public final class ai implements ServiceConnection {
    final /* synthetic */ ah f880a;

    public ai(ah ahVar) {
        this.f880a = ahVar;
    }

    public final void onServiceConnected(ComponentName componentName, IBinder iBinder) {
        synchronized (this.f880a.f879h.f864a) {
            this.f880a.f876e = iBinder;
            this.f880a.f878g = componentName;
            for (ServiceConnection onServiceConnected : this.f880a.f873b) {
                onServiceConnected.onServiceConnected(componentName, iBinder);
            }
            this.f880a.f874c = 1;
        }
    }

    public final void onServiceDisconnected(ComponentName componentName) {
        synchronized (this.f880a.f879h.f864a) {
            this.f880a.f876e = null;
            this.f880a.f878g = componentName;
            for (ServiceConnection onServiceDisconnected : this.f880a.f873b) {
                onServiceDisconnected.onServiceDisconnected(componentName);
            }
            this.f880a.f874c = 2;
        }
    }
}
