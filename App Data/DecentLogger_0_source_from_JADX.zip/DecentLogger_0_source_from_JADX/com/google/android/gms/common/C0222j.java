package com.google.android.gms.common;

import java.lang.ref.WeakReference;

abstract class C0222j extends C0192h {
    private static final WeakReference f924b = new WeakReference(null);
    private WeakReference f925a = f924b;

    C0222j(byte[] bArr) {
        super(bArr);
    }

    final byte[] mo201c() {
        byte[] bArr;
        synchronized (this) {
            bArr = (byte[]) this.f925a.get();
            if (bArr == null) {
                bArr = mo264d();
                this.f925a = new WeakReference(bArr);
            }
        }
        return bArr;
    }

    protected abstract byte[] mo264d();
}
