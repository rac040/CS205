package com.google.android.gms.common.internal;

import android.os.Bundle;
import android.os.IBinder;
import android.os.IInterface;
import android.os.RemoteException;
import android.util.Log;
import com.google.android.gms.common.ConnectionResult;

public final class C0211s extends C0207k {
    public final IBinder f905e;
    final /* synthetic */ C0195j f906f;

    public C0211s(C0195j c0195j, int i, IBinder iBinder, Bundle bundle) {
        this.f906f = c0195j;
        super(c0195j, i, bundle);
        this.f905e = iBinder;
    }

    protected final void mo261a(ConnectionResult connectionResult) {
        if (this.f906f.f854v != null) {
            this.f906f.f854v.mo206a(connectionResult);
        }
        this.f906f.m902a(connectionResult);
    }

    protected final boolean mo262a() {
        try {
            String interfaceDescriptor = this.f905e.getInterfaceDescriptor();
            if (this.f906f.mo259e().equals(interfaceDescriptor)) {
                IInterface a = this.f906f.mo257a(this.f905e);
                if (a == null || !this.f906f.m891a(2, 3, a)) {
                    return false;
                }
                C0195j.m897h();
                if (this.f906f.f853u != null) {
                    this.f906f.f853u.mo204a();
                }
                return true;
            }
            String valueOf = String.valueOf(this.f906f.mo259e());
            Log.e("GmsClient", new StringBuilder((String.valueOf(valueOf).length() + 34) + String.valueOf(interfaceDescriptor).length()).append("service descriptor mismatch: ").append(valueOf).append(" vs. ").append(interfaceDescriptor).toString());
            return false;
        } catch (RemoteException e) {
            Log.w("GmsClient", "service probably died");
            return false;
        }
    }
}
