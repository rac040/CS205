package com.google.android.gms.common.internal;

import android.app.PendingIntent;
import android.os.Bundle;
import com.google.android.gms.common.ConnectionResult;

abstract class C0207k extends C0206o {
    public final int f897a;
    public final Bundle f898b;
    final /* synthetic */ C0195j f899c;

    protected C0207k(C0195j c0195j, int i, Bundle bundle) {
        this.f899c = c0195j;
        super(c0195j, Boolean.valueOf(true));
        this.f897a = i;
        this.f898b = bundle;
    }

    protected abstract void mo261a(ConnectionResult connectionResult);

    protected final /* synthetic */ void mo260a(Object obj) {
        PendingIntent pendingIntent = null;
        if (((Boolean) obj) == null) {
            this.f899c.m889a(1, null);
            return;
        }
        switch (this.f897a) {
            case 0:
                if (!mo262a()) {
                    this.f899c.m889a(1, null);
                    mo261a(new ConnectionResult(8, null));
                    return;
                }
                return;
            case 10:
                this.f899c.m889a(1, null);
                throw new IllegalStateException("A fatal developer error has occurred. Check the logs for further information.");
            default:
                this.f899c.m889a(1, null);
                if (this.f898b != null) {
                    pendingIntent = (PendingIntent) this.f898b.getParcelable("pendingIntent");
                }
                mo261a(new ConnectionResult(this.f897a, pendingIntent));
                return;
        }
    }

    protected abstract boolean mo262a();
}
