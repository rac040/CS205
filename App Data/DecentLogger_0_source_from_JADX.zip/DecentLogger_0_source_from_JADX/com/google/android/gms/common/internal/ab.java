package com.google.android.gms.common.internal;

import android.accounts.Account;
import android.content.Context;
import android.os.Looper;
import com.google.android.gms.common.C0186b;
import com.google.android.gms.common.api.C0129j;
import com.google.android.gms.common.api.C0150q;
import com.google.android.gms.common.api.C0151r;
import com.google.android.gms.common.api.Scope;
import java.util.Set;

public abstract class ab extends C0195j implements C0129j {
    private final C0217v f857a;
    private final Set f858h;
    private final Account f859i;

    private ab(Context context, Looper looper, ae aeVar, C0186b c0186b, C0217v c0217v, C0150q c0150q, C0151r c0151r) {
        C0197m c0197m = null;
        C0196l acVar = c0150q == null ? null : new ac(c0150q);
        if (c0151r != null) {
            c0197m = new ad(c0151r);
        }
        super(context, looper, aeVar, c0186b, acVar, c0197m, c0217v.f912d);
        this.f857a = c0217v;
        this.f859i = c0217v.f909a;
        Set<Scope> set = c0217v.f910b;
        for (Scope contains : set) {
            if (!set.contains(contains)) {
                throw new IllegalStateException("Expanding scopes is not permitted, use implied scopes instead");
            }
        }
        this.f858h = set;
    }

    public ab(Context context, Looper looper, C0217v c0217v, C0150q c0150q, C0151r c0151r) {
        this(context, looper, ae.m919a(context), C0186b.m851a(), c0217v, (C0150q) C0200d.m1039a((Object) c0150q), (C0151r) C0200d.m1039a((Object) c0151r));
    }

    public final Account mo203f() {
        return this.f859i;
    }
}
