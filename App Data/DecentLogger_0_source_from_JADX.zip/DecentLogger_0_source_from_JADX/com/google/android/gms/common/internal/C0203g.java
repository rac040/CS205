package com.google.android.gms.common.internal;

import android.os.IBinder;
import android.os.IInterface;
import com.google.android.gms.common.api.C0174l;

public final class C0203g extends ab {
    public final C0174l f893a;

    protected final IInterface mo257a(IBinder iBinder) {
        return this.f893a.m842c();
    }

    protected final String mo258d() {
        return this.f893a.m840a();
    }

    protected final String mo259e() {
        return this.f893a.m841b();
    }
}
