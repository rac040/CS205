package com.google.android.gms.common.internal;

import android.os.IBinder;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;

public class ResolveAccountResponse extends AbstractSafeParcelable {
    public static final Creator CREATOR = new C0202f();
    final int f821a;
    IBinder f822b;
    ConnectionResult f823c;
    boolean f824d;
    boolean f825e;

    ResolveAccountResponse(int i, IBinder iBinder, ConnectionResult connectionResult, boolean z, boolean z2) {
        this.f821a = i;
        this.f822b = iBinder;
        this.f823c = connectionResult;
        this.f824d = z;
        this.f825e = z2;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof ResolveAccountResponse)) {
            return false;
        }
        ResolveAccountResponse resolveAccountResponse = (ResolveAccountResponse) obj;
        return this.f823c.equals(resolveAccountResponse.f823c) && al.m883a(this.f822b).equals(al.m883a(resolveAccountResponse.f822b));
    }

    public void writeToParcel(Parcel parcel, int i) {
        C0202f.m1045a(this, parcel, i);
    }
}
