package com.google.android.gms.common.internal;

import android.accounts.Account;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.common.internal.safeparcel.C0212a;
import com.google.android.gms.common.internal.safeparcel.C0213b;
import com.google.android.gms.common.internal.safeparcel.C0214c;

public final class C0201e implements Creator {
    static void m1044a(ResolveAccountRequest resolveAccountRequest, Parcel parcel, int i) {
        int a = C0214c.m1078a(parcel, 20293);
        C0214c.m1079a(parcel, 1, resolveAccountRequest.f817a);
        C0214c.m1083a(parcel, 2, resolveAccountRequest.f818b, i);
        C0214c.m1079a(parcel, 3, resolveAccountRequest.f819c);
        C0214c.m1083a(parcel, 4, resolveAccountRequest.f820d, i);
        C0214c.m1090b(parcel, a);
    }

    public final /* synthetic */ Object createFromParcel(Parcel parcel) {
        int a = C0212a.m1064a(parcel);
        int i = 0;
        Account account = null;
        int i2 = 0;
        GoogleSignInAccount googleSignInAccount = null;
        while (parcel.dataPosition() < a) {
            int readInt = parcel.readInt();
            switch (65535 & readInt) {
                case 1:
                    i2 = C0212a.m1070c(parcel, readInt);
                    break;
                case 2:
                    account = (Account) C0212a.m1065a(parcel, readInt, Account.CREATOR);
                    break;
                case 3:
                    i = C0212a.m1070c(parcel, readInt);
                    break;
                case 4:
                    googleSignInAccount = (GoogleSignInAccount) C0212a.m1065a(parcel, readInt, GoogleSignInAccount.CREATOR);
                    break;
                default:
                    C0212a.m1066a(parcel, readInt);
                    break;
            }
        }
        if (parcel.dataPosition() == a) {
            return new ResolveAccountRequest(i2, account, i, googleSignInAccount);
        }
        throw new C0213b("Overread allowed size end=" + a, parcel);
    }

    public final /* synthetic */ Object[] newArray(int i) {
        return new ResolveAccountRequest[i];
    }
}
