package com.google.android.gms.common.internal;

import android.os.Bundle;
import android.os.IBinder;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.api.Scope;
import com.google.android.gms.common.internal.safeparcel.C0212a;
import com.google.android.gms.common.internal.safeparcel.C0213b;
import com.google.android.gms.common.internal.safeparcel.C0214c;

public final class C0204h implements Creator {
    static void m1049a(ValidateAccountRequest validateAccountRequest, Parcel parcel, int i) {
        int a = C0214c.m1078a(parcel, 20293);
        C0214c.m1079a(parcel, 1, validateAccountRequest.f826a);
        C0214c.m1079a(parcel, 2, validateAccountRequest.f827b);
        C0214c.m1082a(parcel, 3, validateAccountRequest.f828c);
        C0214c.m1088a(parcel, 4, validateAccountRequest.f829d, i);
        C0214c.m1081a(parcel, 5, validateAccountRequest.f830e);
        C0214c.m1085a(parcel, 6, validateAccountRequest.f831f);
        C0214c.m1090b(parcel, a);
    }

    public final /* synthetic */ Object createFromParcel(Parcel parcel) {
        int i = 0;
        String str = null;
        int a = C0212a.m1064a(parcel);
        Bundle bundle = null;
        Scope[] scopeArr = null;
        IBinder iBinder = null;
        int i2 = 0;
        while (parcel.dataPosition() < a) {
            int readInt = parcel.readInt();
            switch (65535 & readInt) {
                case 1:
                    i2 = C0212a.m1070c(parcel, readInt);
                    break;
                case 2:
                    i = C0212a.m1070c(parcel, readInt);
                    break;
                case 3:
                    iBinder = C0212a.m1075g(parcel, readInt);
                    break;
                case 4:
                    scopeArr = (Scope[]) C0212a.m1069b(parcel, readInt, Scope.CREATOR);
                    break;
                case 5:
                    bundle = C0212a.m1076h(parcel, readInt);
                    break;
                case 6:
                    str = C0212a.m1074f(parcel, readInt);
                    break;
                default:
                    C0212a.m1066a(parcel, readInt);
                    break;
            }
        }
        if (parcel.dataPosition() == a) {
            return new ValidateAccountRequest(i2, i, iBinder, scopeArr, bundle, str);
        }
        throw new C0213b("Overread allowed size end=" + a, parcel);
    }

    public final /* synthetic */ Object[] newArray(int i) {
        return new ValidateAccountRequest[i];
    }
}
