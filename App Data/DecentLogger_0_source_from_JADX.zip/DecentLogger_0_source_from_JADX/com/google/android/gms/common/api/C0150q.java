package com.google.android.gms.common.api;

public interface C0150q {
    void mo186a();

    void mo188b();
}
