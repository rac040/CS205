package com.google.android.gms.common.internal;

import com.google.android.gms.common.api.C0150q;

final class ac implements C0196l {
    final /* synthetic */ C0150q f860a;

    ac(C0150q c0150q) {
        this.f860a = c0150q;
    }

    public final void mo204a() {
        this.f860a.mo186a();
    }

    public final void mo205b() {
        this.f860a.mo188b();
    }
}
