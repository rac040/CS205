package com.google.android.gms.common.internal;

public final class C0198b {
    public static C0199c m1036a(Object obj) {
        return new C0199c(obj);
    }

    public static boolean m1037a(Object obj, Object obj2) {
        return obj == obj2 || (obj != null && obj.equals(obj2));
    }
}
