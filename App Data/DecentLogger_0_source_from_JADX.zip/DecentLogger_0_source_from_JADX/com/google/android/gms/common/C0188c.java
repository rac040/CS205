package com.google.android.gms.common;

import android.app.Notification;
import android.app.Notification.BigTextStyle;
import android.app.Notification.Builder;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.res.Resources;
import android.os.Build.VERSION;
import android.support.v4.app.bb;
import com.google.android.gms.C0162b;
import com.google.android.gms.C0163c;
import com.google.android.gms.common.internal.C0219x;
import com.google.android.gms.common.util.C0230d;
import com.google.android.gms.common.util.C0232f;

public final class C0188c extends C0187n {
    @Deprecated
    public static final int f799a = C0187n.f791b;

    public static Resources m868a(Context context) {
        return C0187n.m866d(context);
    }

    static void m869a(int i, Context context, PendingIntent pendingIntent) {
        Notification notification;
        boolean z;
        int i2;
        Resources resources = context.getResources();
        String e = C0187n.m867e(context);
        CharSequence b = C0219x.m1098b(context, i);
        if (b == null) {
            b = resources.getString(C0163c.common_google_play_services_notification_ticker);
        }
        CharSequence b2 = C0219x.m1099b(context, i, e);
        if (!C0230d.m1113a(context)) {
            CharSequence string = resources.getString(C0163c.common_google_play_services_notification_ticker);
            if (C0232f.m1115a(11)) {
                Notification build;
                Builder autoCancel = new Builder(context).setSmallIcon(17301642).setContentTitle(b).setContentText(b2).setContentIntent(pendingIntent).setTicker(string).setAutoCancel(true);
                if (C0232f.m1115a(20)) {
                    autoCancel.setLocalOnly(true);
                }
                if (C0232f.m1115a(16)) {
                    autoCancel.setStyle(new BigTextStyle().bigText(b2));
                    build = autoCancel.build();
                } else {
                    build = autoCancel.getNotification();
                }
                if (VERSION.SDK_INT == 19) {
                    build.extras.putBoolean("android.support.localOnly", true);
                }
                notification = build;
            } else {
                bb a = new bb(context).m91a(17301642).m95c(string).m92a(System.currentTimeMillis());
                Notification notification2 = a.f136F;
                notification2.flags |= 16;
                a.f141d = pendingIntent;
                notification = a.m93a(b).m94b(b2).m90a();
            }
        } else if (C0232f.m1115a(16)) {
            notification = new Builder(context).setSmallIcon(C0162b.common_ic_googleplayservices).setPriority(2).setAutoCancel(true).setStyle(new BigTextStyle().bigText(new StringBuilder((String.valueOf(b).length() + 1) + String.valueOf(b2).length()).append(b).append(" ").append(b2).toString())).addAction(C0162b.common_full_open_on_phone, resources.getString(C0163c.common_open_on_phone), pendingIntent).build();
        } else {
            throw new IllegalStateException();
        }
        switch (i) {
            case 1:
            case 2:
            case 3:
            case 18:
            case 42:
                z = true;
                break;
            default:
                z = false;
                break;
        }
        if (z) {
            f.set(false);
            i2 = 10436;
        } else {
            i2 = 39789;
        }
        ((NotificationManager) context.getSystemService("notification")).notify(i2, notification);
    }
}
