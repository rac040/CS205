package com.google.android.gms.common.util;

import android.annotation.TargetApi;
import android.content.Context;

public final class C0230d {
    public static Boolean f930a;
    public static Boolean f931b;
    private static Boolean f932c;

    @TargetApi(20)
    public static boolean m1113a(Context context) {
        if (f932c == null) {
            boolean z = C0232f.m1115a(20) && context.getPackageManager().hasSystemFeature("android.hardware.type.watch");
            f932c = Boolean.valueOf(z);
        }
        return f932c.booleanValue();
    }
}
