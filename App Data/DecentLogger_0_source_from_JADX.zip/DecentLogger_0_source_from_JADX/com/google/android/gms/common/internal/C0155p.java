package com.google.android.gms.common.internal;

import com.google.android.gms.common.ConnectionResult;

public interface C0155p {
    void mo190a(ConnectionResult connectionResult);
}
