package com.google.android.gms.common.internal;

import android.os.Bundle;
import android.os.IBinder;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.api.Scope;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;

@Deprecated
public class ValidateAccountRequest extends AbstractSafeParcelable {
    public static final Creator CREATOR = new C0204h();
    final int f826a;
    final int f827b;
    final IBinder f828c;
    final Scope[] f829d;
    final Bundle f830e;
    final String f831f;

    ValidateAccountRequest(int i, int i2, IBinder iBinder, Scope[] scopeArr, Bundle bundle, String str) {
        this.f826a = i;
        this.f827b = i2;
        this.f828c = iBinder;
        this.f829d = scopeArr;
        this.f830e = bundle;
        this.f831f = str;
    }

    public void writeToParcel(Parcel parcel, int i) {
        C0204h.m1049a(this, parcel, i);
    }
}
