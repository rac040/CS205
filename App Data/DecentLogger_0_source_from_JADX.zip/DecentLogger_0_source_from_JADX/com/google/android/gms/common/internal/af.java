package com.google.android.gms.common.internal;

import android.content.Context;
import android.content.ServiceConnection;
import android.os.Handler;
import android.os.Handler.Callback;
import android.os.Message;
import com.google.android.gms.common.p007a.C0164a;
import java.util.HashMap;

final class af extends ae implements Callback {
    private final HashMap f864a = new HashMap();
    private final Context f865b;
    private final Handler f866c;
    private final C0164a f867d;
    private final long f868e;

    af(Context context) {
        this.f865b = context.getApplicationContext();
        this.f866c = new Handler(context.getMainLooper(), this);
        this.f867d = C0164a.m830a();
        this.f868e = 5000;
    }

    private boolean m923a(ag agVar, ServiceConnection serviceConnection) {
        boolean z;
        C0200d.m1040a((Object) serviceConnection, (Object) "ServiceConnection must not be null");
        synchronized (this.f864a) {
            ah ahVar = (ah) this.f864a.get(agVar);
            if (ahVar != null) {
                this.f866c.removeMessages(0, ahVar);
                if (!ahVar.m932b(serviceConnection)) {
                    ahVar.m930a(serviceConnection);
                    switch (ahVar.f874c) {
                        case 1:
                            serviceConnection.onServiceConnected(ahVar.f878g, ahVar.f876e);
                            break;
                        case 2:
                            ahVar.m929a();
                            break;
                        default:
                            break;
                    }
                }
                String valueOf = String.valueOf(agVar);
                throw new IllegalStateException(new StringBuilder(String.valueOf(valueOf).length() + 81).append("Trying to bind a GmsServiceConnection that was already connected before.  config=").append(valueOf).toString());
            }
            ahVar = new ah(this, agVar);
            ahVar.m930a(serviceConnection);
            ahVar.m929a();
            this.f864a.put(agVar, ahVar);
            z = ahVar.f875d;
        }
        return z;
    }

    public final boolean mo207a(String str, String str2, ServiceConnection serviceConnection) {
        return m923a(new ag(str, str2), serviceConnection);
    }

    public final void mo208b(String str, String str2, ServiceConnection serviceConnection) {
        ag agVar = new ag(str, str2);
        C0200d.m1040a((Object) serviceConnection, (Object) "ServiceConnection must not be null");
        synchronized (this.f864a) {
            ah ahVar = (ah) this.f864a.get(agVar);
            String valueOf;
            if (ahVar == null) {
                valueOf = String.valueOf(agVar);
                throw new IllegalStateException(new StringBuilder(String.valueOf(valueOf).length() + 50).append("Nonexistent connection status for service config: ").append(valueOf).toString());
            } else if (ahVar.m932b(serviceConnection)) {
                C0164a.m831a(serviceConnection);
                ahVar.f873b.remove(serviceConnection);
                if (ahVar.m931b()) {
                    this.f866c.sendMessageDelayed(this.f866c.obtainMessage(0, ahVar), this.f868e);
                }
            } else {
                valueOf = String.valueOf(agVar);
                throw new IllegalStateException(new StringBuilder(String.valueOf(valueOf).length() + 76).append("Trying to unbind a GmsServiceConnection  that was not bound before.  config=").append(valueOf).toString());
            }
        }
    }

    public final boolean handleMessage(Message message) {
        switch (message.what) {
            case 0:
                ah ahVar = (ah) message.obj;
                synchronized (this.f864a) {
                    if (ahVar.m931b()) {
                        if (ahVar.f875d) {
                            C0164a.m832a(ahVar.f879h.f865b, ahVar.f872a);
                            ahVar.f875d = false;
                            ahVar.f874c = 2;
                        }
                        this.f864a.remove(ahVar.f877f);
                    }
                }
                return true;
            default:
                return false;
        }
    }
}
