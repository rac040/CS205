package com.google.android.gms.common.internal;

import android.accounts.Account;
import android.content.Context;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.DeadObjectException;
import android.os.Handler;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Looper;
import android.util.Log;
import com.google.android.gms.common.C0185f;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.Scope;
import java.util.ArrayList;
import java.util.Set;
import java.util.concurrent.atomic.AtomicInteger;

public abstract class C0195j {
    public static final String[] f833g = new String[]{"service_esmobile", "service_googleme"};
    private long f834a;
    int f835b;
    long f836c;
    public final Context f837d;
    final Handler f838e;
    protected AtomicInteger f839f = new AtomicInteger(0);
    private int f840h;
    private long f841i;
    private final Looper f842j;
    private final ae f843k;
    private final C0185f f844l;
    private final Object f845m = new Object();
    private final Object f846n = new Object();
    private at f847o;
    private C0155p f848p;
    private IInterface f849q;
    private final ArrayList f850r = new ArrayList();
    private C0210r f851s;
    private int f852t = 1;
    private final C0196l f853u;
    private final C0197m f854v;
    private final int f855w;
    private final String f856x;

    protected C0195j(Context context, Looper looper, ae aeVar, C0185f c0185f, C0196l c0196l, C0197m c0197m, String str) {
        this.f837d = (Context) C0200d.m1040a((Object) context, (Object) "Context must not be null");
        this.f842j = (Looper) C0200d.m1040a((Object) looper, (Object) "Looper must not be null");
        this.f843k = (ae) C0200d.m1040a((Object) aeVar, (Object) "Supervisor must not be null");
        this.f844l = (C0185f) C0200d.m1040a((Object) c0185f, (Object) "API availability must not be null");
        this.f838e = new C0208n(this, looper);
        this.f855w = 44;
        this.f853u = c0196l;
        this.f854v = c0197m;
        this.f856x = str;
    }

    private void m889a(int i, IInterface iInterface) {
        Object obj = 1;
        if ((i == 3 ? 1 : null) != (iInterface != null ? 1 : null)) {
            obj = null;
        }
        if (obj == null) {
            throw new IllegalArgumentException();
        }
        synchronized (this.f845m) {
            this.f852t = i;
            this.f849q = iInterface;
            ServiceConnection serviceConnection;
            switch (i) {
                case 1:
                    if (this.f851s != null) {
                        serviceConnection = this.f851s;
                        m898j();
                        this.f843k.mo208b(mo258d(), "com.google.android.gms", serviceConnection);
                        this.f851s = null;
                        break;
                    }
                    break;
                case 2:
                    String valueOf;
                    String valueOf2;
                    if (this.f851s != null) {
                        valueOf = String.valueOf(mo258d());
                        valueOf2 = String.valueOf("com.google.android.gms");
                        Log.e("GmsClient", new StringBuilder((String.valueOf(valueOf).length() + 70) + String.valueOf(valueOf2).length()).append("Calling connect() while still connected, missing disconnect() for ").append(valueOf).append(" on ").append(valueOf2).toString());
                        serviceConnection = this.f851s;
                        m898j();
                        this.f843k.mo208b(mo258d(), "com.google.android.gms", serviceConnection);
                        this.f839f.incrementAndGet();
                    }
                    this.f851s = new C0210r(this, this.f839f.get());
                    serviceConnection = this.f851s;
                    m898j();
                    if (!this.f843k.mo207a(mo258d(), "com.google.android.gms", serviceConnection)) {
                        valueOf = String.valueOf(mo258d());
                        valueOf2 = String.valueOf("com.google.android.gms");
                        Log.e("GmsClient", new StringBuilder((String.valueOf(valueOf).length() + 34) + String.valueOf(valueOf2).length()).append("unable to connect to service: ").append(valueOf).append(" on ").append(valueOf2).toString());
                        m901a(16, this.f839f.get());
                        break;
                    }
                    break;
                case 3:
                    this.f834a = System.currentTimeMillis();
                    break;
            }
        }
    }

    private boolean m891a(int i, int i2, IInterface iInterface) {
        boolean z;
        synchronized (this.f845m) {
            if (this.f852t != i) {
                z = false;
            } else {
                m889a(i2, iInterface);
                z = true;
            }
        }
        return z;
    }

    public static Bundle m897h() {
        return null;
    }

    private String m898j() {
        return this.f856x == null ? this.f837d.getClass().getName() : this.f856x;
    }

    public abstract IInterface mo257a(IBinder iBinder);

    public final void m900a() {
        this.f839f.incrementAndGet();
        synchronized (this.f850r) {
            int size = this.f850r.size();
            for (int i = 0; i < size; i++) {
                ((C0206o) this.f850r.get(i)).m1054d();
            }
            this.f850r.clear();
        }
        synchronized (this.f846n) {
            this.f847o = null;
        }
        m889a(1, null);
    }

    protected final void m901a(int i, int i2) {
        this.f838e.sendMessage(this.f838e.obtainMessage(5, i2, -1, new C0215t(this, i)));
    }

    protected final void m902a(ConnectionResult connectionResult) {
        this.f840h = connectionResult.f709c;
        this.f841i = System.currentTimeMillis();
    }

    public final void m903a(C0155p c0155p) {
        this.f848p = (C0155p) C0200d.m1040a((Object) c0155p, (Object) "Connection progress callbacks cannot be null.");
        m889a(2, null);
    }

    public final void m904a(Set set) {
        try {
            Bundle g = mo280g();
            GetServiceRequest getServiceRequest = new GetServiceRequest(this.f855w);
            getServiceRequest.f811d = this.f837d.getPackageName();
            getServiceRequest.f814g = g;
            if (set != null) {
                getServiceRequest.f813f = (Scope[]) set.toArray(new Scope[set.size()]);
            }
            if (mo281i()) {
                getServiceRequest.f815h = mo203f() != null ? mo203f() : new Account("<<default account>>", "com.google");
            }
            synchronized (this.f846n) {
                if (this.f847o != null) {
                    this.f847o.mo223a(new C0209q(this, this.f839f.get()), getServiceRequest);
                } else {
                    Log.w("GmsClient", "mServiceBroker is null, client disconnected");
                }
            }
        } catch (DeadObjectException e) {
            Log.w("GmsClient", "service died");
            this.f838e.sendMessage(this.f838e.obtainMessage(4, this.f839f.get(), 1));
        } catch (Throwable e2) {
            Log.w("GmsClient", "Remote exception occurred", e2);
        }
    }

    public final boolean m905b() {
        boolean z;
        synchronized (this.f845m) {
            z = this.f852t == 3;
        }
        return z;
    }

    public final boolean m906c() {
        boolean z;
        synchronized (this.f845m) {
            z = this.f852t == 2;
        }
        return z;
    }

    public abstract String mo258d();

    public abstract String mo259e();

    public Account mo203f() {
        return null;
    }

    public Bundle mo280g() {
        return new Bundle();
    }

    public boolean mo281i() {
        return false;
    }
}
