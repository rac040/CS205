package com.google.android.gms.common.p007a;

import android.support.v4.p002c.C0034l;

public final class C0168e {
    private final long f738a;
    private final int f739b;
    private final C0034l f740c;

    public C0168e() {
        this.f738a = 60000;
        this.f739b = 10;
        this.f740c = new C0034l(10);
    }

    public C0168e(long j) {
        this.f738a = j;
        this.f739b = 1024;
        this.f740c = new C0034l();
    }
}
