package com.google.android.gms.common.util;

public final class C0229c implements C0228b {
    private static C0229c f929a;

    public static synchronized C0228b m1112a() {
        C0228b c0228b;
        synchronized (C0229c.class) {
            if (f929a == null) {
                f929a = new C0229c();
            }
            c0228b = f929a;
        }
        return c0228b;
    }
}
