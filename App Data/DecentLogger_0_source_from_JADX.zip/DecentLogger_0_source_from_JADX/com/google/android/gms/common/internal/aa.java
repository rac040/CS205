package com.google.android.gms.common.internal;

import android.accounts.Account;
import android.os.Bundle;
import android.os.IBinder;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.api.Scope;
import com.google.android.gms.common.internal.safeparcel.C0212a;
import com.google.android.gms.common.internal.safeparcel.C0213b;
import com.google.android.gms.common.internal.safeparcel.C0214c;

public final class aa implements Creator {
    static void m886a(GetServiceRequest getServiceRequest, Parcel parcel, int i) {
        int a = C0214c.m1078a(parcel, 20293);
        C0214c.m1079a(parcel, 1, getServiceRequest.f808a);
        C0214c.m1079a(parcel, 2, getServiceRequest.f809b);
        C0214c.m1079a(parcel, 3, getServiceRequest.f810c);
        C0214c.m1085a(parcel, 4, getServiceRequest.f811d);
        C0214c.m1082a(parcel, 5, getServiceRequest.f812e);
        C0214c.m1088a(parcel, 6, getServiceRequest.f813f, i);
        C0214c.m1081a(parcel, 7, getServiceRequest.f814g);
        C0214c.m1083a(parcel, 8, getServiceRequest.f815h, i);
        C0214c.m1080a(parcel, 9, getServiceRequest.f816i);
        C0214c.m1090b(parcel, a);
    }

    public final /* synthetic */ Object createFromParcel(Parcel parcel) {
        int i = 0;
        Account account = null;
        int a = C0212a.m1064a(parcel);
        long j = 0;
        Bundle bundle = null;
        Scope[] scopeArr = null;
        IBinder iBinder = null;
        String str = null;
        int i2 = 0;
        int i3 = 0;
        while (parcel.dataPosition() < a) {
            int readInt = parcel.readInt();
            switch (65535 & readInt) {
                case 1:
                    i3 = C0212a.m1070c(parcel, readInt);
                    break;
                case 2:
                    i2 = C0212a.m1070c(parcel, readInt);
                    break;
                case 3:
                    i = C0212a.m1070c(parcel, readInt);
                    break;
                case 4:
                    str = C0212a.m1074f(parcel, readInt);
                    break;
                case 5:
                    iBinder = C0212a.m1075g(parcel, readInt);
                    break;
                case 6:
                    scopeArr = (Scope[]) C0212a.m1069b(parcel, readInt, Scope.CREATOR);
                    break;
                case 7:
                    bundle = C0212a.m1076h(parcel, readInt);
                    break;
                case 8:
                    account = (Account) C0212a.m1065a(parcel, readInt, Account.CREATOR);
                    break;
                case 9:
                    j = C0212a.m1073e(parcel, readInt);
                    break;
                default:
                    C0212a.m1066a(parcel, readInt);
                    break;
            }
        }
        if (parcel.dataPosition() == a) {
            return new GetServiceRequest(i3, i2, i, str, iBinder, scopeArr, bundle, account, j);
        }
        throw new C0213b("Overread allowed size end=" + a, parcel);
    }

    public final /* synthetic */ Object[] newArray(int i) {
        return new GetServiceRequest[i];
    }
}
