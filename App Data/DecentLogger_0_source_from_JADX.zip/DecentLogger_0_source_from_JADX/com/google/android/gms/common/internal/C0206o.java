package com.google.android.gms.common.internal;

import android.util.Log;

public abstract class C0206o {
    private Object f894a;
    private boolean f895b = false;
    final /* synthetic */ C0195j f896d;

    public C0206o(C0195j c0195j, Object obj) {
        this.f896d = c0195j;
        this.f894a = obj;
    }

    protected abstract void mo260a(Object obj);

    public final void m1052b() {
        synchronized (this) {
            Object obj = this.f894a;
            if (this.f895b) {
                String valueOf = String.valueOf(this);
                Log.w("GmsClient", new StringBuilder(String.valueOf(valueOf).length() + 47).append("Callback proxy ").append(valueOf).append(" being reused. This is not safe.").toString());
            }
        }
        if (obj != null) {
            try {
                mo260a(obj);
            } catch (RuntimeException e) {
                throw e;
            }
        }
        synchronized (this) {
            this.f895b = true;
        }
        m1053c();
    }

    public final void m1053c() {
        m1054d();
        synchronized (this.f896d.f850r) {
            this.f896d.f850r.remove(this);
        }
    }

    public final void m1054d() {
        synchronized (this) {
            this.f894a = null;
        }
    }
}
