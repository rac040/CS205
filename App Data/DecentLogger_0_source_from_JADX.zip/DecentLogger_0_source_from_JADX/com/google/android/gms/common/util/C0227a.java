package com.google.android.gms.common.util;

import android.annotation.TargetApi;
import android.content.Context;
import android.content.pm.PackageManager.NameNotFoundException;
import com.google.android.gms.p006b.ae;

public final class C0227a {
    @TargetApi(12)
    public static boolean m1111a(Context context, String str) {
        if (!C0232f.m1115a(12)) {
            return false;
        }
        "com.google.android.gms".equals(str);
        try {
            return (ae.m751a(context).m748a(str, 0).flags & 2097152) != 0;
        } catch (NameNotFoundException e) {
            return false;
        }
    }
}
