package com.google.android.gms.common.internal;

import android.content.Context;
import android.content.ServiceConnection;

public abstract class ae {
    private static final Object f862a = new Object();
    private static ae f863b;

    public static ae m919a(Context context) {
        synchronized (f862a) {
            if (f863b == null) {
                f863b = new af(context.getApplicationContext());
            }
        }
        return f863b;
    }

    public abstract boolean mo207a(String str, String str2, ServiceConnection serviceConnection);

    public abstract void mo208b(String str, String str2, ServiceConnection serviceConnection);
}
