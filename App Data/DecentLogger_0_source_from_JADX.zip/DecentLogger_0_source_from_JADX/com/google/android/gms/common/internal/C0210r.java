package com.google.android.gms.common.internal;

import android.content.ComponentName;
import android.content.ServiceConnection;
import android.os.IBinder;

public final class C0210r implements ServiceConnection {
    final /* synthetic */ C0195j f903a;
    private final int f904b;

    public C0210r(C0195j c0195j, int i) {
        this.f903a = c0195j;
        this.f904b = i;
    }

    public final void onServiceConnected(ComponentName componentName, IBinder iBinder) {
        C0200d.m1040a((Object) iBinder, (Object) "Expecting a valid IBinder");
        synchronized (this.f903a.f846n) {
            this.f903a.f847o = au.m987a(iBinder);
        }
        this.f903a.m901a(0, this.f904b);
    }

    public final void onServiceDisconnected(ComponentName componentName) {
        synchronized (this.f903a.f846n) {
            this.f903a.f847o = null;
        }
        this.f903a.f838e.sendMessage(this.f903a.f838e.obtainMessage(4, this.f904b, 1));
    }
}
