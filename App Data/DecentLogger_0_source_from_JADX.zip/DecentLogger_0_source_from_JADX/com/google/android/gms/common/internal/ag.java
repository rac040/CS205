package com.google.android.gms.common.internal;

import android.content.ComponentName;
import android.content.Intent;
import java.util.Arrays;

final class ag {
    private final String f869a;
    private final String f870b;
    private final ComponentName f871c = null;

    public ag(String str, String str2) {
        this.f869a = C0200d.m1041a(str);
        this.f870b = C0200d.m1041a(str2);
    }

    public final Intent m928a() {
        return this.f869a != null ? new Intent(this.f869a).setPackage(this.f870b) : new Intent().setComponent(this.f871c);
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof ag)) {
            return false;
        }
        ag agVar = (ag) obj;
        return C0198b.m1037a(this.f869a, agVar.f869a) && C0198b.m1037a(this.f871c, agVar.f871c);
    }

    public final int hashCode() {
        return Arrays.hashCode(new Object[]{this.f869a, this.f871c});
    }

    public final String toString() {
        return this.f869a == null ? this.f871c.flattenToString() : this.f869a;
    }
}
