package com.google.android.gms.common.internal;

import android.os.IBinder;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.api.Scope;
import com.google.android.gms.common.internal.safeparcel.C0212a;
import com.google.android.gms.common.internal.safeparcel.C0213b;
import com.google.android.gms.common.internal.safeparcel.C0214c;

public final class C0205i implements Creator {
    static void m1050a(AuthAccountRequest authAccountRequest, Parcel parcel, int i) {
        int a = C0214c.m1078a(parcel, 20293);
        C0214c.m1079a(parcel, 1, authAccountRequest.f803a);
        C0214c.m1082a(parcel, 2, authAccountRequest.f804b);
        C0214c.m1088a(parcel, 3, authAccountRequest.f805c, i);
        C0214c.m1084a(parcel, 4, authAccountRequest.f806d);
        C0214c.m1084a(parcel, 5, authAccountRequest.f807e);
        C0214c.m1090b(parcel, a);
    }

    public final /* synthetic */ Object createFromParcel(Parcel parcel) {
        Integer num = null;
        int a = C0212a.m1064a(parcel);
        int i = 0;
        Integer num2 = null;
        Scope[] scopeArr = null;
        IBinder iBinder = null;
        while (parcel.dataPosition() < a) {
            int readInt = parcel.readInt();
            switch (65535 & readInt) {
                case 1:
                    i = C0212a.m1070c(parcel, readInt);
                    break;
                case 2:
                    iBinder = C0212a.m1075g(parcel, readInt);
                    break;
                case 3:
                    scopeArr = (Scope[]) C0212a.m1069b(parcel, readInt, Scope.CREATOR);
                    break;
                case 4:
                    num2 = C0212a.m1072d(parcel, readInt);
                    break;
                case 5:
                    num = C0212a.m1072d(parcel, readInt);
                    break;
                default:
                    C0212a.m1066a(parcel, readInt);
                    break;
            }
        }
        if (parcel.dataPosition() == a) {
            return new AuthAccountRequest(i, iBinder, scopeArr, num2, num);
        }
        throw new C0213b("Overread allowed size end=" + a, parcel);
    }

    public final /* synthetic */ Object[] newArray(int i) {
        return new AuthAccountRequest[i];
    }
}
