package com.google.android.gms.common.internal;

import android.os.IInterface;

public interface aw extends IInterface {
    void mo256a(ResolveAccountResponse resolveAccountResponse);
}
