package com.google.android.gms.common.api;

import android.support.v4.p002c.C0035a;
import com.google.android.gms.common.ConnectionResult;

public final class C0182w extends C0181x {
    private final ConnectionResult f781a;

    public C0182w(Status status) {
        C0035a c0035a = null;
        super(status);
        this.f781a = (ConnectionResult) c0035a.get(c0035a.m305b(0));
    }
}
