package com.google.android.gms.common;

import android.annotation.TargetApi;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageInstaller.SessionInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.content.res.Resources;
import android.os.Build;
import android.os.Bundle;
import android.os.UserManager;
import android.text.TextUtils;
import android.util.Log;
import com.google.android.gms.C0163c;
import com.google.android.gms.common.internal.C0216u;
import com.google.android.gms.common.util.C0230d;
import com.google.android.gms.common.util.C0231e;
import com.google.android.gms.common.util.C0232f;
import com.google.android.gms.common.util.C0233g;
import com.google.android.gms.p006b.ae;
import java.util.concurrent.atomic.AtomicBoolean;

public class C0187n {
    private static String f790a = null;
    @Deprecated
    public static final int f791b = C0216u.f908a;
    public static boolean f792c = false;
    public static boolean f793d = false;
    static boolean f794e = false;
    static final AtomicBoolean f795f = new AtomicBoolean();
    private static int f796g = 0;
    private static boolean f797h = false;
    private static final AtomicBoolean f798i = new AtomicBoolean();

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private static void m859a(android.content.Context r6) {
        /*
        r5 = 1;
        r0 = f797h;
        if (r0 != 0) goto L_0x0036;
    L_0x0005:
        r0 = r6.getPackageName();	 Catch:{ NameNotFoundException -> 0x003b }
        f790a = r0;	 Catch:{ NameNotFoundException -> 0x003b }
        r0 = com.google.android.gms.p006b.ae.m751a(r6);	 Catch:{ NameNotFoundException -> 0x003b }
        r1 = com.google.android.gms.common.internal.az.m1035a(r6);	 Catch:{ NameNotFoundException -> 0x003b }
        f796g = r1;	 Catch:{ NameNotFoundException -> 0x003b }
        r1 = "com.google.android.gms";
        r0 = r0.m749a(r1);	 Catch:{ NameNotFoundException -> 0x003b }
        if (r0 == 0) goto L_0x0037;
    L_0x001d:
        com.google.android.gms.common.C0226o.m1109a(r6);	 Catch:{ NameNotFoundException -> 0x003b }
        r1 = 1;
        r1 = new com.google.android.gms.common.C0192h[r1];	 Catch:{ NameNotFoundException -> 0x003b }
        r2 = 0;
        r3 = com.google.android.gms.common.C0223k.f926a;	 Catch:{ NameNotFoundException -> 0x003b }
        r4 = 1;
        r3 = r3[r4];	 Catch:{ NameNotFoundException -> 0x003b }
        r1[r2] = r3;	 Catch:{ NameNotFoundException -> 0x003b }
        r0 = com.google.android.gms.common.C0226o.m1108a(r0, r1);	 Catch:{ NameNotFoundException -> 0x003b }
        if (r0 == 0) goto L_0x0037;
    L_0x0031:
        r0 = 1;
        f794e = r0;	 Catch:{ NameNotFoundException -> 0x003b }
    L_0x0034:
        f797h = r5;
    L_0x0036:
        return;
    L_0x0037:
        r0 = 0;
        f794e = r0;	 Catch:{ NameNotFoundException -> 0x003b }
        goto L_0x0034;
    L_0x003b:
        r0 = move-exception;
        r1 = "GooglePlayServicesUtil";
        r2 = "Cannot find Google Play services package name.";
        android.util.Log.w(r1, r2, r0);	 Catch:{ all -> 0x0046 }
        f797h = r5;
        goto L_0x0036;
    L_0x0046:
        r0 = move-exception;
        f797h = r5;
        throw r0;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.common.n.a(android.content.Context):void");
    }

    @Deprecated
    public static boolean m860a(int i) {
        return C0233g.m1116a(i);
    }

    @Deprecated
    public static boolean m861a(Context context, int i) {
        return i == 18 ? true : i == 1 ? C0187n.m862a(context, "com.google.android.gms") : false;
    }

    @TargetApi(21)
    private static boolean m862a(Context context, String str) {
        boolean equals = str.equals("com.google.android.gms");
        if (C0232f.m1115a(21)) {
            for (SessionInfo appPackageName : context.getPackageManager().getPackageInstaller().getAllSessions()) {
                if (str.equals(appPackageName.getAppPackageName())) {
                    return true;
                }
            }
        }
        try {
            ApplicationInfo applicationInfo = context.getPackageManager().getApplicationInfo(str, 8192);
            if (equals) {
                return applicationInfo.enabled;
            }
            if (applicationInfo.enabled) {
                Object obj;
                if (C0232f.m1115a(18)) {
                    Bundle applicationRestrictions = ((UserManager) context.getSystemService("user")).getApplicationRestrictions(context.getPackageName());
                    if (applicationRestrictions != null && "true".equals(applicationRestrictions.getString("restricted_profile"))) {
                        obj = 1;
                        if (obj == null) {
                            return true;
                        }
                    }
                }
                obj = null;
                if (obj == null) {
                    return true;
                }
            }
            return false;
        } catch (NameNotFoundException e) {
            return false;
        }
    }

    @Deprecated
    public static int m863b(Context context) {
        PackageManager packageManager = context.getPackageManager();
        try {
            context.getResources().getString(C0163c.common_google_play_services_unknown_issue);
        } catch (Throwable th) {
            Log.e("GooglePlayServicesUtil", "The Google Play services resources were not found. Check your project configuration to ensure that the resources are included.");
        }
        if (!("com.google.android.gms".equals(context.getPackageName()) || f798i.get())) {
            C0187n.m859a(context);
            if (f796g == 0) {
                throw new IllegalStateException("A required meta-data tag in your app's AndroidManifest.xml does not exist.  You must have the following declaration within the <application> element:     <meta-data android:name=\"com.google.android.gms.version\" android:value=\"@integer/google_play_services_version\" />");
            } else if (f796g != f791b) {
                int i = f791b;
                int i2 = f796g;
                String valueOf = String.valueOf("com.google.android.gms.version");
                throw new IllegalStateException(new StringBuilder(String.valueOf(valueOf).length() + 290).append("The meta-data tag in your app's AndroidManifest.xml does not have the right value.  Expected ").append(i).append(" but found ").append(i2).append(".  You must have the following declaration within the <application> element:     <meta-data android:name=\"").append(valueOf).append("\" android:value=\"@integer/google_play_services_version\" />").toString());
            }
        }
        int i3 = !C0230d.m1113a(context) ? 1 : 0;
        PackageInfo packageInfo = null;
        if (i3 != 0) {
            try {
                packageInfo = packageManager.getPackageInfo("com.android.vending", 8256);
            } catch (NameNotFoundException e) {
                Log.w("GooglePlayServicesUtil", "Google Play Store is missing.");
                return 9;
            }
        }
        try {
            PackageInfo packageInfo2 = packageManager.getPackageInfo("com.google.android.gms", 64);
            C0226o.m1109a(context);
            if (i3 != 0) {
                if (C0226o.m1108a(packageInfo, C0223k.f926a) == null) {
                    Log.w("GooglePlayServicesUtil", "Google Play Store signature invalid.");
                    return 9;
                }
                if (C0226o.m1108a(packageInfo2, C0226o.m1108a(packageInfo, C0223k.f926a)) == null) {
                    Log.w("GooglePlayServicesUtil", "Google Play services signature invalid.");
                    return 9;
                }
            } else if (C0226o.m1108a(packageInfo2, C0223k.f926a) == null) {
                Log.w("GooglePlayServicesUtil", "Google Play services signature invalid.");
                return 9;
            }
            if (C0231e.m1114a(packageInfo2.versionCode) < C0231e.m1114a(f791b)) {
                Log.w("GooglePlayServicesUtil", "Google Play services out of date.  Requires " + f791b + " but found " + packageInfo2.versionCode);
                return 2;
            }
            ApplicationInfo applicationInfo = packageInfo2.applicationInfo;
            if (applicationInfo == null) {
                try {
                    applicationInfo = packageManager.getApplicationInfo("com.google.android.gms", 0);
                } catch (Throwable e2) {
                    Log.wtf("GooglePlayServicesUtil", "Google Play services missing when getting application info.", e2);
                    return 1;
                }
            }
            return !applicationInfo.enabled ? 3 : 0;
        } catch (NameNotFoundException e3) {
            Log.w("GooglePlayServicesUtil", "Google Play services is missing.");
            return 1;
        }
    }

    @Deprecated
    public static boolean m864b(int i) {
        switch (i) {
            case 1:
            case 2:
            case 3:
            case 9:
                return true;
            default:
                return false;
        }
    }

    public static boolean m865c(Context context) {
        C0187n.m859a(context);
        return f794e || !"user".equals(Build.TYPE);
    }

    public static Resources m866d(Context context) {
        try {
            return context.getPackageManager().getResourcesForApplication("com.google.android.gms");
        } catch (NameNotFoundException e) {
            return null;
        }
    }

    public static String m867e(Context context) {
        Object obj = context.getApplicationInfo().name;
        if (!TextUtils.isEmpty(obj)) {
            return obj;
        }
        ApplicationInfo a;
        String packageName = context.getPackageName();
        PackageManager packageManager = context.getApplicationContext().getPackageManager();
        try {
            a = ae.m751a(context).m748a(context.getPackageName(), 0);
        } catch (NameNotFoundException e) {
            a = null;
        }
        return a != null ? packageManager.getApplicationLabel(a).toString() : packageName;
    }
}
