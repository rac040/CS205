package com.google.android.gms.common.internal.safeparcel;

import android.os.Bundle;
import android.os.IBinder;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import java.util.ArrayList;

public final class C0212a {
    public static int m1064a(Parcel parcel) {
        int readInt = parcel.readInt();
        int i = C0212a.m1077i(parcel, readInt);
        int dataPosition = parcel.dataPosition();
        if ((65535 & readInt) != 20293) {
            String str = "Expected object header. Got 0x";
            String valueOf = String.valueOf(Integer.toHexString(readInt));
            throw new C0213b(valueOf.length() != 0 ? str.concat(valueOf) : new String(str), parcel);
        }
        readInt = dataPosition + i;
        if (readInt >= dataPosition && readInt <= parcel.dataSize()) {
            return readInt;
        }
        throw new C0213b("Size read is invalid start=" + dataPosition + " end=" + readInt, parcel);
    }

    public static Parcelable m1065a(Parcel parcel, int i, Creator creator) {
        int i2 = C0212a.m1077i(parcel, i);
        int dataPosition = parcel.dataPosition();
        if (i2 == 0) {
            return null;
        }
        Parcelable parcelable = (Parcelable) creator.createFromParcel(parcel);
        parcel.setDataPosition(i2 + dataPosition);
        return parcelable;
    }

    public static void m1066a(Parcel parcel, int i) {
        parcel.setDataPosition(C0212a.m1077i(parcel, i) + parcel.dataPosition());
    }

    private static void m1067a(Parcel parcel, int i, int i2) {
        int i3 = C0212a.m1077i(parcel, i);
        if (i3 != i2) {
            String valueOf = String.valueOf(Integer.toHexString(i3));
            throw new C0213b(new StringBuilder(String.valueOf(valueOf).length() + 46).append("Expected size ").append(i2).append(" got ").append(i3).append(" (0x").append(valueOf).append(")").toString(), parcel);
        }
    }

    public static boolean m1068b(Parcel parcel, int i) {
        C0212a.m1067a(parcel, i, 4);
        return parcel.readInt() != 0;
    }

    public static Object[] m1069b(Parcel parcel, int i, Creator creator) {
        int i2 = C0212a.m1077i(parcel, i);
        int dataPosition = parcel.dataPosition();
        if (i2 == 0) {
            return null;
        }
        Object[] createTypedArray = parcel.createTypedArray(creator);
        parcel.setDataPosition(i2 + dataPosition);
        return createTypedArray;
    }

    public static int m1070c(Parcel parcel, int i) {
        C0212a.m1067a(parcel, i, 4);
        return parcel.readInt();
    }

    public static ArrayList m1071c(Parcel parcel, int i, Creator creator) {
        int i2 = C0212a.m1077i(parcel, i);
        int dataPosition = parcel.dataPosition();
        if (i2 == 0) {
            return null;
        }
        ArrayList createTypedArrayList = parcel.createTypedArrayList(creator);
        parcel.setDataPosition(i2 + dataPosition);
        return createTypedArrayList;
    }

    public static Integer m1072d(Parcel parcel, int i) {
        int i2 = C0212a.m1077i(parcel, i);
        if (i2 == 0) {
            return null;
        }
        if (i2 == 4) {
            return Integer.valueOf(parcel.readInt());
        }
        String valueOf = String.valueOf(Integer.toHexString(i2));
        throw new C0213b(new StringBuilder(String.valueOf(valueOf).length() + 46).append("Expected size 4 got ").append(i2).append(" (0x").append(valueOf).append(")").toString(), parcel);
    }

    public static long m1073e(Parcel parcel, int i) {
        C0212a.m1067a(parcel, i, 8);
        return parcel.readLong();
    }

    public static String m1074f(Parcel parcel, int i) {
        int i2 = C0212a.m1077i(parcel, i);
        int dataPosition = parcel.dataPosition();
        if (i2 == 0) {
            return null;
        }
        String readString = parcel.readString();
        parcel.setDataPosition(i2 + dataPosition);
        return readString;
    }

    public static IBinder m1075g(Parcel parcel, int i) {
        int i2 = C0212a.m1077i(parcel, i);
        int dataPosition = parcel.dataPosition();
        if (i2 == 0) {
            return null;
        }
        IBinder readStrongBinder = parcel.readStrongBinder();
        parcel.setDataPosition(i2 + dataPosition);
        return readStrongBinder;
    }

    public static Bundle m1076h(Parcel parcel, int i) {
        int i2 = C0212a.m1077i(parcel, i);
        int dataPosition = parcel.dataPosition();
        if (i2 == 0) {
            return null;
        }
        Bundle readBundle = parcel.readBundle();
        parcel.setDataPosition(i2 + dataPosition);
        return readBundle;
    }

    private static int m1077i(Parcel parcel, int i) {
        return (i & -65536) != -65536 ? (i >> 16) & 65535 : parcel.readInt();
    }
}
