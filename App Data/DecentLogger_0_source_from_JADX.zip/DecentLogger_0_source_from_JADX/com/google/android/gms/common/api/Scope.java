package com.google.android.gms.common.api;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import android.text.TextUtils;
import com.google.android.gms.common.internal.ReflectedParcelable;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;

public final class Scope extends AbstractSafeParcelable implements ReflectedParcelable {
    public static final Creator CREATOR = new C0184z();
    final int f744a;
    public final String f745b;

    Scope(int i, String str) {
        String str2 = "scopeUri must not be null or empty";
        if (TextUtils.isEmpty(str)) {
            throw new IllegalArgumentException(String.valueOf(str2));
        }
        this.f744a = i;
        this.f745b = str;
    }

    public Scope(String str) {
        this(1, str);
    }

    public final boolean equals(Object obj) {
        return this == obj ? true : !(obj instanceof Scope) ? false : this.f745b.equals(((Scope) obj).f745b);
    }

    public final int hashCode() {
        return this.f745b.hashCode();
    }

    public final String toString() {
        return this.f745b;
    }

    public final void writeToParcel(Parcel parcel, int i) {
        C0184z.m844a(this, parcel);
    }
}
