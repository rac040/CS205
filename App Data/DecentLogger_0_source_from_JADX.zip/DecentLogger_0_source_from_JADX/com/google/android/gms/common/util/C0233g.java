package com.google.android.gms.common.util;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager.NameNotFoundException;
import android.util.Log;
import com.google.android.gms.common.C0187n;
import com.google.android.gms.common.C0226o;
import com.google.android.gms.p006b.ae;

public final class C0233g {
    public static boolean m1116a(int i) {
        Context context = null;
        if (!ae.m751a(context).m750a(i, "com.google.android.gms")) {
            return false;
        }
        try {
            PackageInfo packageInfo = context.getPackageManager().getPackageInfo("com.google.android.gms", 64);
            C0226o a = C0226o.m1109a(context);
            context.getPackageManager();
            if (packageInfo == null) {
                return false;
            }
            if (C0226o.m1110a(packageInfo, false)) {
                return true;
            }
            if (!C0226o.m1110a(packageInfo, true)) {
                return false;
            }
            if (C0187n.m865c(a.f928a)) {
                return true;
            }
            Log.w("GoogleSignatureVerifier", "Test-keys aren't accepted on this build.");
            return false;
        } catch (NameNotFoundException e) {
            if (!Log.isLoggable("UidVerifier", 3)) {
                return false;
            }
            Log.d("UidVerifier", "Package manager can't find google play services package, defaulting to false");
            return false;
        }
    }
}
