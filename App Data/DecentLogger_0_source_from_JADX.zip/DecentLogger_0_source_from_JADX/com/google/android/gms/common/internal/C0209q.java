package com.google.android.gms.common.internal;

import android.os.Bundle;
import android.os.IBinder;
import android.util.Log;

public final class C0209q extends ar {
    private C0195j f901a;
    private final int f902b;

    public C0209q(C0195j c0195j, int i) {
        this.f901a = c0195j;
        this.f902b = i;
    }

    public final void mo209a(int i, Bundle bundle) {
        Log.wtf("GmsClient", "received deprecated onAccountValidationComplete callback, ignoring", new Exception());
    }

    public final void mo210a(int i, IBinder iBinder, Bundle bundle) {
        C0200d.m1040a(this.f901a, (Object) "onPostInitComplete can be called only once per call to getRemoteService");
        C0195j c0195j = this.f901a;
        c0195j.f838e.sendMessage(c0195j.f838e.obtainMessage(1, this.f902b, -1, new C0211s(c0195j, i, iBinder, bundle)));
        this.f901a = null;
    }
}
