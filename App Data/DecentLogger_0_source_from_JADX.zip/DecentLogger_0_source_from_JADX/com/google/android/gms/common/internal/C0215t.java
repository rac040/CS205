package com.google.android.gms.common.internal;

import com.google.android.gms.common.ConnectionResult;

public final class C0215t extends C0207k {
    final /* synthetic */ C0195j f907e;

    public C0215t(C0195j c0195j, int i) {
        this.f907e = c0195j;
        super(c0195j, i, null);
    }

    protected final void mo261a(ConnectionResult connectionResult) {
        this.f907e.f848p.mo190a(connectionResult);
        this.f907e.m902a(connectionResult);
    }

    protected final boolean mo262a() {
        this.f907e.f848p.mo190a(ConnectionResult.f707a);
        return true;
    }
}
