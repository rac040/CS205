package com.google.android.gms.common.api;

import android.support.v4.p002c.C0035a;

public class C0181x implements C0170u {
    private final Status f779a;
    private final C0035a f780b = null;

    public C0181x(Status status) {
        this.f779a = status;
    }

    public final Status mo191a() {
        return this.f779a;
    }
}
