package com.google.android.gms.common.internal;

import android.app.Activity;
import android.content.Intent;

final class C0221z extends C0220y {
    final /* synthetic */ Intent f921a;
    final /* synthetic */ Activity f922b;
    final /* synthetic */ int f923c = 2;

    C0221z(Intent intent, Activity activity) {
        this.f921a = intent;
        this.f922b = activity;
    }

    public final void mo263a() {
        if (this.f921a != null) {
            this.f922b.startActivityForResult(this.f921a, this.f923c);
        }
    }
}
