package com.google.android.gms.common.internal;

import android.app.Activity;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.util.Log;

public abstract class C0220y implements OnClickListener {
    public static C0220y m1101a(Activity activity, Intent intent) {
        return new C0221z(intent, activity);
    }

    public abstract void mo263a();

    public void onClick(DialogInterface dialogInterface, int i) {
        try {
            mo263a();
            dialogInterface.dismiss();
        } catch (Throwable e) {
            Log.e("DialogRedirect", "Can't redirect to app settings for Google Play services", e);
        }
    }
}
