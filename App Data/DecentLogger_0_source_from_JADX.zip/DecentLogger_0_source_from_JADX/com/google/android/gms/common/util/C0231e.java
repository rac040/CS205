package com.google.android.gms.common.util;

import java.util.regex.Pattern;

public final class C0231e {
    private static Pattern f933a = null;

    public static int m1114a(int i) {
        return i / 1000;
    }
}
