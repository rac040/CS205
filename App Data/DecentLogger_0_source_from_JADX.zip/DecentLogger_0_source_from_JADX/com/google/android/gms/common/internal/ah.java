package com.google.android.gms.common.internal;

import android.annotation.TargetApi;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.IBinder;
import android.util.Log;
import com.google.android.gms.common.p007a.C0164a;
import java.util.HashSet;
import java.util.Set;

final class ah {
    final ai f872a = new ai(this);
    final Set f873b = new HashSet();
    int f874c = 2;
    boolean f875d;
    IBinder f876e;
    final ag f877f;
    ComponentName f878g;
    final /* synthetic */ af f879h;

    public ah(af afVar, ag agVar) {
        this.f879h = afVar;
        this.f877f = agVar;
    }

    @TargetApi(14)
    public final void m929a() {
        boolean z;
        this.f874c = 3;
        this.f879h.f867d;
        Context b = this.f879h.f865b;
        Intent a = this.f877f.m928a();
        ServiceConnection serviceConnection = this.f872a;
        if (C0164a.m833a(b, a)) {
            Log.w("ConnectionTracker", "Attempted to bind to a service in a STOPPED package.");
            z = false;
        } else {
            z = b.bindService(a, serviceConnection, 129);
            if (z) {
                C0164a.m831a(serviceConnection);
            }
        }
        this.f875d = z;
        if (!this.f875d) {
            this.f874c = 2;
            try {
                this.f879h.f867d;
                C0164a.m832a(this.f879h.f865b, this.f872a);
            } catch (IllegalArgumentException e) {
            }
        }
    }

    public final void m930a(ServiceConnection serviceConnection) {
        this.f879h.f867d;
        this.f879h.f865b;
        this.f877f.m928a();
        C0164a.m831a(serviceConnection);
        this.f873b.add(serviceConnection);
    }

    public final boolean m931b() {
        return this.f873b.isEmpty();
    }

    public final boolean m932b(ServiceConnection serviceConnection) {
        return this.f873b.contains(serviceConnection);
    }
}
