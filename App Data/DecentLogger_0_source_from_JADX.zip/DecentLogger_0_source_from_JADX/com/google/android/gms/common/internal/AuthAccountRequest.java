package com.google.android.gms.common.internal;

import android.os.IBinder;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.api.Scope;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;

public class AuthAccountRequest extends AbstractSafeParcelable {
    public static final Creator CREATOR = new C0205i();
    final int f803a;
    final IBinder f804b;
    final Scope[] f805c;
    Integer f806d;
    Integer f807e;

    AuthAccountRequest(int i, IBinder iBinder, Scope[] scopeArr, Integer num, Integer num2) {
        this.f803a = i;
        this.f804b = iBinder;
        this.f805c = scopeArr;
        this.f806d = num;
        this.f807e = num2;
    }

    public void writeToParcel(Parcel parcel, int i) {
        C0205i.m1050a(this, parcel, i);
    }
}
