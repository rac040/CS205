package com.google.android.gms.common.internal.safeparcel;

import android.os.Bundle;
import android.os.IBinder;
import android.os.Parcel;
import android.os.Parcelable;
import java.util.List;

public final class C0214c {
    public static int m1078a(Parcel parcel, int i) {
        parcel.writeInt(-65536 | i);
        parcel.writeInt(0);
        return parcel.dataPosition();
    }

    public static void m1079a(Parcel parcel, int i, int i2) {
        C0214c.m1091b(parcel, i, 4);
        parcel.writeInt(i2);
    }

    public static void m1080a(Parcel parcel, int i, long j) {
        C0214c.m1091b(parcel, i, 8);
        parcel.writeLong(j);
    }

    public static void m1081a(Parcel parcel, int i, Bundle bundle) {
        if (bundle != null) {
            int a = C0214c.m1078a(parcel, i);
            parcel.writeBundle(bundle);
            C0214c.m1090b(parcel, a);
        }
    }

    public static void m1082a(Parcel parcel, int i, IBinder iBinder) {
        if (iBinder != null) {
            int a = C0214c.m1078a(parcel, i);
            parcel.writeStrongBinder(iBinder);
            C0214c.m1090b(parcel, a);
        }
    }

    public static void m1083a(Parcel parcel, int i, Parcelable parcelable, int i2) {
        if (parcelable != null) {
            int a = C0214c.m1078a(parcel, i);
            parcelable.writeToParcel(parcel, i2);
            C0214c.m1090b(parcel, a);
        }
    }

    public static void m1084a(Parcel parcel, int i, Integer num) {
        if (num != null) {
            C0214c.m1091b(parcel, i, 4);
            parcel.writeInt(num.intValue());
        }
    }

    public static void m1085a(Parcel parcel, int i, String str) {
        if (str != null) {
            int a = C0214c.m1078a(parcel, i);
            parcel.writeString(str);
            C0214c.m1090b(parcel, a);
        }
    }

    public static void m1086a(Parcel parcel, int i, List list) {
        if (list != null) {
            int a = C0214c.m1078a(parcel, i);
            int size = list.size();
            parcel.writeInt(size);
            for (int i2 = 0; i2 < size; i2++) {
                Parcelable parcelable = (Parcelable) list.get(i2);
                if (parcelable == null) {
                    parcel.writeInt(0);
                } else {
                    C0214c.m1089a(parcel, parcelable, 0);
                }
            }
            C0214c.m1090b(parcel, a);
        }
    }

    public static void m1087a(Parcel parcel, int i, boolean z) {
        C0214c.m1091b(parcel, i, 4);
        parcel.writeInt(z ? 1 : 0);
    }

    public static void m1088a(Parcel parcel, int i, Parcelable[] parcelableArr, int i2) {
        if (parcelableArr != null) {
            int a = C0214c.m1078a(parcel, i);
            parcel.writeInt(r3);
            for (Parcelable parcelable : parcelableArr) {
                if (parcelable == null) {
                    parcel.writeInt(0);
                } else {
                    C0214c.m1089a(parcel, parcelable, i2);
                }
            }
            C0214c.m1090b(parcel, a);
        }
    }

    private static void m1089a(Parcel parcel, Parcelable parcelable, int i) {
        int dataPosition = parcel.dataPosition();
        parcel.writeInt(1);
        int dataPosition2 = parcel.dataPosition();
        parcelable.writeToParcel(parcel, i);
        int dataPosition3 = parcel.dataPosition();
        parcel.setDataPosition(dataPosition);
        parcel.writeInt(dataPosition3 - dataPosition2);
        parcel.setDataPosition(dataPosition3);
    }

    public static void m1090b(Parcel parcel, int i) {
        int dataPosition = parcel.dataPosition();
        int i2 = dataPosition - i;
        parcel.setDataPosition(i - 4);
        parcel.writeInt(i2);
        parcel.setDataPosition(dataPosition);
    }

    private static void m1091b(Parcel parcel, int i, int i2) {
        if (i2 >= 65535) {
            parcel.writeInt(-65536 | i);
            parcel.writeInt(i2);
            return;
        }
        parcel.writeInt((i2 << 16) | i);
    }
}
