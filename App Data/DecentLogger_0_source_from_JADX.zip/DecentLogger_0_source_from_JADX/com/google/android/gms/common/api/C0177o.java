package com.google.android.gms.common.api;

import java.util.Collections;
import java.util.Set;
import java.util.WeakHashMap;

public abstract class C0177o {
    private static final Set f762a = Collections.newSetFromMap(new WeakHashMap());
}
