package com.google.android.gms.common.api;

import android.app.PendingIntent;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import android.support.wearable.C0107c;
import com.google.android.gms.common.internal.C0198b;
import com.google.android.gms.common.internal.C0199c;
import com.google.android.gms.common.internal.ReflectedParcelable;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import java.util.Arrays;

public final class Status extends AbstractSafeParcelable implements C0170u, ReflectedParcelable {
    public static final Creator CREATOR = new aa();
    public static final Status f746a = new Status(0);
    public static final Status f747b = new Status(14);
    public static final Status f748c = new Status(8);
    public static final Status f749d = new Status(15);
    public static final Status f750e = new Status(16);
    public static final Status f751f = new Status(17);
    public static final Status f752g = new Status(18);
    final int f753h;
    public final int f754i;
    final String f755j;
    final PendingIntent f756k;

    public Status(int i) {
        this(i, null);
    }

    Status(int i, int i2, String str, PendingIntent pendingIntent) {
        this.f753h = i;
        this.f754i = i2;
        this.f755j = str;
        this.f756k = pendingIntent;
    }

    public Status(int i, String str) {
        this(1, i, str, null);
    }

    public final Status mo191a() {
        return this;
    }

    public final boolean equals(Object obj) {
        if (!(obj instanceof Status)) {
            return false;
        }
        Status status = (Status) obj;
        return this.f753h == status.f753h && this.f754i == status.f754i && C0198b.m1037a(this.f755j, status.f755j) && C0198b.m1037a(this.f756k, status.f756k);
    }

    public final int hashCode() {
        return Arrays.hashCode(new Object[]{Integer.valueOf(this.f753h), Integer.valueOf(this.f754i), this.f755j, this.f756k});
    }

    public final String toString() {
        Object obj;
        C0199c a = C0198b.m1036a(this);
        String str = "statusCode";
        if (this.f755j == null) {
            int i = this.f754i;
            switch (i) {
                case -1:
                    obj = "SUCCESS_CACHE";
                    break;
                case 0:
                    obj = "SUCCESS";
                    break;
                case 2:
                    obj = "SERVICE_VERSION_UPDATE_REQUIRED";
                    break;
                case 3:
                    obj = "SERVICE_DISABLED";
                    break;
                case 4:
                    obj = "SIGN_IN_REQUIRED";
                    break;
                case 5:
                    obj = "INVALID_ACCOUNT";
                    break;
                case 6:
                    obj = "RESOLUTION_REQUIRED";
                    break;
                case 7:
                    obj = "NETWORK_ERROR";
                    break;
                case 8:
                    obj = "INTERNAL_ERROR";
                    break;
                case 10:
                    obj = "DEVELOPER_ERROR";
                    break;
                case 13:
                    obj = "ERROR";
                    break;
                case 14:
                    obj = "INTERRUPTED";
                    break;
                case C0107c.ActionPage_imageScaleMode /*15*/:
                    obj = "TIMEOUT";
                    break;
                case C0107c.ActionPage_buttonRippleColor /*16*/:
                    obj = "CANCELED";
                    break;
                case C0107c.ActionPage_pressedButtonTranslationZ /*17*/:
                    obj = "API_NOT_CONNECTED";
                    break;
                case 18:
                    obj = "DEAD_CLIENT";
                    break;
                default:
                    obj = "unknown status code: " + i;
                    break;
            }
        }
        obj = this.f755j;
        return a.m1038a(str, obj).m1038a("resolution", this.f756k).toString();
    }

    public final void writeToParcel(Parcel parcel, int i) {
        aa.m839a(this, parcel, i);
    }
}
