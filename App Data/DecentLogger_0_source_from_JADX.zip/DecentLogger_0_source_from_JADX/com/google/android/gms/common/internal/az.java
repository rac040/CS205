package com.google.android.gms.common.internal;

import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import com.google.android.gms.p006b.ae;

public final class az {
    private static Object f887a = new Object();
    private static boolean f888b;
    private static String f889c;
    private static int f890d;

    public static int m1035a(Context context) {
        synchronized (f887a) {
            if (f888b) {
            } else {
                f888b = true;
                try {
                    Bundle bundle = ae.m751a(context).m748a(context.getPackageName(), 128).metaData;
                    if (bundle == null) {
                    } else {
                        f889c = bundle.getString("com.google.app.id");
                        f890d = bundle.getInt("com.google.android.gms.version");
                    }
                } catch (Throwable e) {
                    Log.wtf("MetadataValueReader", "This should never happen.", e);
                }
            }
        }
        return f890d;
    }
}
