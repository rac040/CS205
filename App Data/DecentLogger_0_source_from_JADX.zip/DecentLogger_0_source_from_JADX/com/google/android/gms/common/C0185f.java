package com.google.android.gms.common;

import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager.NameNotFoundException;
import android.text.TextUtils;
import com.google.android.gms.common.internal.aj;
import com.google.android.gms.common.util.C0230d;

public class C0185f {
    private static final C0185f f786a = new C0185f();
    public static final int f787b = C0187n.f791b;

    C0185f() {
    }

    private static String m845a(Context context, String str) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("gcore_");
        stringBuilder.append(f787b);
        stringBuilder.append("-");
        if (!TextUtils.isEmpty(str)) {
            stringBuilder.append(str);
        }
        stringBuilder.append("-");
        if (context != null) {
            stringBuilder.append(context.getPackageName());
        }
        stringBuilder.append("-");
        if (context != null) {
            try {
                stringBuilder.append(context.getPackageManager().getPackageInfo(context.getPackageName(), 0).versionCode);
            } catch (NameNotFoundException e) {
            }
        }
        return stringBuilder.toString();
    }

    public int mo192a(Context context) {
        int b = C0187n.m863b(context);
        return C0187n.m861a(context, b) ? 18 : b;
    }

    public PendingIntent mo193a(Context context, int i, int i2) {
        return mo194a(context, i, i2, null);
    }

    public PendingIntent mo194a(Context context, int i, int i2, String str) {
        if (C0230d.m1113a(context) && i == 2) {
            i = 42;
        }
        Intent a = mo195a(context, i, str);
        return a == null ? null : PendingIntent.getActivity(context, i2, a, 268435456);
    }

    public Intent mo195a(Context context, int i, String str) {
        switch (i) {
            case 1:
            case 2:
                return aj.m935a("com.google.android.gms", C0185f.m845a(context, str));
            case 3:
                return aj.m934a("com.google.android.gms");
            case 42:
                return aj.m933a();
            default:
                return null;
        }
    }

    public boolean mo196a(int i) {
        return C0187n.m864b(i);
    }
}
