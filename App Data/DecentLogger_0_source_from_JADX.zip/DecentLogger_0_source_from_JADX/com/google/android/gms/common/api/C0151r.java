package com.google.android.gms.common.api;

import com.google.android.gms.common.ConnectionResult;

public interface C0151r {
    void mo187a(ConnectionResult connectionResult);
}
