package com.google.android.gms.common.internal;

import com.google.android.gms.common.ConnectionResult;

public interface C0197m {
    void mo206a(ConnectionResult connectionResult);
}
