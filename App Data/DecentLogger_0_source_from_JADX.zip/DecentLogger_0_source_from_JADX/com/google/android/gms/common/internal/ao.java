package com.google.android.gms.common.internal;

import android.os.IInterface;
import com.google.android.gms.p005a.C0117a;

public interface ao extends IInterface {
    C0117a mo199a();

    int mo200b();
}
