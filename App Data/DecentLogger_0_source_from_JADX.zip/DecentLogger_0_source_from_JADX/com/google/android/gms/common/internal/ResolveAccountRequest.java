package com.google.android.gms.common.internal;

import android.accounts.Account;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;

public class ResolveAccountRequest extends AbstractSafeParcelable {
    public static final Creator CREATOR = new C0201e();
    final int f817a;
    final Account f818b;
    final int f819c;
    final GoogleSignInAccount f820d;

    ResolveAccountRequest(int i, Account account, int i2, GoogleSignInAccount googleSignInAccount) {
        this.f817a = i;
        this.f818b = account;
        this.f819c = i2;
        this.f820d = googleSignInAccount;
    }

    public void writeToParcel(Parcel parcel, int i) {
        C0201e.m1044a(this, parcel, i);
    }
}
