package com.google.android.gms.common.api;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C0212a;
import com.google.android.gms.common.internal.safeparcel.C0213b;
import com.google.android.gms.common.internal.safeparcel.C0214c;

public final class C0184z implements Creator {
    static void m844a(Scope scope, Parcel parcel) {
        int a = C0214c.m1078a(parcel, 20293);
        C0214c.m1079a(parcel, 1, scope.f744a);
        C0214c.m1085a(parcel, 2, scope.f745b);
        C0214c.m1090b(parcel, a);
    }

    public final /* synthetic */ Object createFromParcel(Parcel parcel) {
        int a = C0212a.m1064a(parcel);
        int i = 0;
        String str = null;
        while (parcel.dataPosition() < a) {
            int readInt = parcel.readInt();
            switch (65535 & readInt) {
                case 1:
                    i = C0212a.m1070c(parcel, readInt);
                    break;
                case 2:
                    str = C0212a.m1074f(parcel, readInt);
                    break;
                default:
                    C0212a.m1066a(parcel, readInt);
                    break;
            }
        }
        if (parcel.dataPosition() == a) {
            return new Scope(i, str);
        }
        throw new C0213b("Overread allowed size end=" + a, parcel);
    }

    public final /* synthetic */ Object[] newArray(int i) {
        return new Scope[i];
    }
}
