package com.google.android.gms.common;

import android.content.Context;
import android.util.Log;

final class C0191g {
    private static Context f800a;

    static synchronized void m874a(Context context) {
        synchronized (C0191g.class) {
            if (f800a != null) {
                Log.w("GoogleCertificates", "GoogleCertificates has been initialized already");
            } else if (context != null) {
                f800a = context.getApplicationContext();
            }
        }
    }
}
