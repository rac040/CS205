package com.google.android.gms.common;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.util.Log;
import com.google.android.gms.common.internal.C0200d;

public class C0226o {
    private static C0226o f927b;
    public final Context f928a;

    private C0226o(Context context) {
        this.f928a = context.getApplicationContext();
    }

    static C0192h m1108a(PackageInfo packageInfo, C0192h... c0192hArr) {
        int i = 0;
        if (packageInfo.signatures == null) {
            return null;
        }
        if (packageInfo.signatures.length != 1) {
            Log.w("GoogleSignatureVerifier", "Package has more than one signature.");
            return null;
        }
        C0193i c0193i = new C0193i(packageInfo.signatures[0].toByteArray());
        while (i < c0192hArr.length) {
            if (c0192hArr[i].equals(c0193i)) {
                return c0192hArr[i];
            }
            i++;
        }
        return null;
    }

    public static C0226o m1109a(Context context) {
        C0200d.m1039a((Object) context);
        synchronized (C0226o.class) {
            if (f927b == null) {
                C0191g.m874a(context);
                f927b = new C0226o(context);
            }
        }
        return f927b;
    }

    public static boolean m1110a(PackageInfo packageInfo, boolean z) {
        if (!(packageInfo == null || packageInfo.signatures == null)) {
            C0192h a;
            if (z) {
                a = C0226o.m1108a(packageInfo, C0223k.f926a);
            } else {
                a = C0226o.m1108a(packageInfo, C0223k.f926a[0]);
            }
            if (a != null) {
                return true;
            }
        }
        return false;
    }
}
