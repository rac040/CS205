package com.google.android.gms.common.internal;

import android.accounts.Account;
import android.os.Binder;
import android.os.RemoteException;
import android.util.Log;
import com.google.android.gms.common.C0187n;

public final class C0194a extends al {
    int f832a;

    public static Account m884a(ak akVar) {
        Account account = null;
        if (akVar != null) {
            long clearCallingIdentity = Binder.clearCallingIdentity();
            try {
                account = akVar.mo202a();
            } catch (RemoteException e) {
                Log.w("AccountAccessor", "Remote account accessor probably died");
            } finally {
                Binder.restoreCallingIdentity(clearCallingIdentity);
            }
        }
        return account;
    }

    public final Account mo202a() {
        int callingUid = Binder.getCallingUid();
        if (callingUid != this.f832a) {
            if (C0187n.m860a(callingUid)) {
                this.f832a = callingUid;
            } else {
                throw new SecurityException("Caller is not GooglePlayServices");
            }
        }
        return null;
    }

    public final boolean equals(Object obj) {
        Account account = null;
        return this == obj ? true : !(obj instanceof C0194a) ? false : account.equals(account);
    }
}
