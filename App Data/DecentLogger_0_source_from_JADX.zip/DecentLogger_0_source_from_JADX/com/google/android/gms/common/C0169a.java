package com.google.android.gms.common;

import android.annotation.TargetApi;
import android.app.Dialog;
import android.app.DialogFragment;
import android.app.FragmentManager;
import android.content.DialogInterface;
import android.content.DialogInterface.OnCancelListener;
import android.os.Bundle;
import com.google.android.gms.common.internal.C0200d;

@TargetApi(11)
public final class C0169a extends DialogFragment {
    private Dialog f741a = null;
    private OnCancelListener f742b = null;

    public static C0169a m835a(Dialog dialog, OnCancelListener onCancelListener) {
        C0169a c0169a = new C0169a();
        Dialog dialog2 = (Dialog) C0200d.m1040a((Object) dialog, (Object) "Cannot display null dialog");
        dialog2.setOnCancelListener(null);
        dialog2.setOnDismissListener(null);
        c0169a.f741a = dialog2;
        if (onCancelListener != null) {
            c0169a.f742b = onCancelListener;
        }
        return c0169a;
    }

    public final void onCancel(DialogInterface dialogInterface) {
        if (this.f742b != null) {
            this.f742b.onCancel(dialogInterface);
        }
    }

    public final Dialog onCreateDialog(Bundle bundle) {
        if (this.f741a == null) {
            setShowsDialog(false);
        }
        return this.f741a;
    }

    public final void show(FragmentManager fragmentManager, String str) {
        super.show(fragmentManager, str);
    }
}
