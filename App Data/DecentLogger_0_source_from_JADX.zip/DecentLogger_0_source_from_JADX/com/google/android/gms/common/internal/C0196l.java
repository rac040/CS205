package com.google.android.gms.common.internal;

public interface C0196l {
    void mo204a();

    void mo205b();
}
