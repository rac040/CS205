package com.google.android.gms.common.internal;

import android.app.PendingIntent;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.util.Log;
import com.google.android.gms.common.ConnectionResult;

final class C0208n extends Handler {
    final /* synthetic */ C0195j f900a;

    public C0208n(C0195j c0195j, Looper looper) {
        this.f900a = c0195j;
        super(looper);
    }

    private static void m1058a(Message message) {
        ((C0206o) message.obj).m1053c();
    }

    private static boolean m1059b(Message message) {
        return message.what == 2 || message.what == 1 || message.what == 5;
    }

    public final void handleMessage(Message message) {
        PendingIntent pendingIntent = null;
        if (this.f900a.f839f.get() != message.arg1) {
            if (C0208n.m1059b(message)) {
                C0208n.m1058a(message);
            }
        } else if ((message.what == 1 || message.what == 5) && !this.f900a.m906c()) {
            C0208n.m1058a(message);
        } else if (message.what == 3) {
            if (message.obj instanceof PendingIntent) {
                pendingIntent = (PendingIntent) message.obj;
            }
            ConnectionResult connectionResult = new ConnectionResult(message.arg2, pendingIntent);
            this.f900a.f848p.mo190a(connectionResult);
            this.f900a.m902a(connectionResult);
        } else if (message.what == 4) {
            this.f900a.m889a(4, null);
            if (this.f900a.f853u != null) {
                C0196l c = this.f900a.f853u;
                int i = message.arg2;
                c.mo205b();
            }
            C0195j c0195j = this.f900a;
            c0195j.f835b = message.arg2;
            c0195j.f836c = System.currentTimeMillis();
            this.f900a.m891a(4, 1, null);
        } else if (message.what == 2 && !this.f900a.m905b()) {
            C0208n.m1058a(message);
        } else if (C0208n.m1059b(message)) {
            ((C0206o) message.obj).m1052b();
        } else {
            Log.wtf("GmsClient", "Don't know how to handle message: " + message.what, new Exception());
        }
    }
}
