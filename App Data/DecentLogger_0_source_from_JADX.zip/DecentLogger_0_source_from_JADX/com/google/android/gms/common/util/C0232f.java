package com.google.android.gms.common.util;

import android.os.Build.VERSION;

public final class C0232f {
    public static boolean m1115a(int i) {
        return VERSION.SDK_INT >= i;
    }
}
