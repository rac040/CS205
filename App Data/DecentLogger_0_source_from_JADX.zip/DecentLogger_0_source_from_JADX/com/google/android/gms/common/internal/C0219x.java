package com.google.android.gms.common.internal;

import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.support.v4.p002c.C0034l;
import android.support.wearable.C0107c;
import android.text.TextUtils;
import android.util.Log;
import com.google.android.gms.C0163c;
import com.google.android.gms.common.C0188c;
import com.google.android.gms.common.util.C0230d;
import com.google.android.gms.common.util.C0232f;

public final class C0219x {
    private static final C0034l f920a = new C0034l();

    public static String m1094a(Context context, int i) {
        Resources resources = context.getResources();
        switch (i) {
            case 1:
                return resources.getString(C0163c.common_google_play_services_install_title);
            case 2:
            case 42:
                return resources.getString(C0163c.common_google_play_services_update_title);
            case 3:
                return resources.getString(C0163c.common_google_play_services_enable_title);
            case 4:
            case 6:
                return null;
            case 5:
                Log.e("GoogleApiAvailability", "An invalid account was specified when connecting. Please provide a valid account.");
                return C0219x.m1096a(context, "common_google_play_services_invalid_account_title");
            case 7:
                Log.e("GoogleApiAvailability", "Network error occurred. Please retry request later.");
                return C0219x.m1096a(context, "common_google_play_services_network_error_title");
            case 8:
                Log.e("GoogleApiAvailability", "Internal error occurred. Please see logs for detailed information");
                return null;
            case 9:
                Log.e("GoogleApiAvailability", "Google Play services is invalid. Cannot recover.");
                return resources.getString(C0163c.common_google_play_services_unsupported_title);
            case 10:
                Log.e("GoogleApiAvailability", "Developer error occurred. Please see logs for detailed information");
                return null;
            case 11:
                Log.e("GoogleApiAvailability", "The application is not licensed to the user.");
                return null;
            case C0107c.ActionPage_buttonRippleColor /*16*/:
                Log.e("GoogleApiAvailability", "One of the API components you attempted to connect to is not available.");
                return null;
            case C0107c.ActionPage_pressedButtonTranslationZ /*17*/:
                Log.e("GoogleApiAvailability", "The specified account could not be signed in.");
                return C0219x.m1096a(context, "common_google_play_services_sign_in_failed_title");
            case 18:
                return resources.getString(C0163c.common_google_play_services_updating_title);
            case 20:
                Log.e("GoogleApiAvailability", "The current user profile is restricted and could not use authenticated features.");
                return C0219x.m1096a(context, "common_google_play_services_restricted_profile_title");
            default:
                Log.e("GoogleApiAvailability", "Unexpected error code " + i);
                return null;
        }
    }

    public static String m1095a(Context context, int i, String str) {
        Resources resources = context.getResources();
        switch (i) {
            case 1:
                boolean z;
                if (resources == null) {
                    z = false;
                } else {
                    if (C0230d.f930a == null) {
                        int i2 = (resources.getConfiguration().screenLayout & 15) > 3 ? 1 : 0;
                        if (!C0232f.m1115a(11) || i2 == 0) {
                            if (C0230d.f931b == null) {
                                Configuration configuration = resources.getConfiguration();
                                z = C0232f.m1115a(13) && (configuration.screenLayout & 15) <= 3 && configuration.smallestScreenWidthDp >= 600;
                                C0230d.f931b = Boolean.valueOf(z);
                            }
                            if (!C0230d.f931b.booleanValue()) {
                                z = false;
                                C0230d.f930a = Boolean.valueOf(z);
                            }
                        }
                        z = true;
                        C0230d.f930a = Boolean.valueOf(z);
                    }
                    z = C0230d.f930a.booleanValue();
                }
                if (z) {
                    return resources.getString(C0163c.common_google_play_services_install_text_tablet, new Object[]{str});
                }
                return resources.getString(C0163c.common_google_play_services_install_text_phone, new Object[]{str});
            case 2:
                return resources.getString(C0163c.common_google_play_services_update_text, new Object[]{str});
            case 3:
                return resources.getString(C0163c.common_google_play_services_enable_text, new Object[]{str});
            case 5:
                return C0219x.m1097a(context, "common_google_play_services_invalid_account_text", str);
            case 7:
                return C0219x.m1097a(context, "common_google_play_services_network_error_text", str);
            case 9:
                return resources.getString(C0163c.common_google_play_services_unsupported_text, new Object[]{str});
            case C0107c.ActionPage_buttonRippleColor /*16*/:
                return C0219x.m1097a(context, "common_google_play_services_api_unavailable_text", str);
            case C0107c.ActionPage_pressedButtonTranslationZ /*17*/:
                return C0219x.m1097a(context, "common_google_play_services_sign_in_failed_text", str);
            case 18:
                return resources.getString(C0163c.common_google_play_services_updating_text, new Object[]{str});
            case 20:
                return C0219x.m1097a(context, "common_google_play_services_restricted_profile_text", str);
            case 42:
                return resources.getString(C0163c.common_google_play_services_wear_update_text);
            default:
                return resources.getString(C0163c.common_google_play_services_unknown_issue, new Object[]{str});
        }
    }

    private static String m1096a(Context context, String str) {
        synchronized (f920a) {
            String str2 = (String) f920a.get(str);
            if (str2 != null) {
                return str2;
            }
            Resources a = C0188c.m868a(context);
            if (a == null) {
                return null;
            }
            int identifier = a.getIdentifier(str, "string", "com.google.android.gms");
            if (identifier == 0) {
                String str3 = "GoogleApiAvailability";
                String str4 = "Missing resource: ";
                str2 = String.valueOf(str);
                Log.w(str3, str2.length() != 0 ? str4.concat(str2) : new String(str4));
                return null;
            }
            Object string = a.getString(identifier);
            if (TextUtils.isEmpty(string)) {
                str3 = "GoogleApiAvailability";
                str4 = "Got empty resource: ";
                str2 = String.valueOf(str);
                Log.w(str3, str2.length() != 0 ? str4.concat(str2) : new String(str4));
                return null;
            }
            f920a.put(str, string);
            return string;
        }
    }

    private static String m1097a(Context context, String str, String str2) {
        Resources resources = context.getResources();
        String a = C0219x.m1096a(context, str);
        if (a == null) {
            a = resources.getString(C0163c.common_google_play_services_unknown_issue);
        }
        return String.format(resources.getConfiguration().locale, a, new Object[]{str2});
    }

    public static String m1098b(Context context, int i) {
        return i == 6 ? C0219x.m1096a(context, "common_google_play_services_resolution_required_title") : C0219x.m1094a(context, i);
    }

    public static String m1099b(Context context, int i, String str) {
        return i == 6 ? C0219x.m1097a(context, "common_google_play_services_resolution_required_text", str) : C0219x.m1095a(context, i, str);
    }

    public static String m1100c(Context context, int i) {
        Resources resources = context.getResources();
        switch (i) {
            case 1:
                return resources.getString(C0163c.common_google_play_services_install_button);
            case 2:
                return resources.getString(C0163c.common_google_play_services_update_button);
            case 3:
                return resources.getString(C0163c.common_google_play_services_enable_button);
            default:
                return resources.getString(17039370);
        }
    }
}
