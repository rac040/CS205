package com.google.android.gms.common;

import android.app.Dialog;
import android.content.DialogInterface;
import android.content.DialogInterface.OnCancelListener;
import android.support.v4.app.C0014k;
import android.support.v4.app.C0024v;
import com.google.android.gms.common.internal.C0200d;

public final class C0189d extends C0014k {
    private Dialog aj = null;
    private OnCancelListener ak = null;

    public static C0189d m870a(Dialog dialog, OnCancelListener onCancelListener) {
        C0189d c0189d = new C0189d();
        Dialog dialog2 = (Dialog) C0200d.m1040a((Object) dialog, (Object) "Cannot display null dialog");
        dialog2.setOnCancelListener(null);
        dialog2.setOnDismissListener(null);
        c0189d.aj = dialog2;
        if (onCancelListener != null) {
            c0189d.ak = onCancelListener;
        }
        return c0189d;
    }

    public final void mo197a(C0024v c0024v, String str) {
        super.mo197a(c0024v, str);
    }

    public final Dialog mo30b() {
        if (this.aj == null) {
            this.f302d = false;
        }
        return this.aj;
    }

    public final void onCancel(DialogInterface dialogInterface) {
        if (this.ak != null) {
            this.ak.onCancel(dialogInterface);
        }
    }
}
