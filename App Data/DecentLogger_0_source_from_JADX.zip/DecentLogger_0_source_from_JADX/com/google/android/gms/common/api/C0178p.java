package com.google.android.gms.common.api;

import android.accounts.Account;
import android.content.Context;
import android.os.Looper;
import android.support.v4.p002c.C0035a;
import android.view.View;
import com.google.android.gms.common.C0186b;
import com.google.android.gms.p006b.aj;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public final class C0178p {
    public Account f763a;
    public final Set f764b = new HashSet();
    public int f765c;
    public View f766d;
    public String f767e;
    public String f768f;
    public final Map f769g = new C0035a();
    public final Map f770h = new C0035a();
    private final Set f771i = new HashSet();
    private final Context f772j;
    private int f773k = -1;
    private Looper f774l;
    private C0186b f775m = C0186b.m851a();
    private C0127f f776n = aj.f627c;
    private final ArrayList f777o = new ArrayList();
    private final ArrayList f778p = new ArrayList();

    public C0178p(Context context) {
        this.f772j = context;
        this.f774l = context.getMainLooper();
        this.f767e = context.getPackageName();
        this.f768f = context.getClass().getName();
    }
}
