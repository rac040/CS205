package com.google.android.gms.common.p007a;

import android.annotation.SuppressLint;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Process;
import com.google.android.gms.common.util.C0227a;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public final class C0164a {
    private static final Object f712a = new Object();
    private static C0164a f713b;
    private static Integer f714h;
    private final List f715c;
    private final List f716d;
    private final List f717e;
    private final List f718f;
    private C0168e f719g;
    private C0168e f720i;

    private C0164a() {
        if (C0164a.m834b() == C0167d.f730b) {
            this.f715c = Collections.EMPTY_LIST;
            this.f716d = Collections.EMPTY_LIST;
            this.f717e = Collections.EMPTY_LIST;
            this.f718f = Collections.EMPTY_LIST;
            return;
        }
        String str = (String) C0166c.f724b.m742b();
        this.f715c = str == null ? Collections.EMPTY_LIST : Arrays.asList(str.split(","));
        str = (String) C0166c.f725c.m742b();
        this.f716d = str == null ? Collections.EMPTY_LIST : Arrays.asList(str.split(","));
        str = (String) C0166c.f726d.m742b();
        this.f717e = str == null ? Collections.EMPTY_LIST : Arrays.asList(str.split(","));
        str = (String) C0166c.f727e.m742b();
        this.f718f = str == null ? Collections.EMPTY_LIST : Arrays.asList(str.split(","));
        this.f719g = new C0168e(((Long) C0166c.f728f.m742b()).longValue());
        this.f720i = new C0168e(((Long) C0166c.f728f.m742b()).longValue());
    }

    public static C0164a m830a() {
        synchronized (f712a) {
            if (f713b == null) {
                f713b = new C0164a();
            }
        }
        return f713b;
    }

    public static String m831a(ServiceConnection serviceConnection) {
        return String.valueOf((((long) Process.myPid()) << 32) | ((long) System.identityHashCode(serviceConnection)));
    }

    @SuppressLint({"UntrackedBindService"})
    public static void m832a(Context context, ServiceConnection serviceConnection) {
        context.unbindService(serviceConnection);
        C0164a.m831a(serviceConnection);
    }

    public static boolean m833a(Context context, Intent intent) {
        ComponentName component = intent.getComponent();
        return component == null ? false : C0227a.m1111a(context, component.getPackageName());
    }

    private static int m834b() {
        if (f714h == null) {
            try {
                f714h = Integer.valueOf(C0167d.f730b);
            } catch (SecurityException e) {
                f714h = Integer.valueOf(C0167d.f730b);
            }
        }
        return f714h.intValue();
    }
}
