package com.google.android.gms.common.api;

import android.content.Context;
import android.os.Looper;
import com.google.android.gms.common.internal.C0217v;

public abstract class C0127f extends C0126i {
    public abstract C0129j mo178a(Context context, Looper looper, C0217v c0217v, Object obj, C0150q c0150q, C0151r c0151r);
}
