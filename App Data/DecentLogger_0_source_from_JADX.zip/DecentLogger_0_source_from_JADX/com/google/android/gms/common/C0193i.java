package com.google.android.gms.common;

import java.util.Arrays;

final class C0193i extends C0192h {
    private final byte[] f802a;

    C0193i(byte[] bArr) {
        super(Arrays.copyOfRange(bArr, 0, 25));
        this.f802a = bArr;
    }

    final byte[] mo201c() {
        return this.f802a;
    }
}
