package com.google.android.gms.common.p007a;

import android.content.ComponentName;

public final class C0167d {
    public static final ComponentName f729a = new ComponentName("com.google.android.gms", "com.google.android.gms.common.stats.GmsCoreStatsService");
    public static int f730b = 0;
    public static int f731c = 1;
    public static int f732d = 2;
    public static int f733e = 4;
    public static int f734f = 8;
    public static int f735g = 16;
    public static int f736h = 32;
    public static int f737i = 1;
}
