package com.google.android.gms.common.api;

import com.google.android.gms.common.internal.C0200d;

public final class C0171a {
    public final C0127f f757a;
    public final C0173k f758b;
    public final String f759c;
    private final C0175m f760d = null;
    private final C0176n f761e;

    public C0171a(String str, C0127f c0127f, C0173k c0173k) {
        C0200d.m1040a((Object) c0127f, (Object) "Cannot construct an Api with a null ClientBuilder");
        C0200d.m1040a((Object) c0173k, (Object) "Cannot construct an Api with a null ClientKey");
        this.f759c = str;
        this.f757a = c0127f;
        this.f758b = c0173k;
        this.f761e = null;
    }
}
