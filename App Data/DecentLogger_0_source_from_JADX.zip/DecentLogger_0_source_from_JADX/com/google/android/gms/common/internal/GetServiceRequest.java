package com.google.android.gms.common.internal;

import android.accounts.Account;
import android.os.Bundle;
import android.os.IBinder;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.C0185f;
import com.google.android.gms.common.api.Scope;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;

public class GetServiceRequest extends AbstractSafeParcelable {
    public static final Creator CREATOR = new aa();
    final int f808a;
    final int f809b;
    int f810c;
    String f811d;
    IBinder f812e;
    Scope[] f813f;
    Bundle f814g;
    Account f815h;
    long f816i;

    public GetServiceRequest(int i) {
        this.f808a = 3;
        this.f810c = C0185f.f787b;
        this.f809b = i;
    }

    GetServiceRequest(int i, int i2, int i3, String str, IBinder iBinder, Scope[] scopeArr, Bundle bundle, Account account, long j) {
        this.f808a = i;
        this.f809b = i2;
        this.f810c = i3;
        this.f811d = str;
        if (i < 2) {
            Account account2 = null;
            if (iBinder != null) {
                account2 = C0194a.m884a(al.m883a(iBinder));
            }
            this.f815h = account2;
        } else {
            this.f812e = iBinder;
            this.f815h = account;
        }
        this.f813f = scopeArr;
        this.f814g = bundle;
        this.f816i = j;
    }

    public void writeToParcel(Parcel parcel, int i) {
        aa.m886a(this, parcel, i);
    }
}
