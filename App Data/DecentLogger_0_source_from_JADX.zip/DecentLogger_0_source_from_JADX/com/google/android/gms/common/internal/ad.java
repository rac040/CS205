package com.google.android.gms.common.internal;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.C0151r;

final class ad implements C0197m {
    final /* synthetic */ C0151r f861a;

    ad(C0151r c0151r) {
        this.f861a = c0151r;
    }

    public final void mo206a(ConnectionResult connectionResult) {
        this.f861a.mo187a(connectionResult);
    }
}
