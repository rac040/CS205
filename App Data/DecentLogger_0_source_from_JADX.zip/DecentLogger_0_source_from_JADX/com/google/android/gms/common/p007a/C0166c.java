package com.google.android.gms.common.p007a;

import com.google.android.gms.p006b.C0125y;

public final class C0166c {
    public static C0125y f723a = C0125y.m738a("gms:common:stats:connections:level", Integer.valueOf(C0167d.f730b));
    public static C0125y f724b = C0125y.m740a("gms:common:stats:connections:ignored_calling_processes", "");
    public static C0125y f725c = C0125y.m740a("gms:common:stats:connections:ignored_calling_services", "");
    public static C0125y f726d = C0125y.m740a("gms:common:stats:connections:ignored_target_processes", "");
    public static C0125y f727e = C0125y.m740a("gms:common:stats:connections:ignored_target_services", "com.google.android.gms.auth.GetToken");
    public static C0125y f728f = C0125y.m739a("gms:common:stats:connections:time_out_duration", Long.valueOf(600000));
}
