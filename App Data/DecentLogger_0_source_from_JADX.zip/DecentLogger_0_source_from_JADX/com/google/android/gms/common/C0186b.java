package com.google.android.gms.common;

import android.app.Activity;
import android.app.AlertDialog.Builder;
import android.app.Dialog;
import android.app.PendingIntent;
import android.content.Context;
import android.content.DialogInterface.OnCancelListener;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.support.v4.app.C0018o;
import android.util.TypedValue;
import com.google.android.gms.common.api.GoogleApiActivity;
import com.google.android.gms.common.internal.C0219x;
import com.google.android.gms.common.internal.C0220y;
import com.google.android.gms.common.util.C0230d;
import com.google.android.gms.common.util.C0232f;

public final class C0186b extends C0185f {
    public static final int f788a = C0185f.f787b;
    private static final C0186b f789c = new C0186b();

    C0186b() {
    }

    public static C0186b m851a() {
        return f789c;
    }

    public final int mo192a(Context context) {
        return super.mo192a(context);
    }

    public final PendingIntent mo193a(Context context, int i, int i2) {
        return super.mo193a(context, i, i2);
    }

    public final PendingIntent mo194a(Context context, int i, int i2, String str) {
        return super.mo194a(context, i, i2, str);
    }

    public final Intent mo195a(Context context, int i, String str) {
        return super.mo195a(context, i, str);
    }

    public final void m856a(Context context, ConnectionResult connectionResult, int i) {
        PendingIntent pendingIntent;
        if (connectionResult.m828a()) {
            pendingIntent = connectionResult.f710d;
        } else {
            int i2 = connectionResult.f709c;
            if (C0230d.m1113a(context) && i2 == 2) {
                i2 = 42;
            }
            pendingIntent = super.mo193a(context, i2, 0);
        }
        if (pendingIntent != null) {
            C0188c.m869a(connectionResult.f709c, context, GoogleApiActivity.m836a(context, pendingIntent, i));
        }
    }

    public final boolean mo196a(int i) {
        return super.mo196a(i);
    }

    public final boolean m858a(Activity activity, int i, OnCancelListener onCancelListener) {
        Builder builder = null;
        OnClickListener a = C0220y.m1101a(activity, super.mo195a((Context) activity, i, "d"));
        if (i != 0) {
            if (C0230d.m1113a(activity) && i == 2) {
                i = 42;
            }
            if (C0232f.m1115a(14)) {
                TypedValue typedValue = new TypedValue();
                activity.getTheme().resolveAttribute(16843529, typedValue, true);
                if ("Theme.Dialog.Alert".equals(activity.getResources().getResourceEntryName(typedValue.resourceId))) {
                    builder = new Builder(activity, 5);
                }
            }
            if (builder == null) {
                builder = new Builder(activity);
            }
            builder.setMessage(C0219x.m1095a((Context) activity, i, C0187n.m867e(activity)));
            if (onCancelListener != null) {
                builder.setOnCancelListener(onCancelListener);
            }
            CharSequence c = C0219x.m1100c(activity, i);
            if (c != null) {
                builder.setPositiveButton(c, a);
            }
            CharSequence a2 = C0219x.m1094a((Context) activity, i);
            if (a2 != null) {
                builder.setTitle(a2);
            }
            Dialog create = builder.create();
        }
        if (create == null) {
            return false;
        }
        String str = "GooglePlayServicesErrorDialog";
        if (activity instanceof C0018o) {
            C0189d.m870a(create, onCancelListener).mo197a(((C0018o) activity).f310d.f334a.f324f, str);
        } else if (C0232f.m1115a(11)) {
            C0169a.m835a(create, onCancelListener).show(activity.getFragmentManager(), str);
        } else {
            throw new RuntimeException("This Activity does not support Fragments.");
        }
        return true;
    }
}
