package com.google.android.gms.common.p007a;

import com.google.android.gms.p006b.C0125y;

public final class C0165b {
    public static C0125y f721a = C0125y.m738a("gms:common:stats:max_num_of_events", Integer.valueOf(100));
    public static C0125y f722b = C0125y.m738a("gms:common:stats:max_chunk_size", Integer.valueOf(100));
}
