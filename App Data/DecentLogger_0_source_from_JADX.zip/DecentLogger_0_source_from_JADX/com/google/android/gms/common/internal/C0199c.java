package com.google.android.gms.common.internal;

import java.util.ArrayList;
import java.util.List;

public final class C0199c {
    private final List f891a;
    private final Object f892b;

    private C0199c(Object obj) {
        this.f892b = C0200d.m1039a(obj);
        this.f891a = new ArrayList();
    }

    public final C0199c m1038a(String str, Object obj) {
        List list = this.f891a;
        String str2 = (String) C0200d.m1039a((Object) str);
        String valueOf = String.valueOf(String.valueOf(obj));
        list.add(new StringBuilder((String.valueOf(str2).length() + 1) + String.valueOf(valueOf).length()).append(str2).append("=").append(valueOf).toString());
        return this;
    }

    public final String toString() {
        StringBuilder append = new StringBuilder(100).append(this.f892b.getClass().getSimpleName()).append('{');
        int size = this.f891a.size();
        for (int i = 0; i < size; i++) {
            append.append((String) this.f891a.get(i));
            if (i < size - 1) {
                append.append(", ");
            }
        }
        return append.append('}').toString();
    }
}
