package com.google.android.gms.common.internal;

import android.accounts.Account;
import android.os.IInterface;

public interface ak extends IInterface {
    Account mo202a();
}
