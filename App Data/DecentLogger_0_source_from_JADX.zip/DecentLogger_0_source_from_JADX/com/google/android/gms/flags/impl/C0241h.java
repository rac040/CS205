package com.google.android.gms.flags.impl;

public final class C0241h extends C0234a {
}
