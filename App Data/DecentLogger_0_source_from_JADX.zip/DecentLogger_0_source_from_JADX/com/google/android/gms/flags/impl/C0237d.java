package com.google.android.gms.flags.impl;

public final class C0237d extends C0234a {
}
