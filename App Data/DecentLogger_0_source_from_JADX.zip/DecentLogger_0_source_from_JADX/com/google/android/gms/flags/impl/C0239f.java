package com.google.android.gms.flags.impl;

public final class C0239f extends C0234a {
}
