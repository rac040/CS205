package com.google.android.gms.flags.impl;

import android.content.SharedPreferences;
import java.util.concurrent.Callable;

final class C0240g implements Callable {
    final /* synthetic */ SharedPreferences f942a;
    final /* synthetic */ String f943b;
    final /* synthetic */ Long f944c;

    C0240g(SharedPreferences sharedPreferences, String str, Long l) {
        this.f942a = sharedPreferences;
        this.f943b = str;
        this.f944c = l;
    }

    public final /* synthetic */ Object call() {
        return Long.valueOf(this.f942a.getLong(this.f943b, this.f944c.longValue()));
    }
}
