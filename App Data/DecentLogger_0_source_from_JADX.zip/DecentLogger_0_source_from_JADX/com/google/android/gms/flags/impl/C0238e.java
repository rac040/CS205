package com.google.android.gms.flags.impl;

import android.content.SharedPreferences;
import java.util.concurrent.Callable;

final class C0238e implements Callable {
    final /* synthetic */ SharedPreferences f939a;
    final /* synthetic */ String f940b;
    final /* synthetic */ Integer f941c;

    C0238e(SharedPreferences sharedPreferences, String str, Integer num) {
        this.f939a = sharedPreferences;
        this.f940b = str;
        this.f941c = num;
    }

    public final /* synthetic */ Object call() {
        return Integer.valueOf(this.f939a.getInt(this.f940b, this.f941c.intValue()));
    }
}
