package com.google.android.gms.flags.impl;

import android.content.SharedPreferences;
import java.util.concurrent.Callable;

final class C0236c implements Callable {
    final /* synthetic */ SharedPreferences f936a;
    final /* synthetic */ String f937b;
    final /* synthetic */ Boolean f938c;

    C0236c(SharedPreferences sharedPreferences, String str, Boolean bool) {
        this.f936a = sharedPreferences;
        this.f937b = str;
        this.f938c = bool;
    }

    public final /* synthetic */ Object call() {
        return Boolean.valueOf(this.f936a.getBoolean(this.f937b, this.f938c.booleanValue()));
    }
}
