package com.google.android.gms.flags.impl;

import android.content.SharedPreferences;
import java.util.concurrent.Callable;

final class C0242i implements Callable {
    final /* synthetic */ SharedPreferences f945a;
    final /* synthetic */ String f946b;
    final /* synthetic */ String f947c;

    C0242i(SharedPreferences sharedPreferences, String str, String str2) {
        this.f945a = sharedPreferences;
        this.f946b = str;
        this.f947c = str2;
    }

    public final /* synthetic */ Object call() {
        return this.f945a.getString(this.f946b, this.f947c);
    }
}
