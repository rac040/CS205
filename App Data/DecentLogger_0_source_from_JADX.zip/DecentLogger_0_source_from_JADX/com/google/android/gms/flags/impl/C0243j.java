package com.google.android.gms.flags.impl;

import android.content.Context;
import android.content.SharedPreferences;
import com.google.android.gms.p006b.ai;

public final class C0243j {
    private static SharedPreferences f948a = null;

    public static SharedPreferences m1117a(Context context) {
        SharedPreferences sharedPreferences;
        synchronized (SharedPreferences.class) {
            if (f948a == null) {
                f948a = (SharedPreferences) ai.m753a(new C0244k(context));
            }
            sharedPreferences = f948a;
        }
        return sharedPreferences;
    }
}
