package com.google.android.gms.flags.impl;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager.NameNotFoundException;
import com.google.android.gms.common.util.DynamiteApi;
import com.google.android.gms.p005a.C0117a;
import com.google.android.gms.p005a.C0120d;
import com.google.android.gms.p006b.ag;
import com.google.android.gms.p006b.ai;

@DynamiteApi
public class FlagProviderImpl extends ag {
    private boolean f934a = false;
    private SharedPreferences f935b;

    public boolean getBooleanFlagValue(String str, boolean z, int i) {
        return !this.f934a ? z : ((Boolean) ai.m753a(new C0236c(this.f935b, str, Boolean.valueOf(z)))).booleanValue();
    }

    public int getIntFlagValue(String str, int i, int i2) {
        return !this.f934a ? i : ((Integer) ai.m753a(new C0238e(this.f935b, str, Integer.valueOf(i)))).intValue();
    }

    public long getLongFlagValue(String str, long j, int i) {
        return !this.f934a ? j : ((Long) ai.m753a(new C0240g(this.f935b, str, Long.valueOf(j)))).longValue();
    }

    public String getStringFlagValue(String str, String str2, int i) {
        return !this.f934a ? str2 : (String) ai.m753a(new C0242i(this.f935b, str, str2));
    }

    public void init(C0117a c0117a) {
        Context context = (Context) C0120d.m731a(c0117a);
        if (!this.f934a) {
            try {
                this.f935b = C0243j.m1117a(context.createPackageContext("com.google.android.gms", 0));
                this.f934a = true;
            } catch (NameNotFoundException e) {
            }
        }
    }
}
