package android.support.v4.view;

import android.view.LayoutInflater;

interface C0099t {
    void mo167a(LayoutInflater layoutInflater, ab abVar);
}
