package android.support.v4.view;

import android.view.View;

public interface ah {
    bs mo127a(View view, bs bsVar);
}
