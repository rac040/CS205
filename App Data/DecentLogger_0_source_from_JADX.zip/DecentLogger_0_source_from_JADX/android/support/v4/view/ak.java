package android.support.v4.view;

import android.os.Build.VERSION;
import android.view.VelocityTracker;

public final class ak {
    static final an f479a;

    static {
        if (VERSION.SDK_INT >= 11) {
            f479a = new am();
        } else {
            f479a = new al();
        }
    }

    public static float m512a(VelocityTracker velocityTracker, int i) {
        return f479a.mo110a(velocityTracker, i);
    }
}
