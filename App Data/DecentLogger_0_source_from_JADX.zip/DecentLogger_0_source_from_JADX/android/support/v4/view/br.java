package android.support.v4.view;

import android.view.View;
import java.util.Comparator;

final class br implements Comparator {
    br() {
    }

    public final /* synthetic */ int compare(Object obj, Object obj2) {
        bl blVar = (bl) ((View) obj).getLayoutParams();
        bl blVar2 = (bl) ((View) obj2).getLayoutParams();
        return blVar.f496a != blVar2.f496a ? blVar.f496a ? 1 : -1 : blVar.f500e - blVar2.f500e;
    }
}
