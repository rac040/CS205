package android.support.v4.view;

import android.os.Parcel;
import android.support.v4.p001b.C0032d;

final class C0079a implements C0032d {
    C0079a() {
    }

    public final /* synthetic */ Object mo108a(Parcel parcel, ClassLoader classLoader) {
        if (parcel.readParcelable(classLoader) == null) {
            return AbsSavedState.f409a;
        }
        throw new IllegalStateException("superState must be null");
    }

    public final /* bridge */ /* synthetic */ Object[] mo109a(int i) {
        return new AbsSavedState[i];
    }
}
