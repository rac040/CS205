package android.support.v4.view;

import android.os.Build.VERSION;
import android.os.Bundle;
import android.support.v4.view.p004a.C0059g;
import android.support.v4.view.p004a.C0071s;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityEvent;

public class C0081b {
    private static final C0082e f485b;
    private static final Object f486c = f485b.mo138a();
    final Object f487a = f485b.mo139a(this);

    static {
        if (VERSION.SDK_INT >= 16) {
            f485b = new C0087f();
        } else if (VERSION.SDK_INT >= 14) {
            f485b = new C0084c();
        } else {
            f485b = new C0083h();
        }
    }

    public static C0071s m577a(View view) {
        return f485b.mo137a(f486c, view);
    }

    public static void m578a(View view, int i) {
        f485b.mo140a(f486c, view, i);
    }

    public static void m579a(View view, AccessibilityEvent accessibilityEvent) {
        f485b.mo147d(f486c, view, accessibilityEvent);
    }

    public static boolean m580a(ViewGroup viewGroup, View view, AccessibilityEvent accessibilityEvent) {
        return f485b.mo144a(f486c, viewGroup, view, accessibilityEvent);
    }

    public static boolean m581b(View view, AccessibilityEvent accessibilityEvent) {
        return f485b.mo143a(f486c, view, accessibilityEvent);
    }

    public static void m582c(View view, AccessibilityEvent accessibilityEvent) {
        f485b.mo146c(f486c, view, accessibilityEvent);
    }

    public void mo128a(View view, C0059g c0059g) {
        f485b.mo141a(f486c, view, c0059g);
    }

    public boolean mo129a(View view, int i, Bundle bundle) {
        return f485b.mo142a(f486c, view, i, bundle);
    }

    public void mo130d(View view, AccessibilityEvent accessibilityEvent) {
        f485b.mo145b(f486c, view, accessibilityEvent);
    }
}
