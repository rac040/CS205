package android.support.v4.view;

public interface aj {
    int m509a();

    int m510b();

    int m511c();
}
