package android.support.v4.view;

final class bk {
    int f492a;
    boolean f493b;
    float f494c;
    float f495d;

    bk() {
    }
}
