package android.support.v4.view;

import android.animation.ValueAnimator;
import android.view.View;

class ar extends aq {
    ar() {
    }

    final long mo125a() {
        return ValueAnimator.getFrameDelay();
    }

    public final void mo119b(View view, int i) {
        view.setLayerType(i, null);
    }

    public final int mo121d(View view) {
        return view.getLayerType();
    }

    public final void mo123f(View view) {
        view.setSaveFromParentEnabled(false);
    }
}
