package android.support.v4.view;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.ViewGroup.LayoutParams;

public final class bl extends LayoutParams {
    public boolean f496a;
    public int f497b;
    float f498c = 0.0f;
    boolean f499d;
    int f500e;
    int f501f;

    public bl() {
        super(-1, -1);
    }

    public bl(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, ViewPager.f414a);
        this.f497b = obtainStyledAttributes.getInteger(0, 48);
        obtainStyledAttributes.recycle();
    }
}
