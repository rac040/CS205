package android.support.v4.view;

import android.os.Bundle;
import android.support.v4.view.p004a.C0071s;
import android.view.View;
import android.view.View.AccessibilityDelegate;
import android.view.accessibility.AccessibilityNodeProvider;

final class C0087f extends C0084c {
    C0087f() {
    }

    public final C0071s mo137a(Object obj, View view) {
        AccessibilityNodeProvider accessibilityNodeProvider = ((AccessibilityDelegate) obj).getAccessibilityNodeProvider(view);
        return accessibilityNodeProvider != null ? new C0071s(accessibilityNodeProvider) : null;
    }

    public final Object mo139a(C0081b c0081b) {
        return new C0093m(new C0089g(this, c0081b));
    }

    public final boolean mo142a(Object obj, View view, int i, Bundle bundle) {
        return ((AccessibilityDelegate) obj).performAccessibilityAction(view, i, bundle);
    }
}
