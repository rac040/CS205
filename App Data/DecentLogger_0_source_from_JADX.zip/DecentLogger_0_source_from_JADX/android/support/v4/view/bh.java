package android.support.v4.view;

final class bh implements Runnable {
    final /* synthetic */ ViewPager f489a;

    bh(ViewPager viewPager) {
        this.f489a = viewPager;
    }

    public final void run() {
        this.f489a.setScrollState(0);
        this.f489a.m401b();
    }
}
