package android.support.v4.view;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;

public interface ab {
    View mo53a(View view, String str, Context context, AttributeSet attributeSet);
}
