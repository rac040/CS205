package android.support.v4.view;

import android.database.DataSetObserver;

public abstract class ai {
    private DataSetObserver f478a;

    public static void m505b() {
        throw new UnsupportedOperationException("Required method destroyItem was not overridden");
    }

    public abstract int m506a();

    final void m507a(DataSetObserver dataSetObserver) {
        synchronized (this) {
            this.f478a = dataSetObserver;
        }
    }

    public abstract boolean m508c();
}
