package android.support.v4.view;

import android.view.WindowInsets;

final class bu extends bt {
    private bu() {
        super();
    }

    public final boolean mo136e(Object obj) {
        return ((WindowInsets) obj).isConsumed();
    }
}
