package android.support.v4.view;

interface bw {
    int mo131a(Object obj);

    bs mo132a(Object obj, int i, int i2, int i3, int i4);

    int mo133b(Object obj);

    int mo134c(Object obj);

    int mo135d(Object obj);

    boolean mo136e(Object obj);
}
