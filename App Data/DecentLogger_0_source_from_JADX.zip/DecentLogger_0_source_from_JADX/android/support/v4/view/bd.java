package android.support.v4.view;

import android.view.View;
import android.view.View.OnApplyWindowInsetsListener;
import android.view.WindowInsets;

final class bd implements OnApplyWindowInsetsListener {
    final /* synthetic */ be f488a;

    bd(be beVar) {
        this.f488a = beVar;
    }

    public final WindowInsets onApplyWindowInsets(View view, WindowInsets windowInsets) {
        return (WindowInsets) this.f488a.mo126a(view, windowInsets);
    }
}
