package android.support.v4.view;

import android.content.Context;
import android.util.AttributeSet;
import android.view.LayoutInflater.Factory2;
import android.view.View;

final class aa extends C0080y implements Factory2 {
    aa(ab abVar) {
        super(abVar);
    }

    public final View onCreateView(View view, String str, Context context, AttributeSet attributeSet) {
        return this.a.mo53a(view, str, context, attributeSet);
    }
}
