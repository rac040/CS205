package android.support.v4.view;

import android.view.LayoutInflater;

final class C0102w extends C0101v {
    C0102w() {
    }

    public final void mo167a(LayoutInflater layoutInflater, ab abVar) {
        layoutInflater.setFactory2(abVar != null ? new aa(abVar) : null);
    }
}
