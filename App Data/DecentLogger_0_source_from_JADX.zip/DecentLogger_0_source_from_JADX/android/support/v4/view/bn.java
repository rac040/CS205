package android.support.v4.view;

public interface bn {
    void mo168a(float f);

    void mo169a(int i);

    void mo170b(int i);
}
