package android.support.v4.view;

import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityEvent;

public interface C0085k {
    void mo148a(View view, int i);

    void mo149a(View view, Object obj);

    boolean mo150a(View view, AccessibilityEvent accessibilityEvent);

    boolean mo151a(ViewGroup viewGroup, View view, AccessibilityEvent accessibilityEvent);

    void mo152b(View view, AccessibilityEvent accessibilityEvent);

    void mo153c(View view, AccessibilityEvent accessibilityEvent);

    void mo154d(View view, AccessibilityEvent accessibilityEvent);
}
