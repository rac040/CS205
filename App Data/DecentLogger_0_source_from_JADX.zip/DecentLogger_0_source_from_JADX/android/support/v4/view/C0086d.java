package android.support.v4.view;

import android.support.v4.view.p004a.C0059g;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityEvent;

final class C0086d implements C0085k {
    final /* synthetic */ C0081b f506a;
    final /* synthetic */ C0084c f507b;

    C0086d(C0084c c0084c, C0081b c0081b) {
        this.f507b = c0084c;
        this.f506a = c0081b;
    }

    public final void mo148a(View view, int i) {
        C0081b.m578a(view, i);
    }

    public final void mo149a(View view, Object obj) {
        this.f506a.mo128a(view, new C0059g(obj));
    }

    public final boolean mo150a(View view, AccessibilityEvent accessibilityEvent) {
        return C0081b.m581b(view, accessibilityEvent);
    }

    public final boolean mo151a(ViewGroup viewGroup, View view, AccessibilityEvent accessibilityEvent) {
        return C0081b.m580a(viewGroup, view, accessibilityEvent);
    }

    public final void mo152b(View view, AccessibilityEvent accessibilityEvent) {
        this.f506a.mo130d(view, accessibilityEvent);
    }

    public final void mo153c(View view, AccessibilityEvent accessibilityEvent) {
        C0081b.m582c(view, accessibilityEvent);
    }

    public final void mo154d(View view, AccessibilityEvent accessibilityEvent) {
        C0081b.m579a(view, accessibilityEvent);
    }
}
