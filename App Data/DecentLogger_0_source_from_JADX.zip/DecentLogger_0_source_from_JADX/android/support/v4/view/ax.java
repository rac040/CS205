package android.support.v4.view;

import android.view.View;

class ax extends aw {
    ax() {
    }

    public final void mo120c(View view) {
        view.setImportantForAccessibility(1);
    }

    public final boolean mo124g(View view) {
        return view.isAttachedToWindow();
    }
}
