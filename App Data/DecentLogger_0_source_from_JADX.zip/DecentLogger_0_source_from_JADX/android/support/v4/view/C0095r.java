package android.support.v4.view;

interface C0095r {
    boolean mo164b(int i);

    boolean mo165c(int i);
}
