package android.support.v4.view;

import java.util.Comparator;

final class bf implements Comparator {
    bf() {
    }

    public final /* bridge */ /* synthetic */ int compare(Object obj, Object obj2) {
        return ((bk) obj).f492a - ((bk) obj2).f492a;
    }
}
