package android.support.v4.view;

import android.view.View;

final class bc {
    public static void m586a(View view, be beVar) {
        if (beVar == null) {
            view.setOnApplyWindowInsetsListener(null);
        } else {
            view.setOnApplyWindowInsetsListener(new bd(beVar));
        }
    }
}
