package android.support.v4.view;

import android.os.Bundle;
import android.support.v4.view.p004a.C0059g;
import android.support.v4.view.p004a.C0071s;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityEvent;

interface C0082e {
    C0071s mo137a(Object obj, View view);

    Object mo138a();

    Object mo139a(C0081b c0081b);

    void mo140a(Object obj, View view, int i);

    void mo141a(Object obj, View view, C0059g c0059g);

    boolean mo142a(Object obj, View view, int i, Bundle bundle);

    boolean mo143a(Object obj, View view, AccessibilityEvent accessibilityEvent);

    boolean mo144a(Object obj, ViewGroup viewGroup, View view, AccessibilityEvent accessibilityEvent);

    void mo145b(Object obj, View view, AccessibilityEvent accessibilityEvent);

    void mo146c(Object obj, View view, AccessibilityEvent accessibilityEvent);

    void mo147d(Object obj, View view, AccessibilityEvent accessibilityEvent);
}
