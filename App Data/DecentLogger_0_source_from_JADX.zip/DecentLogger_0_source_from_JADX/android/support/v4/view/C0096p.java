package android.support.v4.view;

class C0096p implements C0095r {
    C0096p() {
    }

    private static int m691a(int i, int i2, int i3, int i4) {
        Object obj = 1;
        Object obj2 = (i2 & 1) != 0 ? 1 : null;
        int i5 = i3 | i4;
        if ((i5 & 1) == 0) {
            obj = null;
        }
        if (obj2 == null) {
            return obj != null ? i & (i2 ^ -1) : i;
        } else {
            if (obj == null) {
                return i & (i5 ^ -1);
            }
            throw new IllegalArgumentException("bad arguments");
        }
    }

    public int mo166a(int i) {
        int i2 = (i & 192) != 0 ? i | 1 : i;
        if ((i2 & 48) != 0) {
            i2 |= 2;
        }
        return i2 & 247;
    }

    public boolean mo164b(int i) {
        return C0096p.m691a(C0096p.m691a(mo166a(i) & 247, 1, 64, 128), 2, 16, 32) == 1;
    }

    public boolean mo165c(int i) {
        return (mo166a(i) & 247) == 0;
    }
}
