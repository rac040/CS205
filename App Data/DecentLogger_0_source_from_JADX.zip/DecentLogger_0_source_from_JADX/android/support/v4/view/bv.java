package android.support.v4.view;

class bv implements bw {
    private bv() {
    }

    public int mo131a(Object obj) {
        return 0;
    }

    public bs mo132a(Object obj, int i, int i2, int i3, int i4) {
        return null;
    }

    public int mo133b(Object obj) {
        return 0;
    }

    public int mo134c(Object obj) {
        return 0;
    }

    public int mo135d(Object obj) {
        return 0;
    }

    public boolean mo136e(Object obj) {
        return false;
    }
}
