package android.support.v4.view;

import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityEvent;

public interface C0088n {
    Object mo155a(View view);

    void mo156a(View view, int i);

    void mo157a(View view, Object obj);

    boolean mo158a(View view, int i, Bundle bundle);

    boolean mo159a(View view, AccessibilityEvent accessibilityEvent);

    boolean mo160a(ViewGroup viewGroup, View view, AccessibilityEvent accessibilityEvent);

    void mo161b(View view, AccessibilityEvent accessibilityEvent);

    void mo162c(View view, AccessibilityEvent accessibilityEvent);

    void mo163d(View view, AccessibilityEvent accessibilityEvent);
}
