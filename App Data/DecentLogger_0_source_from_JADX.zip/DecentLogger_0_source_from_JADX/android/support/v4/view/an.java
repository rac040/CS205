package android.support.v4.view;

import android.view.VelocityTracker;

interface an {
    float mo110a(VelocityTracker velocityTracker, int i);
}
