package android.support.v4.view;

import android.os.Build.VERSION;
import android.support.v4.p001b.C0029a;
import android.view.View;

public final class ao {
    static final bb f480a;

    static {
        int i = VERSION.SDK_INT;
        if (C0029a.m294a()) {
            f480a = new ap();
        } else if (i >= 23) {
            f480a = new ba();
        } else if (i >= 21) {
            f480a = new ay();
        } else if (i >= 19) {
            f480a = new ax();
        } else if (i >= 18) {
            f480a = new aw();
        } else if (i >= 17) {
            f480a = new av();
        } else if (i >= 16) {
            f480a = new au();
        } else if (i >= 15) {
            f480a = new as();
        } else if (i >= 14) {
            f480a = new at();
        } else if (i >= 11) {
            f480a = new ar();
        } else {
            f480a = new aq();
        }
    }

    public static bs m516a(View view, bs bsVar) {
        return f480a.mo111a(view, bsVar);
    }

    public static void m517a(View view) {
        f480a.mo112a(view);
    }

    public static void m518a(View view, ah ahVar) {
        f480a.mo113a(view, ahVar);
    }

    public static void m519a(View view, C0081b c0081b) {
        f480a.mo114a(view, c0081b);
    }

    public static void m520a(View view, Runnable runnable) {
        f480a.mo115a(view, runnable);
    }

    public static boolean m521a(View view, int i) {
        return f480a.mo116a(view, i);
    }

    public static int m522b(View view) {
        return f480a.mo117b(view);
    }

    public static bs m523b(View view, bs bsVar) {
        return f480a.mo118b(view, bsVar);
    }

    public static void m524b(View view, int i) {
        f480a.mo119b(view, i);
    }

    public static void m525c(View view) {
        f480a.mo120c(view);
    }

    public static int m526d(View view) {
        return f480a.mo121d(view);
    }

    public static void m527e(View view) {
        f480a.mo123f(view);
    }

    public static boolean m528f(View view) {
        return f480a.mo122e(view);
    }

    public static boolean m529g(View view) {
        return f480a.mo124g(view);
    }
}
