package android.support.v4.view;

import android.database.DataSetObserver;

final class bp extends DataSetObserver {
    final /* synthetic */ ViewPager f503a;

    private bp(ViewPager viewPager) {
        this.f503a = viewPager;
    }

    public final void onChanged() {
        this.f503a.m400a();
    }

    public final void onInvalidated() {
        this.f503a.m400a();
    }
}
