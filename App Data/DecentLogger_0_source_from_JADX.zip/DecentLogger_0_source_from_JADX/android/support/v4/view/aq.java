package android.support.v4.view;

import android.view.View;
import java.util.WeakHashMap;

class aq implements bb {
    WeakHashMap f481a = null;

    aq() {
    }

    long mo125a() {
        return 10;
    }

    public bs mo111a(View view, bs bsVar) {
        return bsVar;
    }

    public void mo112a(View view) {
        view.invalidate();
    }

    public void mo113a(View view, ah ahVar) {
    }

    public void mo114a(View view, C0081b c0081b) {
    }

    public void mo115a(View view, Runnable runnable) {
        view.postDelayed(runnable, mo125a());
    }

    public boolean mo116a(View view, int i) {
        if (view instanceof aj) {
            boolean z;
            aj ajVar = (aj) view;
            int b = ajVar.m510b();
            int a = ajVar.m509a() - ajVar.m511c();
            if (a != 0) {
                if (i < 0) {
                    z = b > 0;
                } else if (b < a - 1) {
                    z = true;
                }
                if (z) {
                    return true;
                }
            }
            z = false;
            if (z) {
                return true;
            }
        }
        return false;
    }

    public int mo117b(View view) {
        return 0;
    }

    public bs mo118b(View view, bs bsVar) {
        return bsVar;
    }

    public void mo119b(View view, int i) {
    }

    public void mo120c(View view) {
    }

    public int mo121d(View view) {
        return 0;
    }

    public boolean mo122e(View view) {
        return true;
    }

    public void mo123f(View view) {
    }

    public boolean mo124g(View view) {
        return view.getWindowToken() != null;
    }
}
