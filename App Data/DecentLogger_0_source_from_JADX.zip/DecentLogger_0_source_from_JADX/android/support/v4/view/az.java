package android.support.v4.view;

import android.view.View;

final class az implements be {
    final /* synthetic */ ah f483a;
    final /* synthetic */ ay f484b;

    az(ay ayVar, ah ahVar) {
        this.f484b = ayVar;
        this.f483a = ahVar;
    }

    public final Object mo126a(View view, Object obj) {
        return bs.m598a(this.f483a.mo127a(view, bs.m597a(obj)));
    }
}
