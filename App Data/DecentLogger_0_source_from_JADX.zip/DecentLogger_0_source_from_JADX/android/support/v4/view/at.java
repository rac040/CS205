package android.support.v4.view;

import android.view.View;
import android.view.View.AccessibilityDelegate;

class at extends ar {
    static boolean f482b = false;

    at() {
    }

    public final void mo114a(View view, C0081b c0081b) {
        view.setAccessibilityDelegate((AccessibilityDelegate) (c0081b == null ? null : c0081b.f487a));
    }

    public final boolean mo116a(View view, int i) {
        return view.canScrollHorizontally(i);
    }
}
