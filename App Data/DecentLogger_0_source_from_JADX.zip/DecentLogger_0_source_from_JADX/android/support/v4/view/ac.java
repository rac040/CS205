package android.support.v4.view;

import android.os.Build.VERSION;
import android.view.MotionEvent;

public final class ac {
    static final ag f477a;

    static {
        if (VERSION.SDK_INT >= 14) {
            f477a = new af();
        } else if (VERSION.SDK_INT >= 12) {
            f477a = new ae();
        } else {
            f477a = new ad();
        }
    }

    public static int m503a(MotionEvent motionEvent) {
        return (motionEvent.getAction() & 65280) >> 8;
    }
}
