package android.support.v4.view;

import android.view.KeyEvent;

final class C0097q extends C0096p {
    C0097q() {
    }

    public final int mo166a(int i) {
        return KeyEvent.normalizeMetaState(i);
    }

    public final boolean mo164b(int i) {
        return KeyEvent.metaStateHasModifiers(i, 1);
    }

    public final boolean mo165c(int i) {
        return KeyEvent.metaStateHasNoModifiers(i);
    }
}
