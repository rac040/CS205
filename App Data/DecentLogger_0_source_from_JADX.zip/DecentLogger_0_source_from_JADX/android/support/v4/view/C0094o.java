package android.support.v4.view;

import android.os.Build.VERSION;
import android.view.KeyEvent;

public final class C0094o {
    static final C0095r f512a;

    static {
        if (VERSION.SDK_INT >= 11) {
            f512a = new C0097q();
        } else {
            f512a = new C0096p();
        }
    }

    public static boolean m687a(KeyEvent keyEvent) {
        return f512a.mo164b(keyEvent.getMetaState());
    }

    public static boolean m688b(KeyEvent keyEvent) {
        return f512a.mo165c(keyEvent.getMetaState());
    }
}
