package android.support.v4.view;

import android.view.View;

class au extends as {
    au() {
    }

    public final void mo112a(View view) {
        view.postInvalidateOnAnimation();
    }

    public final void mo115a(View view, Runnable runnable) {
        view.postOnAnimation(runnable);
    }

    public final int mo117b(View view) {
        return view.getImportantForAccessibility();
    }

    public void mo120c(View view) {
        view.setImportantForAccessibility(1);
    }

    public final boolean mo122e(View view) {
        return view.hasOverlappingRendering();
    }
}
