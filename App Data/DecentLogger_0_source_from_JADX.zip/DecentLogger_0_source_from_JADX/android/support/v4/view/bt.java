package android.support.v4.view;

import android.view.WindowInsets;

class bt extends bv {
    private bt() {
        super();
    }

    public final int mo131a(Object obj) {
        return ((WindowInsets) obj).getSystemWindowInsetBottom();
    }

    public final bs mo132a(Object obj, int i, int i2, int i3, int i4) {
        return new bs(((WindowInsets) obj).replaceSystemWindowInsets(i, i2, i3, i4));
    }

    public final int mo133b(Object obj) {
        return ((WindowInsets) obj).getSystemWindowInsetLeft();
    }

    public final int mo134c(Object obj) {
        return ((WindowInsets) obj).getSystemWindowInsetRight();
    }

    public final int mo135d(Object obj) {
        return ((WindowInsets) obj).getSystemWindowInsetTop();
    }
}
