package android.support.v4.view;

import android.os.Build.VERSION;

public final class bs {
    static final bw f504a;
    final Object f505b;

    static {
        int i = VERSION.SDK_INT;
        if (i >= 21) {
            f504a = new bu();
        } else if (i >= 20) {
            f504a = new bt();
        } else {
            f504a = new bv();
        }
    }

    private bs(Object obj) {
        this.f505b = obj;
    }

    static bs m597a(Object obj) {
        return obj == null ? null : new bs(obj);
    }

    static Object m598a(bs bsVar) {
        return bsVar == null ? null : bsVar.f505b;
    }

    public final int m599a() {
        return f504a.mo133b(this.f505b);
    }

    public final int m600b() {
        return f504a.mo135d(this.f505b);
    }

    public final int m601c() {
        return f504a.mo134c(this.f505b);
    }

    public final int m602d() {
        return f504a.mo131a(this.f505b);
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        bs bsVar = (bs) obj;
        return this.f505b == null ? bsVar.f505b == null : this.f505b.equals(bsVar.f505b);
    }

    public final int hashCode() {
        return this.f505b == null ? 0 : this.f505b.hashCode();
    }
}
