package android.support.v4.view.p004a;

import android.graphics.Rect;

public interface C0060m {
    int mo79a(Object obj);

    void mo80a(Object obj, int i);

    void mo81a(Object obj, Rect rect);

    void mo82a(Object obj, CharSequence charSequence);

    void mo83a(Object obj, boolean z);

    CharSequence mo84b(Object obj);

    void mo85b(Object obj, Rect rect);

    CharSequence mo86c(Object obj);

    CharSequence mo87d(Object obj);

    CharSequence mo88e(Object obj);

    boolean mo89f(Object obj);

    boolean mo90g(Object obj);

    boolean mo91h(Object obj);

    boolean mo92i(Object obj);

    boolean mo93j(Object obj);

    boolean mo94k(Object obj);

    boolean mo95l(Object obj);

    boolean mo96m(Object obj);

    boolean mo97n(Object obj);

    boolean mo98o(Object obj);

    String mo99p(Object obj);
}
