package android.support.v4.view.p004a;

final class C0074u extends C0073y {
    private C0074u() {
    }

    public final Object mo100a(C0071s c0071s) {
        return new aa(new C0075v(this, c0071s));
    }
}
