package android.support.v4.view.p004a;

import android.os.Bundle;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.accessibility.AccessibilityNodeProvider;
import java.util.List;

final class aa extends AccessibilityNodeProvider {
    final /* synthetic */ ab f464a;

    aa(ab abVar) {
        this.f464a = abVar;
    }

    public final AccessibilityNodeInfo createAccessibilityNodeInfo(int i) {
        this.f464a.mo103c();
        return null;
    }

    public final List findAccessibilityNodeInfosByText(String str, int i) {
        return this.f464a.mo102b();
    }

    public final boolean performAction(int i, int i2, Bundle bundle) {
        return this.f464a.mo101a();
    }
}
