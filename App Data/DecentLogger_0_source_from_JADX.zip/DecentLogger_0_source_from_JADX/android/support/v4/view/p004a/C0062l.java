package android.support.v4.view.p004a;

import android.graphics.Rect;
import android.view.accessibility.AccessibilityNodeInfo;

class C0062l extends C0061r {
    C0062l() {
    }

    public final int mo79a(Object obj) {
        return ((AccessibilityNodeInfo) obj).getActions();
    }

    public final void mo80a(Object obj, int i) {
        ((AccessibilityNodeInfo) obj).addAction(i);
    }

    public final void mo81a(Object obj, Rect rect) {
        ((AccessibilityNodeInfo) obj).getBoundsInParent(rect);
    }

    public final void mo82a(Object obj, CharSequence charSequence) {
        ((AccessibilityNodeInfo) obj).setClassName(charSequence);
    }

    public final void mo83a(Object obj, boolean z) {
        ((AccessibilityNodeInfo) obj).setScrollable(z);
    }

    public final CharSequence mo84b(Object obj) {
        return ((AccessibilityNodeInfo) obj).getClassName();
    }

    public final void mo85b(Object obj, Rect rect) {
        ((AccessibilityNodeInfo) obj).getBoundsInScreen(rect);
    }

    public final CharSequence mo86c(Object obj) {
        return ((AccessibilityNodeInfo) obj).getContentDescription();
    }

    public final CharSequence mo87d(Object obj) {
        return ((AccessibilityNodeInfo) obj).getPackageName();
    }

    public final CharSequence mo88e(Object obj) {
        return ((AccessibilityNodeInfo) obj).getText();
    }

    public final boolean mo89f(Object obj) {
        return ((AccessibilityNodeInfo) obj).isCheckable();
    }

    public final boolean mo90g(Object obj) {
        return ((AccessibilityNodeInfo) obj).isChecked();
    }

    public final boolean mo91h(Object obj) {
        return ((AccessibilityNodeInfo) obj).isClickable();
    }

    public final boolean mo92i(Object obj) {
        return ((AccessibilityNodeInfo) obj).isEnabled();
    }

    public final boolean mo93j(Object obj) {
        return ((AccessibilityNodeInfo) obj).isFocusable();
    }

    public final boolean mo94k(Object obj) {
        return ((AccessibilityNodeInfo) obj).isFocused();
    }

    public final boolean mo95l(Object obj) {
        return ((AccessibilityNodeInfo) obj).isLongClickable();
    }

    public final boolean mo96m(Object obj) {
        return ((AccessibilityNodeInfo) obj).isPassword();
    }

    public final boolean mo97n(Object obj) {
        return ((AccessibilityNodeInfo) obj).isScrollable();
    }

    public final boolean mo98o(Object obj) {
        return ((AccessibilityNodeInfo) obj).isSelected();
    }
}
