package android.support.v4.view.p004a;

import java.util.List;

final class C0077x implements ae {
    final /* synthetic */ C0071s f474a;
    final /* synthetic */ C0076w f475b;

    C0077x(C0076w c0076w, C0071s c0071s) {
        this.f475b = c0076w;
        this.f474a = c0071s;
    }

    public final boolean mo104a() {
        return C0071s.m487b();
    }

    public final List mo105b() {
        C0071s.m488c();
        return null;
    }

    public final Object mo106c() {
        C0071s.m486a();
        return null;
    }

    public final Object mo107d() {
        C0071s.m489d();
        return null;
    }
}
