package android.support.v4.view.p004a;

import android.os.Build.VERSION;

public final class af {
    public static final ai f466a;
    public final Object f467b;

    static {
        if (VERSION.SDK_INT >= 16) {
            f466a = new aj();
        } else if (VERSION.SDK_INT >= 15) {
            f466a = new ah();
        } else if (VERSION.SDK_INT >= 14) {
            f466a = new ag();
        } else {
            f466a = new ak();
        }
    }

    @Deprecated
    public af(Object obj) {
        this.f467b = obj;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        af afVar = (af) obj;
        return this.f467b == null ? afVar.f467b == null : this.f467b.equals(afVar.f467b);
    }

    public final int hashCode() {
        return this.f467b == null ? 0 : this.f467b.hashCode();
    }
}
