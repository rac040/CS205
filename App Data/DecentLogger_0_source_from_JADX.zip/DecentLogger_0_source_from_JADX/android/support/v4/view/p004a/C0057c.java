package android.support.v4.view.p004a;

class C0057c extends C0056b {
    C0057c() {
    }
}
