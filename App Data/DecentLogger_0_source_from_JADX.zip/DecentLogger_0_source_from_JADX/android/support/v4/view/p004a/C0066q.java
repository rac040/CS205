package android.support.v4.view.p004a;

class C0066q extends C0065p {
    C0066q() {
    }
}
