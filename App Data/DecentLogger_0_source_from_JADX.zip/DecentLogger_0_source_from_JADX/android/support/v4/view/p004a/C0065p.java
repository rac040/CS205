package android.support.v4.view.p004a;

import android.view.accessibility.AccessibilityNodeInfo;

class C0065p extends C0064o {
    C0065p() {
    }

    public final String mo99p(Object obj) {
        return ((AccessibilityNodeInfo) obj).getViewIdResourceName();
    }
}
