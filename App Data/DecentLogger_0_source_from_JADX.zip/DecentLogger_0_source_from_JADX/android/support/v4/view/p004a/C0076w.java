package android.support.v4.view.p004a;

final class C0076w extends C0073y {
    private C0076w() {
    }

    public final Object mo100a(C0071s c0071s) {
        return new ad(new C0077x(this, c0071s));
    }
}
