package android.support.v4.view.p004a;

interface C0072t {
    Object mo100a(C0071s c0071s);
}
