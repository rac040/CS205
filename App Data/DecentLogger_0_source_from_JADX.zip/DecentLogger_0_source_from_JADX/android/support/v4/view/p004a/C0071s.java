package android.support.v4.view.p004a;

import android.os.Build.VERSION;
import java.util.List;

public final class C0071s {
    private static final C0072t f470b;
    public final Object f471a;

    static {
        if (VERSION.SDK_INT >= 19) {
            f470b = new C0076w();
        } else if (VERSION.SDK_INT >= 16) {
            f470b = new C0074u();
        } else {
            f470b = new C0073y();
        }
    }

    public C0071s() {
        this.f471a = f470b.mo100a(this);
    }

    public C0071s(Object obj) {
        this.f471a = obj;
    }

    public static C0059g m486a() {
        return null;
    }

    public static boolean m487b() {
        return false;
    }

    public static List m488c() {
        return null;
    }

    public static C0059g m489d() {
        return null;
    }
}
