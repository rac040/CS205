package android.support.v4.view.p004a;

class C0056b extends C0055e {
    C0056b() {
    }
}
