package android.support.v4.view.p004a;

import android.graphics.Rect;
import android.os.Build.VERSION;
import android.support.wearable.C0107c;

public final class C0059g {
    public static final C0060m f468a;
    public final Object f469b;

    static {
        if (VERSION.SDK_INT >= 24) {
            f468a = new C0070k();
        } else if (VERSION.SDK_INT >= 23) {
            f468a = new C0069j();
        } else if (VERSION.SDK_INT >= 22) {
            f468a = new C0068i();
        } else if (VERSION.SDK_INT >= 21) {
            f468a = new C0067h();
        } else if (VERSION.SDK_INT >= 19) {
            f468a = new C0066q();
        } else if (VERSION.SDK_INT >= 18) {
            f468a = new C0065p();
        } else if (VERSION.SDK_INT >= 17) {
            f468a = new C0064o();
        } else if (VERSION.SDK_INT >= 16) {
            f468a = new C0063n();
        } else if (VERSION.SDK_INT >= 14) {
            f468a = new C0062l();
        } else {
            f468a = new C0061r();
        }
    }

    public C0059g(Object obj) {
        this.f469b = obj;
    }

    public final void m422a(int i) {
        f468a.mo80a(this.f469b, i);
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        C0059g c0059g = (C0059g) obj;
        return this.f469b == null ? c0059g.f469b == null : this.f469b.equals(c0059g.f469b);
    }

    public final int hashCode() {
        return this.f469b == null ? 0 : this.f469b.hashCode();
    }

    public final String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(super.toString());
        Rect rect = new Rect();
        f468a.mo81a(this.f469b, rect);
        stringBuilder.append("; boundsInParent: " + rect);
        f468a.mo85b(this.f469b, rect);
        stringBuilder.append("; boundsInScreen: " + rect);
        stringBuilder.append("; packageName: ").append(f468a.mo87d(this.f469b));
        stringBuilder.append("; className: ").append(f468a.mo84b(this.f469b));
        stringBuilder.append("; text: ").append(f468a.mo88e(this.f469b));
        stringBuilder.append("; contentDescription: ").append(f468a.mo86c(this.f469b));
        stringBuilder.append("; viewId: ").append(f468a.mo99p(this.f469b));
        stringBuilder.append("; checkable: ").append(f468a.mo89f(this.f469b));
        stringBuilder.append("; checked: ").append(f468a.mo90g(this.f469b));
        stringBuilder.append("; focusable: ").append(f468a.mo93j(this.f469b));
        stringBuilder.append("; focused: ").append(f468a.mo94k(this.f469b));
        stringBuilder.append("; selected: ").append(f468a.mo98o(this.f469b));
        stringBuilder.append("; clickable: ").append(f468a.mo91h(this.f469b));
        stringBuilder.append("; longClickable: ").append(f468a.mo95l(this.f469b));
        stringBuilder.append("; enabled: ").append(f468a.mo92i(this.f469b));
        stringBuilder.append("; password: ").append(f468a.mo96m(this.f469b));
        stringBuilder.append("; scrollable: " + f468a.mo97n(this.f469b));
        stringBuilder.append("; [");
        int a = f468a.mo79a(this.f469b);
        while (a != 0) {
            String str;
            int numberOfTrailingZeros = 1 << Integer.numberOfTrailingZeros(a);
            int i = (numberOfTrailingZeros ^ -1) & a;
            switch (numberOfTrailingZeros) {
                case 1:
                    str = "ACTION_FOCUS";
                    break;
                case 2:
                    str = "ACTION_CLEAR_FOCUS";
                    break;
                case 4:
                    str = "ACTION_SELECT";
                    break;
                case 8:
                    str = "ACTION_CLEAR_SELECTION";
                    break;
                case C0107c.ActionPage_buttonRippleColor /*16*/:
                    str = "ACTION_CLICK";
                    break;
                case 32:
                    str = "ACTION_LONG_CLICK";
                    break;
                case 64:
                    str = "ACTION_ACCESSIBILITY_FOCUS";
                    break;
                case 128:
                    str = "ACTION_CLEAR_ACCESSIBILITY_FOCUS";
                    break;
                case 256:
                    str = "ACTION_NEXT_AT_MOVEMENT_GRANULARITY";
                    break;
                case 512:
                    str = "ACTION_PREVIOUS_AT_MOVEMENT_GRANULARITY";
                    break;
                case 1024:
                    str = "ACTION_NEXT_HTML_ELEMENT";
                    break;
                case 2048:
                    str = "ACTION_PREVIOUS_HTML_ELEMENT";
                    break;
                case 4096:
                    str = "ACTION_SCROLL_FORWARD";
                    break;
                case 8192:
                    str = "ACTION_SCROLL_BACKWARD";
                    break;
                case 16384:
                    str = "ACTION_COPY";
                    break;
                case 32768:
                    str = "ACTION_PASTE";
                    break;
                case 65536:
                    str = "ACTION_CUT";
                    break;
                case 131072:
                    str = "ACTION_SET_SELECTION";
                    break;
                default:
                    str = "ACTION_UNKNOWN";
                    break;
            }
            stringBuilder.append(str);
            if (i != 0) {
                stringBuilder.append(", ");
            }
            a = i;
        }
        stringBuilder.append("]");
        return stringBuilder.toString();
    }
}
