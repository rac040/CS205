package android.support.v4.view.p004a;

import android.os.Bundle;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.accessibility.AccessibilityNodeProvider;
import java.util.List;

final class ad extends AccessibilityNodeProvider {
    final /* synthetic */ ae f465a;

    ad(ae aeVar) {
        this.f465a = aeVar;
    }

    public final AccessibilityNodeInfo createAccessibilityNodeInfo(int i) {
        this.f465a.mo106c();
        return null;
    }

    public final List findAccessibilityNodeInfosByText(String str, int i) {
        return this.f465a.mo105b();
    }

    public final AccessibilityNodeInfo findFocus(int i) {
        this.f465a.mo107d();
        return null;
    }

    public final boolean performAction(int i, int i2, Bundle bundle) {
        return this.f465a.mo104a();
    }
}
