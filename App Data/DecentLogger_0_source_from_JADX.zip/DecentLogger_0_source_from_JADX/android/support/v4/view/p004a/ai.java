package android.support.v4.view.p004a;

public interface ai {
    void mo75a(Object obj, int i);

    void mo76a(Object obj, boolean z);

    void mo77b(Object obj, int i);

    void mo78c(Object obj, int i);
}
