package android.support.v4.view.p004a;

class ak implements ai {
    ak() {
    }

    public void mo75a(Object obj, int i) {
    }

    public void mo76a(Object obj, boolean z) {
    }

    public void mo77b(Object obj, int i) {
    }

    public void mo78c(Object obj, int i) {
    }
}
