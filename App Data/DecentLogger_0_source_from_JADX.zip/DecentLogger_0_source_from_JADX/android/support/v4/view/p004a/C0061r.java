package android.support.v4.view.p004a;

import android.graphics.Rect;

class C0061r implements C0060m {
    C0061r() {
    }

    public int mo79a(Object obj) {
        return 0;
    }

    public void mo80a(Object obj, int i) {
    }

    public void mo81a(Object obj, Rect rect) {
    }

    public void mo82a(Object obj, CharSequence charSequence) {
    }

    public void mo83a(Object obj, boolean z) {
    }

    public CharSequence mo84b(Object obj) {
        return null;
    }

    public void mo85b(Object obj, Rect rect) {
    }

    public CharSequence mo86c(Object obj) {
        return null;
    }

    public CharSequence mo87d(Object obj) {
        return null;
    }

    public CharSequence mo88e(Object obj) {
        return null;
    }

    public boolean mo89f(Object obj) {
        return false;
    }

    public boolean mo90g(Object obj) {
        return false;
    }

    public boolean mo91h(Object obj) {
        return false;
    }

    public boolean mo92i(Object obj) {
        return false;
    }

    public boolean mo93j(Object obj) {
        return false;
    }

    public boolean mo94k(Object obj) {
        return false;
    }

    public boolean mo95l(Object obj) {
        return false;
    }

    public boolean mo96m(Object obj) {
        return false;
    }

    public boolean mo97n(Object obj) {
        return false;
    }

    public boolean mo98o(Object obj) {
        return false;
    }

    public String mo99p(Object obj) {
        return null;
    }
}
