package android.support.v4.view.p004a;

final class C0070k extends C0069j {
    C0070k() {
    }
}
