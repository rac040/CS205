package android.support.v4.view.p004a;

import java.util.List;

interface ae {
    boolean mo104a();

    List mo105b();

    Object mo106c();

    Object mo107d();
}
