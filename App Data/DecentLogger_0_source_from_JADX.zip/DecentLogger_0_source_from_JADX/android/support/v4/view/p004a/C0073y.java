package android.support.v4.view.p004a;

class C0073y implements C0072t {
    C0073y() {
    }

    public Object mo100a(C0071s c0071s) {
        return null;
    }
}
