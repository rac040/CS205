package android.support.v4.view.p004a;

import android.os.Build.VERSION;
import android.view.accessibility.AccessibilityEvent;

public final class C0053a {
    private static final C0054f f463a;

    static {
        if (VERSION.SDK_INT >= 19) {
            f463a = new C0058d();
        } else if (VERSION.SDK_INT >= 16) {
            f463a = new C0057c();
        } else if (VERSION.SDK_INT >= 14) {
            f463a = new C0056b();
        } else {
            f463a = new C0055e();
        }
    }

    public static af m402a(AccessibilityEvent accessibilityEvent) {
        return new af(accessibilityEvent);
    }
}
