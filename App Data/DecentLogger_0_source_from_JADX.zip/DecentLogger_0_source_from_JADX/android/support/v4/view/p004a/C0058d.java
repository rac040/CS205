package android.support.v4.view.p004a;

final class C0058d extends C0057c {
    C0058d() {
    }
}
