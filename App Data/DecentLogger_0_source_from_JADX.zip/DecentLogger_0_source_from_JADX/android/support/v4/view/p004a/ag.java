package android.support.v4.view.p004a;

import android.view.accessibility.AccessibilityRecord;

class ag extends ak {
    ag() {
    }

    public final void mo75a(Object obj, int i) {
        ((AccessibilityRecord) obj).setFromIndex(i);
    }

    public final void mo76a(Object obj, boolean z) {
        ((AccessibilityRecord) obj).setScrollable(z);
    }

    public final void mo77b(Object obj, int i) {
        ((AccessibilityRecord) obj).setItemCount(i);
    }

    public final void mo78c(Object obj, int i) {
        ((AccessibilityRecord) obj).setToIndex(i);
    }
}
