package android.support.v4.view.p004a;

import java.util.List;

final class C0075v implements ab {
    final /* synthetic */ C0071s f472a;
    final /* synthetic */ C0074u f473b;

    C0075v(C0074u c0074u, C0071s c0071s) {
        this.f473b = c0074u;
        this.f472a = c0071s;
    }

    public final boolean mo101a() {
        return C0071s.m487b();
    }

    public final List mo102b() {
        C0071s.m488c();
        return null;
    }

    public final Object mo103c() {
        C0071s.m486a();
        return null;
    }
}
