package android.support.v4.view.p004a;

import java.util.List;

interface ab {
    boolean mo101a();

    List mo102b();

    Object mo103c();
}
