package android.support.v4.view;

import android.view.LayoutInflater;
import android.view.LayoutInflater.Factory;
import android.view.LayoutInflater.Factory2;

class C0101v extends C0100u {
    C0101v() {
    }

    public void mo167a(LayoutInflater layoutInflater, ab abVar) {
        Factory2 aaVar = abVar != null ? new aa(abVar) : null;
        layoutInflater.setFactory2(aaVar);
        Factory factory = layoutInflater.getFactory();
        if (factory instanceof Factory2) {
            C0104z.m703a(layoutInflater, (Factory2) factory);
        } else {
            C0104z.m703a(layoutInflater, aaVar);
        }
    }
}
