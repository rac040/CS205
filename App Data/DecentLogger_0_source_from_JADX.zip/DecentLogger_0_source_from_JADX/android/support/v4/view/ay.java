package android.support.v4.view;

import android.view.View;
import android.view.WindowInsets;

class ay extends ax {
    ay() {
    }

    public final bs mo111a(View view, bs bsVar) {
        Object a = bs.m598a(bsVar);
        WindowInsets windowInsets = (WindowInsets) a;
        WindowInsets onApplyWindowInsets = view.onApplyWindowInsets(windowInsets);
        if (onApplyWindowInsets != windowInsets) {
            a = new WindowInsets(onApplyWindowInsets);
        }
        return bs.m597a(a);
    }

    public final void mo113a(View view, ah ahVar) {
        if (ahVar == null) {
            bc.m586a(view, null);
        } else {
            bc.m586a(view, new az(this, ahVar));
        }
    }

    public final bs mo118b(View view, bs bsVar) {
        Object a = bs.m598a(bsVar);
        WindowInsets windowInsets = (WindowInsets) a;
        WindowInsets dispatchApplyWindowInsets = view.dispatchApplyWindowInsets(windowInsets);
        if (dispatchApplyWindowInsets != windowInsets) {
            a = new WindowInsets(dispatchApplyWindowInsets);
        }
        return bs.m597a(a);
    }
}
