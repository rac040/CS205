package android.support.v4.view;

import android.os.Build.VERSION;
import android.view.LayoutInflater;

public final class C0098s {
    static final C0099t f513a;

    static {
        int i = VERSION.SDK_INT;
        if (i >= 21) {
            f513a = new C0102w();
        } else if (i >= 11) {
            f513a = new C0101v();
        } else {
            f513a = new C0100u();
        }
    }

    public static void m698a(LayoutInflater layoutInflater, ab abVar) {
        f513a.mo167a(layoutInflater, abVar);
    }
}
