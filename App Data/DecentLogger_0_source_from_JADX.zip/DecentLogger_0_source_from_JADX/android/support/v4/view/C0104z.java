package android.support.v4.view;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.LayoutInflater.Factory2;
import java.lang.reflect.Field;

final class C0104z {
    private static Field f514a;
    private static boolean f515b;

    static void m703a(LayoutInflater layoutInflater, Factory2 factory2) {
        if (!f515b) {
            try {
                Field declaredField = LayoutInflater.class.getDeclaredField("mFactory2");
                f514a = declaredField;
                declaredField.setAccessible(true);
            } catch (Throwable e) {
                Log.e("LayoutInflaterCompatHC", "forceSetFactory2 Could not find field 'mFactory2' on class " + LayoutInflater.class.getName() + "; inflation may have unexpected results.", e);
            }
            f515b = true;
        }
        if (f514a != null) {
            try {
                f514a.set(layoutInflater, factory2);
            } catch (Throwable e2) {
                Log.e("LayoutInflaterCompatHC", "forceSetFactory2 could not set the Factory2 on LayoutInflater " + layoutInflater + "; inflation may have unexpected results.", e2);
            }
        }
    }
}
