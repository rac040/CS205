package android.support.v4.view;

import android.graphics.Rect;
import android.view.View;

final class bi implements ah {
    final /* synthetic */ ViewPager f490a;
    private final Rect f491b = new Rect();

    bi(ViewPager viewPager) {
        this.f490a = viewPager;
    }

    public final bs mo127a(View view, bs bsVar) {
        bs a = ao.m516a(view, bsVar);
        if (bs.f504a.mo136e(a.f505b)) {
            return a;
        }
        Rect rect = this.f491b;
        rect.left = a.m599a();
        rect.top = a.m600b();
        rect.right = a.m601c();
        rect.bottom = a.m602d();
        int childCount = this.f490a.getChildCount();
        for (int i = 0; i < childCount; i++) {
            bs b = ao.m523b(this.f490a.getChildAt(i), a);
            rect.left = Math.min(b.m599a(), rect.left);
            rect.top = Math.min(b.m600b(), rect.top);
            rect.right = Math.min(b.m601c(), rect.right);
            rect.bottom = Math.min(b.m602d(), rect.bottom);
        }
        return bs.f504a.mo132a(a.f505b, rect.left, rect.top, rect.right, rect.bottom);
    }
}
