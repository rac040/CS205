package android.support.v4.view;

import android.os.Bundle;
import android.support.v4.view.p004a.C0053a;
import android.support.v4.view.p004a.C0059g;
import android.support.v4.view.p004a.af;
import android.view.View;
import android.view.accessibility.AccessibilityEvent;

final class bm extends C0081b {
    final /* synthetic */ ViewPager f502b;

    bm(ViewPager viewPager) {
        this.f502b = viewPager;
    }

    private boolean m588a() {
        return this.f502b.f444h != null && this.f502b.f444h.m506a() > 1;
    }

    public final void mo128a(View view, C0059g c0059g) {
        super.mo128a(view, c0059g);
        C0059g.f468a.mo82a(c0059g.f469b, ViewPager.class.getName());
        C0059g.f468a.mo83a(c0059g.f469b, m588a());
        if (this.f502b.canScrollHorizontally(1)) {
            c0059g.m422a(4096);
        }
        if (this.f502b.canScrollHorizontally(-1)) {
            c0059g.m422a(8192);
        }
    }

    public final boolean mo129a(View view, int i, Bundle bundle) {
        if (super.mo129a(view, i, bundle)) {
            return true;
        }
        switch (i) {
            case 4096:
                if (!this.f502b.canScrollHorizontally(1)) {
                    return false;
                }
                this.f502b.setCurrentItem(this.f502b.f445i + 1);
                return true;
            case 8192:
                if (!this.f502b.canScrollHorizontally(-1)) {
                    return false;
                }
                this.f502b.setCurrentItem(this.f502b.f445i - 1);
                return true;
            default:
                return false;
        }
    }

    public final void mo130d(View view, AccessibilityEvent accessibilityEvent) {
        super.mo130d(view, accessibilityEvent);
        accessibilityEvent.setClassName(ViewPager.class.getName());
        af a = C0053a.m402a(accessibilityEvent);
        af.f466a.mo76a(a.f467b, m588a());
        if (accessibilityEvent.getEventType() == 4096 && this.f502b.f444h != null) {
            af.f466a.mo77b(a.f467b, this.f502b.f444h.m506a());
            af.f466a.mo75a(a.f467b, this.f502b.f445i);
            af.f466a.mo78c(a.f467b, this.f502b.f445i);
        }
    }
}
