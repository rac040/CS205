package android.support.v4.view;

import android.os.Bundle;
import android.support.v4.view.p004a.C0059g;
import android.support.v4.view.p004a.C0071s;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityEvent;

final class C0089g implements C0088n {
    final /* synthetic */ C0081b f508a;
    final /* synthetic */ C0087f f509b;

    C0089g(C0087f c0087f, C0081b c0081b) {
        this.f509b = c0087f;
        this.f508a = c0081b;
    }

    public final Object mo155a(View view) {
        C0071s a = C0081b.m577a(view);
        return a != null ? a.f471a : null;
    }

    public final void mo156a(View view, int i) {
        C0081b.m578a(view, i);
    }

    public final void mo157a(View view, Object obj) {
        this.f508a.mo128a(view, new C0059g(obj));
    }

    public final boolean mo158a(View view, int i, Bundle bundle) {
        return this.f508a.mo129a(view, i, bundle);
    }

    public final boolean mo159a(View view, AccessibilityEvent accessibilityEvent) {
        return C0081b.m581b(view, accessibilityEvent);
    }

    public final boolean mo160a(ViewGroup viewGroup, View view, AccessibilityEvent accessibilityEvent) {
        return C0081b.m580a(viewGroup, view, accessibilityEvent);
    }

    public final void mo161b(View view, AccessibilityEvent accessibilityEvent) {
        this.f508a.mo130d(view, accessibilityEvent);
    }

    public final void mo162c(View view, AccessibilityEvent accessibilityEvent) {
        C0081b.m582c(view, accessibilityEvent);
    }

    public final void mo163d(View view, AccessibilityEvent accessibilityEvent) {
        C0081b.m579a(view, accessibilityEvent);
    }
}
