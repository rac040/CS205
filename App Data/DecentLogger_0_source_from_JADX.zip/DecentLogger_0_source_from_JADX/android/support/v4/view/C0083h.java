package android.support.v4.view;

import android.os.Bundle;
import android.support.v4.view.p004a.C0059g;
import android.support.v4.view.p004a.C0071s;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityEvent;

class C0083h implements C0082e {
    C0083h() {
    }

    public C0071s mo137a(Object obj, View view) {
        return null;
    }

    public Object mo138a() {
        return null;
    }

    public Object mo139a(C0081b c0081b) {
        return null;
    }

    public void mo140a(Object obj, View view, int i) {
    }

    public void mo141a(Object obj, View view, C0059g c0059g) {
    }

    public boolean mo142a(Object obj, View view, int i, Bundle bundle) {
        return false;
    }

    public boolean mo143a(Object obj, View view, AccessibilityEvent accessibilityEvent) {
        return false;
    }

    public boolean mo144a(Object obj, ViewGroup viewGroup, View view, AccessibilityEvent accessibilityEvent) {
        return true;
    }

    public void mo145b(Object obj, View view, AccessibilityEvent accessibilityEvent) {
    }

    public void mo146c(Object obj, View view, AccessibilityEvent accessibilityEvent) {
    }

    public void mo147d(Object obj, View view, AccessibilityEvent accessibilityEvent) {
    }
}
