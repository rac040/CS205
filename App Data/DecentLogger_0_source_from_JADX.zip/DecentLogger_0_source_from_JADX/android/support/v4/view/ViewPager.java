package android.support.v4.view;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build.VERSION;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import android.support.v4.p001b.C0030b;
import android.support.v4.p003d.C0047a;
import android.support.wearable.C0107c;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.View.MeasureSpec;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.view.ViewParent;
import android.view.accessibility.AccessibilityEvent;
import android.view.animation.Interpolator;
import android.widget.Scroller;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class ViewPager extends ViewGroup {
    private static final int[] f414a = new int[]{16842931};
    private static final br ai = new br();
    private static final Comparator f415c = new bf();
    private static final Interpolator f416d = new bg();
    private int f417A = 1;
    private boolean f418B;
    private boolean f419C;
    private int f420D;
    private int f421E;
    private int f422F;
    private float f423G;
    private float f424H;
    private float f425I;
    private float f426J;
    private int f427K = -1;
    private VelocityTracker f428L;
    private int f429M;
    private int f430N;
    private int f431O;
    private int f432P;
    private boolean f433Q;
    private C0047a f434R;
    private C0047a f435S;
    private boolean f436T = true;
    private boolean f437U = false;
    private boolean f438V;
    private int f439W;
    private List aa;
    private bn ab;
    private bn ac;
    private List ad;
    private bo ae;
    private Method af;
    private int ag;
    private ArrayList ah;
    private final Runnable aj = new bh(this);
    private int ak = 0;
    private int f440b;
    private final ArrayList f441e = new ArrayList();
    private final bk f442f = new bk();
    private final Rect f443g = new Rect();
    private ai f444h;
    private int f445i;
    private int f446j = -1;
    private Parcelable f447k = null;
    private ClassLoader f448l = null;
    private Scroller f449m;
    private boolean f450n;
    private bp f451o;
    private int f452p;
    private Drawable f453q;
    private int f454r;
    private int f455s;
    private float f456t = -3.4028235E38f;
    private float f457u = Float.MAX_VALUE;
    private int f458v;
    private int f459w;
    private boolean f460x;
    private boolean f461y;
    private boolean f462z;

    public class SavedState extends AbsSavedState {
        public static final Creator CREATOR = C0030b.m295a(new bq());
        int f411c;
        Parcelable f412d;
        ClassLoader f413e;

        SavedState(Parcel parcel, ClassLoader classLoader) {
            super(parcel, classLoader);
            if (classLoader == null) {
                classLoader = getClass().getClassLoader();
            }
            this.f411c = parcel.readInt();
            this.f412d = parcel.readParcelable(classLoader);
            this.f413e = classLoader;
        }

        public SavedState(Parcelable parcelable) {
            super(parcelable);
        }

        public String toString() {
            return "FragmentPager.SavedState{" + Integer.toHexString(System.identityHashCode(this)) + " position=" + this.f411c + "}";
        }

        public void writeToParcel(Parcel parcel, int i) {
            super.writeToParcel(parcel, i);
            parcel.writeInt(this.f411c);
            parcel.writeParcelable(this.f412d, i);
        }
    }

    public ViewPager(Context context) {
        super(context);
        m390d();
    }

    public ViewPager(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        m390d();
    }

    private Rect m371a(Rect rect, View view) {
        Rect rect2 = rect == null ? new Rect() : rect;
        if (view == null) {
            rect2.set(0, 0, 0, 0);
            return rect2;
        }
        rect2.left = view.getLeft();
        rect2.right = view.getRight();
        rect2.top = view.getTop();
        rect2.bottom = view.getBottom();
        ViewPager parent = view.getParent();
        while ((parent instanceof ViewGroup) && parent != this) {
            ViewGroup viewGroup = parent;
            rect2.left += viewGroup.getLeft();
            rect2.right += viewGroup.getRight();
            rect2.top += viewGroup.getTop();
            rect2.bottom += viewGroup.getBottom();
            parent = viewGroup.getParent();
        }
        return rect2;
    }

    private static bk m372a(int i) {
        new bk().f492a = i;
        throw new UnsupportedOperationException("Required method instantiateItem was not overridden");
    }

    private bk m373a(View view) {
        while (true) {
            ViewPager parent = view.getParent();
            if (parent == this) {
                return m394f();
            }
            if (parent != null && (parent instanceof View)) {
                view = parent;
            }
        }
        return null;
    }

    private void m374a(float f) {
        int paddingLeft;
        int paddingRight;
        if (this.f439W > 0) {
            int scrollX = getScrollX();
            paddingLeft = getPaddingLeft();
            paddingRight = getPaddingRight();
            int width = getWidth();
            int childCount = getChildCount();
            for (int i = 0; i < childCount; i++) {
                View childAt = getChildAt(i);
                bl blVar = (bl) childAt.getLayoutParams();
                if (blVar.f496a) {
                    int max;
                    switch (blVar.f497b & 7) {
                        case 1:
                            max = Math.max((width - childAt.getMeasuredWidth()) / 2, paddingLeft);
                            break;
                        case 3:
                            int i2 = paddingLeft;
                            paddingLeft = childAt.getWidth() + paddingLeft;
                            max = i2;
                            break;
                        case 5:
                            max = (width - paddingRight) - childAt.getMeasuredWidth();
                            paddingRight += childAt.getMeasuredWidth();
                            break;
                        default:
                            max = paddingLeft;
                            break;
                    }
                    max = (max + scrollX) - childAt.getLeft();
                    if (max != 0) {
                        childAt.offsetLeftAndRight(max);
                    }
                }
            }
        }
        if (this.ab != null) {
            this.ab.mo168a(f);
        }
        if (this.aa != null) {
            paddingRight = this.aa.size();
            for (paddingLeft = 0; paddingLeft < paddingRight; paddingLeft++) {
                bn bnVar = (bn) this.aa.get(paddingLeft);
                if (bnVar != null) {
                    bnVar.mo168a(f);
                }
            }
        }
        if (this.ac != null) {
            this.ac.mo168a(f);
        }
        if (this.ae != null) {
            getScrollX();
            paddingRight = getChildCount();
            for (paddingLeft = 0; paddingLeft < paddingRight; paddingLeft++) {
                View childAt2 = getChildAt(paddingLeft);
                if (!((bl) childAt2.getLayoutParams()).f496a) {
                    childAt2.getLeft();
                    getClientWidth();
                }
            }
        }
        this.f438V = true;
    }

    private void m375a(int i, int i2, int i3, int i4) {
        if (i2 <= 0 || this.f441e.isEmpty()) {
            bk c = m388c(this.f445i);
            int min = (int) ((c != null ? Math.min(c.f495d, this.f457u) : 0.0f) * ((float) ((i - getPaddingLeft()) - getPaddingRight())));
            if (min != getScrollX()) {
                m382a(false);
                scrollTo(min, getScrollY());
            }
        } else if (this.f449m.isFinished()) {
            scrollTo((int) (((float) (((i - getPaddingLeft()) - getPaddingRight()) + i3)) * (((float) getScrollX()) / ((float) (((i2 - getPaddingLeft()) - getPaddingRight()) + i4)))), getScrollY());
        } else {
            this.f449m.setFinalX(getCurrentItem() * getClientWidth());
        }
    }

    private void m376a(int i, boolean z, int i2, boolean z2) {
        bk c = m388c(i);
        int clientWidth = c != null ? (int) (((float) getClientWidth()) * Math.max(this.f456t, Math.min(c.f495d, this.f457u))) : 0;
        if (z) {
            if (getChildCount() == 0) {
                setScrollingCacheEnabled(false);
            } else {
                int currX;
                int i3;
                Object obj = (this.f449m == null || this.f449m.isFinished()) ? null : 1;
                if (obj != null) {
                    currX = this.f450n ? this.f449m.getCurrX() : this.f449m.getStartX();
                    this.f449m.abortAnimation();
                    setScrollingCacheEnabled(false);
                    i3 = currX;
                } else {
                    i3 = getScrollX();
                }
                int scrollY = getScrollY();
                clientWidth -= i3;
                int i4 = 0 - scrollY;
                if (clientWidth == 0 && i4 == 0) {
                    m382a(false);
                    m401b();
                    setScrollState(0);
                } else {
                    setScrollingCacheEnabled(true);
                    setScrollState(2);
                    currX = getClientWidth();
                    int i5 = currX / 2;
                    float sin = (((float) i5) * ((float) Math.sin((double) ((float) (((double) (Math.min(1.0f, (1.0f * ((float) Math.abs(clientWidth))) / ((float) currX)) - 0.5f)) * 0.4712389167638204d))))) + ((float) i5);
                    int abs = Math.abs(i2);
                    i5 = Math.min(abs > 0 ? Math.round(1000.0f * Math.abs(sin / ((float) abs))) * 4 : (int) (((((float) Math.abs(clientWidth)) / ((((float) currX) * 1.0f) + ((float) this.f452p))) + 1.0f) * 100.0f), 600);
                    this.f450n = false;
                    this.f449m.startScroll(i3, scrollY, clientWidth, i4, i5);
                    ao.m517a(this);
                }
            }
            if (z2) {
                m393e(i);
                return;
            }
            return;
        }
        if (z2) {
            m393e(i);
        }
        m382a(false);
        scrollTo(clientWidth, 0);
        m391d(clientWidth);
    }

    private void m377a(int i, boolean z, boolean z2) {
        m378a(i, z, z2, 0);
    }

    private void m378a(int i, boolean z, boolean z2, int i2) {
        boolean z3 = false;
        if (this.f444h == null || this.f444h.m506a() <= 0) {
            setScrollingCacheEnabled(false);
        } else if (z2 || this.f445i != i || this.f441e.size() == 0) {
            if (i < 0) {
                i = 0;
            } else if (i >= this.f444h.m506a()) {
                i = this.f444h.m506a() - 1;
            }
            int i3 = this.f417A;
            if (i > this.f445i + i3 || i < this.f445i - i3) {
                for (int i4 = 0; i4 < this.f441e.size(); i4++) {
                    ((bk) this.f441e.get(i4)).f493b = true;
                }
            }
            if (this.f445i != i) {
                z3 = true;
            }
            if (this.f436T) {
                this.f445i = i;
                if (z3) {
                    m393e(i);
                }
                requestLayout();
                return;
            }
            m385b(i);
            m376a(i, z, i2, z3);
        } else {
            setScrollingCacheEnabled(false);
        }
    }

    private void m380a(bk bkVar, int i, bk bkVar2) {
        int i2;
        bk bkVar3;
        float f;
        int i3;
        int a = this.f444h.m506a();
        int clientWidth = getClientWidth();
        float f2 = clientWidth > 0 ? ((float) this.f452p) / ((float) clientWidth) : 0.0f;
        if (bkVar2 != null) {
            clientWidth = bkVar2.f492a;
            float f3;
            int i4;
            int i5;
            if (clientWidth < bkVar.f492a) {
                f3 = (bkVar2.f495d + bkVar2.f494c) + f2;
                i2 = 0;
                i4 = clientWidth + 1;
                while (i4 <= bkVar.f492a && i2 < this.f441e.size()) {
                    bkVar3 = (bk) this.f441e.get(i2);
                    while (i4 > bkVar3.f492a && i2 < this.f441e.size() - 1) {
                        i2++;
                        bkVar3 = (bk) this.f441e.get(i2);
                    }
                    i5 = i4;
                    f = f3;
                    i3 = i5;
                    while (i3 < bkVar3.f492a) {
                        i3++;
                        f = (1.0f + f2) + f;
                    }
                    bkVar3.f495d = f;
                    f += bkVar3.f494c + f2;
                    clientWidth = i3 + 1;
                    f3 = f;
                    i4 = clientWidth;
                }
            } else if (clientWidth > bkVar.f492a) {
                i2 = this.f441e.size() - 1;
                f3 = bkVar2.f495d;
                i4 = clientWidth - 1;
                while (i4 >= bkVar.f492a && i2 >= 0) {
                    bkVar3 = (bk) this.f441e.get(i2);
                    while (i4 < bkVar3.f492a && i2 > 0) {
                        i2--;
                        bkVar3 = (bk) this.f441e.get(i2);
                    }
                    i5 = i4;
                    f = f3;
                    i3 = i5;
                    while (i3 > bkVar3.f492a) {
                        i3--;
                        f -= 1.0f + f2;
                    }
                    f -= bkVar3.f494c + f2;
                    bkVar3.f495d = f;
                    clientWidth = i3 - 1;
                    f3 = f;
                    i4 = clientWidth;
                }
            }
        }
        int size = this.f441e.size();
        f = bkVar.f495d;
        i3 = bkVar.f492a - 1;
        this.f456t = bkVar.f492a == 0 ? bkVar.f495d : -3.4028235E38f;
        this.f457u = bkVar.f492a == a + -1 ? (bkVar.f495d + bkVar.f494c) - 1.0f : Float.MAX_VALUE;
        for (i2 = i - 1; i2 >= 0; i2--) {
            bkVar3 = (bk) this.f441e.get(i2);
            while (i3 > bkVar3.f492a) {
                i3--;
                f -= 1.0f + f2;
            }
            f -= bkVar3.f494c + f2;
            bkVar3.f495d = f;
            if (bkVar3.f492a == 0) {
                this.f456t = f;
            }
            i3--;
        }
        f = (bkVar.f495d + bkVar.f494c) + f2;
        i3 = bkVar.f492a + 1;
        for (i2 = i + 1; i2 < size; i2++) {
            bkVar3 = (bk) this.f441e.get(i2);
            while (i3 < bkVar3.f492a) {
                i3++;
                f += 1.0f + f2;
            }
            if (bkVar3.f492a == a - 1) {
                this.f457u = (bkVar3.f494c + f) - 1.0f;
            }
            bkVar3.f495d = f;
            f += bkVar3.f494c + f2;
            i3++;
        }
        this.f437U = false;
    }

    private void m381a(MotionEvent motionEvent) {
        int a = ac.m503a(motionEvent);
        if (motionEvent.getPointerId(a) == this.f427K) {
            a = a == 0 ? 1 : 0;
            this.f423G = motionEvent.getX(a);
            this.f427K = motionEvent.getPointerId(a);
            if (this.f428L != null) {
                this.f428L.clear();
            }
        }
    }

    private void m382a(boolean z) {
        int scrollX;
        boolean z2 = this.ak == 2;
        if (z2) {
            setScrollingCacheEnabled(false);
            if (!this.f449m.isFinished()) {
                this.f449m.abortAnimation();
                scrollX = getScrollX();
                int scrollY = getScrollY();
                int currX = this.f449m.getCurrX();
                int currY = this.f449m.getCurrY();
                if (!(scrollX == currX && scrollY == currY)) {
                    scrollTo(currX, currY);
                    if (currX != scrollX) {
                        m391d(currX);
                    }
                }
            }
        }
        this.f462z = false;
        boolean z3 = z2;
        for (scrollX = 0; scrollX < this.f441e.size(); scrollX++) {
            bk bkVar = (bk) this.f441e.get(scrollX);
            if (bkVar.f493b) {
                bkVar.f493b = false;
                z3 = true;
            }
        }
        if (!z3) {
            return;
        }
        if (z) {
            ao.m520a((View) this, this.aj);
        } else {
            this.aj.run();
        }
    }

    private boolean m383a(View view, boolean z, int i, int i2, int i3) {
        if (view instanceof ViewGroup) {
            ViewGroup viewGroup = (ViewGroup) view;
            int scrollX = view.getScrollX();
            int scrollY = view.getScrollY();
            for (int childCount = viewGroup.getChildCount() - 1; childCount >= 0; childCount--) {
                View childAt = viewGroup.getChildAt(childCount);
                if (i2 + scrollX >= childAt.getLeft() && i2 + scrollX < childAt.getRight() && i3 + scrollY >= childAt.getTop() && i3 + scrollY < childAt.getBottom()) {
                    if (m383a(childAt, true, i, (i2 + scrollX) - childAt.getLeft(), (i3 + scrollY) - childAt.getTop())) {
                        return true;
                    }
                }
            }
        }
        return z && ao.m521a(view, -i);
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private void m385b(int r18) {
        /*
        r17 = this;
        r2 = 0;
        r0 = r17;
        r3 = r0.f445i;
        r0 = r18;
        if (r3 == r0) goto L_0x02d7;
    L_0x0009:
        r0 = r17;
        r2 = r0.f445i;
        r0 = r17;
        r2 = r0.m388c(r2);
        r0 = r18;
        r1 = r17;
        r1.f445i = r0;
        r3 = r2;
    L_0x001a:
        r0 = r17;
        r2 = r0.f444h;
        if (r2 != 0) goto L_0x0024;
    L_0x0020:
        r17.m392e();
    L_0x0023:
        return;
    L_0x0024:
        r0 = r17;
        r2 = r0.f462z;
        if (r2 == 0) goto L_0x002e;
    L_0x002a:
        r17.m392e();
        goto L_0x0023;
    L_0x002e:
        r2 = r17.getWindowToken();
        if (r2 == 0) goto L_0x0023;
    L_0x0034:
        r0 = r17;
        r2 = r0.f417A;
        r4 = 0;
        r0 = r17;
        r5 = r0.f445i;
        r5 = r5 - r2;
        r10 = java.lang.Math.max(r4, r5);
        r0 = r17;
        r4 = r0.f444h;
        r11 = r4.m506a();
        r4 = r11 + -1;
        r0 = r17;
        r5 = r0.f445i;
        r2 = r2 + r5;
        r12 = java.lang.Math.min(r4, r2);
        r0 = r17;
        r2 = r0.f440b;
        if (r11 == r2) goto L_0x00be;
    L_0x005b:
        r2 = r17.getResources();	 Catch:{ NotFoundException -> 0x00b4 }
        r3 = r17.getId();	 Catch:{ NotFoundException -> 0x00b4 }
        r2 = r2.getResourceName(r3);	 Catch:{ NotFoundException -> 0x00b4 }
    L_0x0067:
        r3 = new java.lang.IllegalStateException;
        r4 = new java.lang.StringBuilder;
        r5 = "The application's PagerAdapter changed the adapter's contents without calling PagerAdapter#notifyDataSetChanged! Expected adapter item count: ";
        r4.<init>(r5);
        r0 = r17;
        r5 = r0.f440b;
        r4 = r4.append(r5);
        r5 = ", found: ";
        r4 = r4.append(r5);
        r4 = r4.append(r11);
        r5 = " Pager id: ";
        r4 = r4.append(r5);
        r2 = r4.append(r2);
        r4 = " Pager class: ";
        r2 = r2.append(r4);
        r4 = r17.getClass();
        r2 = r2.append(r4);
        r4 = " Problematic adapter: ";
        r2 = r2.append(r4);
        r0 = r17;
        r4 = r0.f444h;
        r4 = r4.getClass();
        r2 = r2.append(r4);
        r2 = r2.toString();
        r3.<init>(r2);
        throw r3;
    L_0x00b4:
        r2 = move-exception;
        r2 = r17.getId();
        r2 = java.lang.Integer.toHexString(r2);
        goto L_0x0067;
    L_0x00be:
        r5 = 0;
        r2 = 0;
        r4 = r2;
    L_0x00c1:
        r0 = r17;
        r2 = r0.f441e;
        r2 = r2.size();
        if (r4 >= r2) goto L_0x02d4;
    L_0x00cb:
        r0 = r17;
        r2 = r0.f441e;
        r2 = r2.get(r4);
        r2 = (android.support.v4.view.bk) r2;
        r6 = r2.f492a;
        r0 = r17;
        r7 = r0.f445i;
        if (r6 < r7) goto L_0x0147;
    L_0x00dd:
        r6 = r2.f492a;
        r0 = r17;
        r7 = r0.f445i;
        if (r6 != r7) goto L_0x02d4;
    L_0x00e5:
        if (r2 != 0) goto L_0x02d1;
    L_0x00e7:
        if (r11 <= 0) goto L_0x02d1;
    L_0x00e9:
        r0 = r17;
        r2 = r0.f445i;
        r2 = m372a(r2);
        r9 = r2;
    L_0x00f2:
        if (r9 == 0) goto L_0x0253;
    L_0x00f4:
        r8 = 0;
        r7 = r4 + -1;
        if (r7 < 0) goto L_0x014c;
    L_0x00f9:
        r0 = r17;
        r2 = r0.f441e;
        r2 = r2.get(r7);
        r2 = (android.support.v4.view.bk) r2;
    L_0x0103:
        r13 = r17.getClientWidth();
        if (r13 > 0) goto L_0x014e;
    L_0x0109:
        r5 = 0;
    L_0x010a:
        r0 = r17;
        r6 = r0.f445i;
        r6 = r6 + -1;
        r15 = r6;
        r6 = r8;
        r8 = r15;
        r16 = r7;
        r7 = r4;
        r4 = r16;
    L_0x0118:
        if (r8 < 0) goto L_0x0190;
    L_0x011a:
        r14 = (r6 > r5 ? 1 : (r6 == r5 ? 0 : -1));
        if (r14 < 0) goto L_0x015e;
    L_0x011e:
        if (r8 >= r10) goto L_0x015e;
    L_0x0120:
        if (r2 == 0) goto L_0x0190;
    L_0x0122:
        r14 = r2.f492a;
        if (r8 != r14) goto L_0x0144;
    L_0x0126:
        r14 = r2.f493b;
        if (r14 != 0) goto L_0x0144;
    L_0x012a:
        r0 = r17;
        r2 = r0.f441e;
        r2.remove(r4);
        android.support.v4.view.ai.m505b();
        r4 = r4 + -1;
        r7 = r7 + -1;
        if (r4 < 0) goto L_0x015c;
    L_0x013a:
        r0 = r17;
        r2 = r0.f441e;
        r2 = r2.get(r4);
        r2 = (android.support.v4.view.bk) r2;
    L_0x0144:
        r8 = r8 + -1;
        goto L_0x0118;
    L_0x0147:
        r2 = r4 + 1;
        r4 = r2;
        goto L_0x00c1;
    L_0x014c:
        r2 = 0;
        goto L_0x0103;
    L_0x014e:
        r5 = 1073741824; // 0x40000000 float:2.0 double:5.304989477E-315;
        r6 = r9.f494c;
        r5 = r5 - r6;
        r6 = r17.getPaddingLeft();
        r6 = (float) r6;
        r14 = (float) r13;
        r6 = r6 / r14;
        r5 = r5 + r6;
        goto L_0x010a;
    L_0x015c:
        r2 = 0;
        goto L_0x0144;
    L_0x015e:
        if (r2 == 0) goto L_0x0178;
    L_0x0160:
        r14 = r2.f492a;
        if (r8 != r14) goto L_0x0178;
    L_0x0164:
        r2 = r2.f494c;
        r6 = r6 + r2;
        r4 = r4 + -1;
        if (r4 < 0) goto L_0x0176;
    L_0x016b:
        r0 = r17;
        r2 = r0.f441e;
        r2 = r2.get(r4);
        r2 = (android.support.v4.view.bk) r2;
        goto L_0x0144;
    L_0x0176:
        r2 = 0;
        goto L_0x0144;
    L_0x0178:
        r2 = m372a(r8);
        r2 = r2.f494c;
        r6 = r6 + r2;
        r7 = r7 + 1;
        if (r4 < 0) goto L_0x018e;
    L_0x0183:
        r0 = r17;
        r2 = r0.f441e;
        r2 = r2.get(r4);
        r2 = (android.support.v4.view.bk) r2;
        goto L_0x0144;
    L_0x018e:
        r2 = 0;
        goto L_0x0144;
    L_0x0190:
        r5 = r9.f494c;
        r8 = r7 + 1;
        r2 = 1073741824; // 0x40000000 float:2.0 double:5.304989477E-315;
        r2 = (r5 > r2 ? 1 : (r5 == r2 ? 0 : -1));
        if (r2 >= 0) goto L_0x024e;
    L_0x019a:
        r0 = r17;
        r2 = r0.f441e;
        r2 = r2.size();
        if (r8 >= r2) goto L_0x01f6;
    L_0x01a4:
        r0 = r17;
        r2 = r0.f441e;
        r2 = r2.get(r8);
        r2 = (android.support.v4.view.bk) r2;
        r6 = r2;
    L_0x01af:
        if (r13 > 0) goto L_0x01f8;
    L_0x01b1:
        r2 = 0;
        r4 = r2;
    L_0x01b3:
        r0 = r17;
        r2 = r0.f445i;
        r2 = r2 + 1;
        r15 = r6;
        r6 = r8;
        r8 = r2;
        r2 = r15;
    L_0x01bd:
        if (r8 >= r11) goto L_0x024e;
    L_0x01bf:
        r10 = (r5 > r4 ? 1 : (r5 == r4 ? 0 : -1));
        if (r10 < 0) goto L_0x0206;
    L_0x01c3:
        if (r8 <= r12) goto L_0x0206;
    L_0x01c5:
        if (r2 == 0) goto L_0x024e;
    L_0x01c7:
        r10 = r2.f492a;
        if (r8 != r10) goto L_0x02cc;
    L_0x01cb:
        r10 = r2.f493b;
        if (r10 != 0) goto L_0x02cc;
    L_0x01cf:
        r0 = r17;
        r2 = r0.f441e;
        r2.remove(r6);
        android.support.v4.view.ai.m505b();
        r0 = r17;
        r2 = r0.f441e;
        r2 = r2.size();
        if (r6 >= r2) goto L_0x0204;
    L_0x01e3:
        r0 = r17;
        r2 = r0.f441e;
        r2 = r2.get(r6);
        r2 = (android.support.v4.view.bk) r2;
    L_0x01ed:
        r15 = r5;
        r5 = r2;
        r2 = r15;
    L_0x01f0:
        r8 = r8 + 1;
        r15 = r2;
        r2 = r5;
        r5 = r15;
        goto L_0x01bd;
    L_0x01f6:
        r6 = 0;
        goto L_0x01af;
    L_0x01f8:
        r2 = r17.getPaddingRight();
        r2 = (float) r2;
        r4 = (float) r13;
        r2 = r2 / r4;
        r4 = 1073741824; // 0x40000000 float:2.0 double:5.304989477E-315;
        r2 = r2 + r4;
        r4 = r2;
        goto L_0x01b3;
    L_0x0204:
        r2 = 0;
        goto L_0x01ed;
    L_0x0206:
        if (r2 == 0) goto L_0x022b;
    L_0x0208:
        r10 = r2.f492a;
        if (r8 != r10) goto L_0x022b;
    L_0x020c:
        r2 = r2.f494c;
        r5 = r5 + r2;
        r6 = r6 + 1;
        r0 = r17;
        r2 = r0.f441e;
        r2 = r2.size();
        if (r6 >= r2) goto L_0x0229;
    L_0x021b:
        r0 = r17;
        r2 = r0.f441e;
        r2 = r2.get(r6);
        r2 = (android.support.v4.view.bk) r2;
    L_0x0225:
        r15 = r5;
        r5 = r2;
        r2 = r15;
        goto L_0x01f0;
    L_0x0229:
        r2 = 0;
        goto L_0x0225;
    L_0x022b:
        r2 = m372a(r8);
        r6 = r6 + 1;
        r2 = r2.f494c;
        r5 = r5 + r2;
        r0 = r17;
        r2 = r0.f441e;
        r2 = r2.size();
        if (r6 >= r2) goto L_0x024c;
    L_0x023e:
        r0 = r17;
        r2 = r0.f441e;
        r2 = r2.get(r6);
        r2 = (android.support.v4.view.bk) r2;
    L_0x0248:
        r15 = r5;
        r5 = r2;
        r2 = r15;
        goto L_0x01f0;
    L_0x024c:
        r2 = 0;
        goto L_0x0248;
    L_0x024e:
        r0 = r17;
        r0.m380a(r9, r7, r3);
    L_0x0253:
        r4 = r17.getChildCount();
        r2 = 0;
        r3 = r2;
    L_0x0259:
        if (r3 >= r4) goto L_0x0286;
    L_0x025b:
        r0 = r17;
        r2 = r0.getChildAt(r3);
        r2 = r2.getLayoutParams();
        r2 = (android.support.v4.view.bl) r2;
        r2.f501f = r3;
        r5 = r2.f496a;
        if (r5 != 0) goto L_0x0282;
    L_0x026d:
        r5 = r2.f498c;
        r6 = 0;
        r5 = (r5 > r6 ? 1 : (r5 == r6 ? 0 : -1));
        if (r5 != 0) goto L_0x0282;
    L_0x0274:
        r5 = r17.m394f();
        if (r5 == 0) goto L_0x0282;
    L_0x027a:
        r6 = r5.f494c;
        r2.f498c = r6;
        r5 = r5.f492a;
        r2.f500e = r5;
    L_0x0282:
        r2 = r3 + 1;
        r3 = r2;
        goto L_0x0259;
    L_0x0286:
        r17.m392e();
        r2 = r17.hasFocus();
        if (r2 == 0) goto L_0x0023;
    L_0x028f:
        r2 = r17.findFocus();
        if (r2 == 0) goto L_0x02ca;
    L_0x0295:
        r0 = r17;
        r2 = r0.m373a(r2);
    L_0x029b:
        if (r2 == 0) goto L_0x02a5;
    L_0x029d:
        r2 = r2.f492a;
        r0 = r17;
        r3 = r0.f445i;
        if (r2 == r3) goto L_0x0023;
    L_0x02a5:
        r2 = 0;
    L_0x02a6:
        r3 = r17.getChildCount();
        if (r2 >= r3) goto L_0x0023;
    L_0x02ac:
        r0 = r17;
        r3 = r0.getChildAt(r2);
        r4 = r17.m394f();
        if (r4 == 0) goto L_0x02c7;
    L_0x02b8:
        r4 = r4.f492a;
        r0 = r17;
        r5 = r0.f445i;
        if (r4 != r5) goto L_0x02c7;
    L_0x02c0:
        r4 = 2;
        r3 = r3.requestFocus(r4);
        if (r3 != 0) goto L_0x0023;
    L_0x02c7:
        r2 = r2 + 1;
        goto L_0x02a6;
    L_0x02ca:
        r2 = 0;
        goto L_0x029b;
    L_0x02cc:
        r15 = r5;
        r5 = r2;
        r2 = r15;
        goto L_0x01f0;
    L_0x02d1:
        r9 = r2;
        goto L_0x00f2;
    L_0x02d4:
        r2 = r5;
        goto L_0x00e5;
    L_0x02d7:
        r3 = r2;
        goto L_0x001a;
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.v4.view.ViewPager.b(int):void");
    }

    private boolean m386b(float f) {
        boolean z;
        float f2;
        boolean z2 = true;
        boolean z3 = false;
        float f3 = this.f423G - f;
        this.f423G = f;
        float scrollX = ((float) getScrollX()) + f3;
        int clientWidth = getClientWidth();
        float f4 = ((float) clientWidth) * this.f456t;
        float f5 = ((float) clientWidth) * this.f457u;
        bk bkVar = (bk) this.f441e.get(0);
        bk bkVar2 = (bk) this.f441e.get(this.f441e.size() - 1);
        if (bkVar.f492a != 0) {
            f4 = bkVar.f495d * ((float) clientWidth);
            z = false;
        } else {
            z = true;
        }
        if (bkVar2.f492a != this.f444h.m506a() - 1) {
            f2 = bkVar2.f495d * ((float) clientWidth);
            z2 = false;
        } else {
            f2 = f5;
        }
        if (scrollX < f4) {
            if (z) {
                z3 = this.f434R.m346a(Math.abs(f4 - scrollX) / ((float) clientWidth));
            }
        } else if (scrollX > f2) {
            if (z2) {
                z3 = this.f435S.m346a(Math.abs(scrollX - f2) / ((float) clientWidth));
            }
            f4 = f2;
        } else {
            f4 = scrollX;
        }
        this.f423G += f4 - ((float) ((int) f4));
        scrollTo((int) f4, getScrollY());
        m391d((int) f4);
        return z3;
    }

    private bk m388c(int i) {
        for (int i2 = 0; i2 < this.f441e.size(); i2++) {
            bk bkVar = (bk) this.f441e.get(i2);
            if (bkVar.f492a == i) {
                return bkVar;
            }
        }
        return null;
    }

    private void m390d() {
        setWillNotDraw(false);
        setDescendantFocusability(262144);
        setFocusable(true);
        Context context = getContext();
        this.f449m = new Scroller(context, f416d);
        ViewConfiguration viewConfiguration = ViewConfiguration.get(context);
        float f = context.getResources().getDisplayMetrics().density;
        this.f422F = viewConfiguration.getScaledPagingTouchSlop();
        this.f429M = (int) (400.0f * f);
        this.f430N = viewConfiguration.getScaledMaximumFlingVelocity();
        this.f434R = new C0047a(context);
        this.f435S = new C0047a(context);
        this.f431O = (int) (25.0f * f);
        this.f432P = (int) (2.0f * f);
        this.f420D = (int) (16.0f * f);
        ao.m519a((View) this, new bm(this));
        if (ao.m522b(this) == 0) {
            ao.m525c(this);
        }
        ao.m518a((View) this, new bi(this));
    }

    private boolean m391d(int i) {
        if (this.f441e.size() != 0) {
            bk i2 = m398i();
            int clientWidth = getClientWidth();
            float f = ((((float) i) / ((float) clientWidth)) - i2.f495d) / (i2.f494c + (((float) this.f452p) / ((float) clientWidth)));
            this.f438V = false;
            m374a(f);
            if (this.f438V) {
                return true;
            }
            throw new IllegalStateException("onPageScrolled did not call superclass implementation");
        } else if (this.f436T) {
            return false;
        } else {
            this.f438V = false;
            m374a(0.0f);
            if (this.f438V) {
                return false;
            }
            throw new IllegalStateException("onPageScrolled did not call superclass implementation");
        }
    }

    private void m392e() {
        if (this.ag != 0) {
            if (this.ah == null) {
                this.ah = new ArrayList();
            } else {
                this.ah.clear();
            }
            int childCount = getChildCount();
            for (int i = 0; i < childCount; i++) {
                this.ah.add(getChildAt(i));
            }
            Collections.sort(this.ah, ai);
        }
    }

    private void m393e(int i) {
        if (this.ab != null) {
            this.ab.mo169a(i);
        }
        if (this.aa != null) {
            int size = this.aa.size();
            for (int i2 = 0; i2 < size; i2++) {
                bn bnVar = (bn) this.aa.get(i2);
                if (bnVar != null) {
                    bnVar.mo169a(i);
                }
            }
        }
        if (this.ac != null) {
            this.ac.mo169a(i);
        }
    }

    private bk m394f() {
        for (int i = 0; i < this.f441e.size(); i++) {
            bk bkVar = (bk) this.f441e.get(i);
            if (this.f444h.m508c()) {
                return bkVar;
            }
        }
        return null;
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private boolean m395f(int r10) {
        /*
        r9 = this;
        r1 = 0;
        r8 = 66;
        r7 = 17;
        r3 = 1;
        r4 = 0;
        r2 = r9.findFocus();
        if (r2 != r9) goto L_0x003f;
    L_0x000d:
        r0 = r1;
    L_0x000e:
        r1 = android.view.FocusFinder.getInstance();
        r1 = r1.findNextFocus(r9, r0, r10);
        if (r1 == 0) goto L_0x00bd;
    L_0x0018:
        if (r1 == r0) goto L_0x00bd;
    L_0x001a:
        if (r10 != r7) goto L_0x00a1;
    L_0x001c:
        r2 = r9.f443g;
        r2 = r9.m371a(r2, r1);
        r2 = r2.left;
        r3 = r9.f443g;
        r3 = r9.m371a(r3, r0);
        r3 = r3.left;
        if (r0 == 0) goto L_0x009c;
    L_0x002e:
        if (r2 < r3) goto L_0x009c;
    L_0x0030:
        r0 = r9.m399j();
    L_0x0034:
        r4 = r0;
    L_0x0035:
        if (r4 == 0) goto L_0x003e;
    L_0x0037:
        r0 = android.view.SoundEffectConstants.getContantForFocusDirection(r10);
        r9.playSoundEffect(r0);
    L_0x003e:
        return r4;
    L_0x003f:
        if (r2 == 0) goto L_0x00e9;
    L_0x0041:
        r0 = r2.getParent();
    L_0x0045:
        r5 = r0 instanceof android.view.ViewGroup;
        if (r5 == 0) goto L_0x00ec;
    L_0x0049:
        if (r0 != r9) goto L_0x007c;
    L_0x004b:
        r0 = r3;
    L_0x004c:
        if (r0 != 0) goto L_0x00e9;
    L_0x004e:
        r5 = new java.lang.StringBuilder;
        r5.<init>();
        r0 = r2.getClass();
        r0 = r0.getSimpleName();
        r5.append(r0);
        r0 = r2.getParent();
    L_0x0062:
        r2 = r0 instanceof android.view.ViewGroup;
        if (r2 == 0) goto L_0x0081;
    L_0x0066:
        r2 = " => ";
        r2 = r5.append(r2);
        r6 = r0.getClass();
        r6 = r6.getSimpleName();
        r2.append(r6);
        r0 = r0.getParent();
        goto L_0x0062;
    L_0x007c:
        r0 = r0.getParent();
        goto L_0x0045;
    L_0x0081:
        r0 = "ViewPager";
        r2 = new java.lang.StringBuilder;
        r6 = "arrowScroll tried to find focus based on non-child current focused view ";
        r2.<init>(r6);
        r5 = r5.toString();
        r2 = r2.append(r5);
        r2 = r2.toString();
        android.util.Log.e(r0, r2);
        r0 = r1;
        goto L_0x000e;
    L_0x009c:
        r0 = r1.requestFocus();
        goto L_0x0034;
    L_0x00a1:
        if (r10 != r8) goto L_0x0035;
    L_0x00a3:
        r2 = r9.f443g;
        r2 = r9.m371a(r2, r1);
        r2 = r2.left;
        r5 = r9.f443g;
        r5 = r9.m371a(r5, r0);
        r5 = r5.left;
        if (r0 == 0) goto L_0x00b7;
    L_0x00b5:
        if (r2 <= r5) goto L_0x00cc;
    L_0x00b7:
        r0 = r1.requestFocus();
        goto L_0x0034;
    L_0x00bd:
        if (r10 == r7) goto L_0x00c1;
    L_0x00bf:
        if (r10 != r3) goto L_0x00c7;
    L_0x00c1:
        r0 = r9.m399j();
        goto L_0x0034;
    L_0x00c7:
        if (r10 == r8) goto L_0x00cc;
    L_0x00c9:
        r0 = 2;
        if (r10 != r0) goto L_0x0035;
    L_0x00cc:
        r0 = r9.f444h;
        if (r0 == 0) goto L_0x00e6;
    L_0x00d0:
        r0 = r9.f445i;
        r1 = r9.f444h;
        r1 = r1.m506a();
        r1 = r1 + -1;
        if (r0 >= r1) goto L_0x00e6;
    L_0x00dc:
        r0 = r9.f445i;
        r0 = r0 + 1;
        r9.setCurrentItem$2563266(r0);
        r0 = r3;
        goto L_0x0034;
    L_0x00e6:
        r0 = r4;
        goto L_0x0034;
    L_0x00e9:
        r0 = r2;
        goto L_0x000e;
    L_0x00ec:
        r0 = r4;
        goto L_0x004c;
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.v4.view.ViewPager.f(int):boolean");
    }

    private boolean m396g() {
        this.f427K = -1;
        this.f418B = false;
        this.f419C = false;
        if (this.f428L != null) {
            this.f428L.recycle();
            this.f428L = null;
        }
        return this.f434R.m349c() | this.f435S.m349c();
    }

    private int getClientWidth() {
        return (getMeasuredWidth() - getPaddingLeft()) - getPaddingRight();
    }

    private void m397h() {
        ViewParent parent = getParent();
        if (parent != null) {
            parent.requestDisallowInterceptTouchEvent(true);
        }
    }

    private bk m398i() {
        int clientWidth = getClientWidth();
        float scrollX = clientWidth > 0 ? ((float) getScrollX()) / ((float) clientWidth) : 0.0f;
        float f = clientWidth > 0 ? ((float) this.f452p) / ((float) clientWidth) : 0.0f;
        float f2 = 0.0f;
        float f3 = 0.0f;
        int i = -1;
        int i2 = 0;
        Object obj = 1;
        bk bkVar = null;
        while (i2 < this.f441e.size()) {
            int i3;
            bk bkVar2;
            bk bkVar3 = (bk) this.f441e.get(i2);
            bk bkVar4;
            if (obj != null || bkVar3.f492a == i + 1) {
                bkVar4 = bkVar3;
                i3 = i2;
                bkVar2 = bkVar4;
            } else {
                bkVar3 = this.f442f;
                bkVar3.f495d = (f2 + f3) + f;
                bkVar3.f492a = i + 1;
                bkVar3.f494c = 1.0f;
                bkVar4 = bkVar3;
                i3 = i2 - 1;
                bkVar2 = bkVar4;
            }
            f2 = bkVar2.f495d;
            f3 = (bkVar2.f494c + f2) + f;
            if (obj == null && scrollX < f2) {
                return bkVar;
            }
            if (scrollX < f3 || i3 == this.f441e.size() - 1) {
                return bkVar2;
            }
            f3 = f2;
            i = bkVar2.f492a;
            obj = null;
            f2 = bkVar2.f494c;
            bkVar = bkVar2;
            i2 = i3 + 1;
        }
        return bkVar;
    }

    private boolean m399j() {
        if (this.f445i <= 0) {
            return false;
        }
        setCurrentItem$2563266(this.f445i - 1);
        return true;
    }

    private void setCurrentItem$2563266(int i) {
        this.f462z = false;
        m377a(i, true, false);
    }

    private void setScrollState(int i) {
        int i2 = 0;
        if (this.ak != i) {
            this.ak = i;
            if (this.ae != null) {
                int i3 = i != 0 ? 1 : 0;
                int childCount = getChildCount();
                for (int i4 = 0; i4 < childCount; i4++) {
                    ao.m524b(getChildAt(i4), i3 != 0 ? 2 : 0);
                }
            }
            if (this.ab != null) {
                this.ab.mo170b(i);
            }
            if (this.aa != null) {
                int size = this.aa.size();
                while (i2 < size) {
                    bn bnVar = (bn) this.aa.get(i2);
                    if (bnVar != null) {
                        bnVar.mo170b(i);
                    }
                    i2++;
                }
            }
            if (this.ac != null) {
                this.ac.mo170b(i);
            }
        }
    }

    private void setScrollingCacheEnabled(boolean z) {
        if (this.f461y != z) {
            this.f461y = z;
        }
    }

    final void m400a() {
        int i;
        int a = this.f444h.m506a();
        this.f440b = a;
        boolean z = this.f441e.size() < (this.f417A * 2) + 1 && this.f441e.size() < a;
        int i2 = this.f445i;
        for (i = 0; i < this.f441e.size(); i++) {
            this.f441e.get(i);
        }
        Collections.sort(this.f441e, f415c);
        if (z) {
            int childCount = getChildCount();
            for (i = 0; i < childCount; i++) {
                bl blVar = (bl) getChildAt(i).getLayoutParams();
                if (!blVar.f496a) {
                    blVar.f498c = 0.0f;
                }
            }
            m377a(i2, false, true);
            requestLayout();
        }
    }

    public void addFocusables(ArrayList arrayList, int i, int i2) {
        int size = arrayList.size();
        int descendantFocusability = getDescendantFocusability();
        if (descendantFocusability != 393216) {
            for (int i3 = 0; i3 < getChildCount(); i3++) {
                View childAt = getChildAt(i3);
                if (childAt.getVisibility() == 0) {
                    bk f = m394f();
                    if (f != null && f.f492a == this.f445i) {
                        childAt.addFocusables(arrayList, i, i2);
                    }
                }
            }
        }
        if ((descendantFocusability == 262144 && size != arrayList.size()) || !isFocusable()) {
            return;
        }
        if (((i2 & 1) != 1 || !isInTouchMode() || isFocusableInTouchMode()) && arrayList != null) {
            arrayList.add(this);
        }
    }

    public void addTouchables(ArrayList arrayList) {
        for (int i = 0; i < getChildCount(); i++) {
            View childAt = getChildAt(i);
            if (childAt.getVisibility() == 0) {
                bk f = m394f();
                if (f != null && f.f492a == this.f445i) {
                    childAt.addTouchables(arrayList);
                }
            }
        }
    }

    public void addView(View view, int i, LayoutParams layoutParams) {
        LayoutParams generateLayoutParams = !checkLayoutParams(layoutParams) ? generateLayoutParams(layoutParams) : layoutParams;
        bl blVar = (bl) generateLayoutParams;
        blVar.f496a = (view.getClass().getAnnotation(bj.class) != null ? 1 : 0) | blVar.f496a;
        if (!this.f460x) {
            super.addView(view, i, generateLayoutParams);
        } else if (blVar == null || !blVar.f496a) {
            blVar.f499d = true;
            addViewInLayout(view, i, generateLayoutParams);
        } else {
            throw new IllegalStateException("Cannot add pager decor view during layout");
        }
    }

    final void m401b() {
        m385b(this.f445i);
    }

    public boolean canScrollHorizontally(int i) {
        if (this.f444h == null) {
            return false;
        }
        int clientWidth = getClientWidth();
        int scrollX = getScrollX();
        return i < 0 ? scrollX > ((int) (((float) clientWidth) * this.f456t)) : i > 0 && scrollX < ((int) (((float) clientWidth) * this.f457u));
    }

    protected boolean checkLayoutParams(LayoutParams layoutParams) {
        return (layoutParams instanceof bl) && super.checkLayoutParams(layoutParams);
    }

    public void computeScroll() {
        this.f450n = true;
        if (this.f449m.isFinished() || !this.f449m.computeScrollOffset()) {
            m382a(true);
            return;
        }
        int scrollX = getScrollX();
        int scrollY = getScrollY();
        int currX = this.f449m.getCurrX();
        int currY = this.f449m.getCurrY();
        if (!(scrollX == currX && scrollY == currY)) {
            scrollTo(currX, currY);
            if (!m391d(currX)) {
                this.f449m.abortAnimation();
                scrollTo(0, currY);
            }
        }
        ao.m517a(this);
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public boolean dispatchKeyEvent(android.view.KeyEvent r5) {
        /*
        r4 = this;
        r1 = 1;
        r0 = 0;
        r2 = super.dispatchKeyEvent(r5);
        if (r2 != 0) goto L_0x0018;
    L_0x0008:
        r2 = r5.getAction();
        if (r2 != 0) goto L_0x0015;
    L_0x000e:
        r2 = r5.getKeyCode();
        switch(r2) {
            case 21: goto L_0x001a;
            case 22: goto L_0x0021;
            case 61: goto L_0x0028;
            default: goto L_0x0015;
        };
    L_0x0015:
        r2 = r0;
    L_0x0016:
        if (r2 == 0) goto L_0x0019;
    L_0x0018:
        r0 = r1;
    L_0x0019:
        return r0;
    L_0x001a:
        r2 = 17;
        r2 = r4.m395f(r2);
        goto L_0x0016;
    L_0x0021:
        r2 = 66;
        r2 = r4.m395f(r2);
        goto L_0x0016;
    L_0x0028:
        r2 = android.os.Build.VERSION.SDK_INT;
        r3 = 11;
        if (r2 < r3) goto L_0x0015;
    L_0x002e:
        r2 = android.support.v4.view.C0094o.m688b(r5);
        if (r2 == 0) goto L_0x003a;
    L_0x0034:
        r2 = 2;
        r2 = r4.m395f(r2);
        goto L_0x0016;
    L_0x003a:
        r2 = android.support.v4.view.C0094o.m687a(r5);
        if (r2 == 0) goto L_0x0015;
    L_0x0040:
        r2 = r4.m395f(r1);
        goto L_0x0016;
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.v4.view.ViewPager.dispatchKeyEvent(android.view.KeyEvent):boolean");
    }

    public boolean dispatchPopulateAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
        if (accessibilityEvent.getEventType() == 4096) {
            return super.dispatchPopulateAccessibilityEvent(accessibilityEvent);
        }
        int childCount = getChildCount();
        for (int i = 0; i < childCount; i++) {
            View childAt = getChildAt(i);
            if (childAt.getVisibility() == 0) {
                bk f = m394f();
                if (f != null && f.f492a == this.f445i && childAt.dispatchPopulateAccessibilityEvent(accessibilityEvent)) {
                    return true;
                }
            }
        }
        return false;
    }

    public void draw(Canvas canvas) {
        super.draw(canvas);
        int i = 0;
        int overScrollMode = getOverScrollMode();
        if (overScrollMode == 0 || (overScrollMode == 1 && this.f444h != null && this.f444h.m506a() > 1)) {
            int width;
            if (!this.f434R.m345a()) {
                overScrollMode = canvas.save();
                i = (getHeight() - getPaddingTop()) - getPaddingBottom();
                width = getWidth();
                canvas.rotate(270.0f);
                canvas.translate((float) ((-i) + getPaddingTop()), this.f456t * ((float) width));
                this.f434R.m344a(i, width);
                i = this.f434R.m347a(canvas) | 0;
                canvas.restoreToCount(overScrollMode);
            }
            if (!this.f435S.m345a()) {
                overScrollMode = canvas.save();
                width = getWidth();
                int height = (getHeight() - getPaddingTop()) - getPaddingBottom();
                canvas.rotate(90.0f);
                canvas.translate((float) (-getPaddingTop()), (-(this.f457u + 1.0f)) * ((float) width));
                this.f435S.m344a(height, width);
                i |= this.f435S.m347a(canvas);
                canvas.restoreToCount(overScrollMode);
            }
        } else {
            this.f434R.m348b();
            this.f435S.m348b();
        }
        if (i != 0) {
            ao.m517a(this);
        }
    }

    protected void drawableStateChanged() {
        super.drawableStateChanged();
        Drawable drawable = this.f453q;
        if (drawable != null && drawable.isStateful()) {
            drawable.setState(getDrawableState());
        }
    }

    protected LayoutParams generateDefaultLayoutParams() {
        return new bl();
    }

    public LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return new bl(getContext(), attributeSet);
    }

    protected LayoutParams generateLayoutParams(LayoutParams layoutParams) {
        return generateDefaultLayoutParams();
    }

    public ai getAdapter() {
        return this.f444h;
    }

    protected int getChildDrawingOrder(int i, int i2) {
        if (this.ag == 2) {
            i2 = (i - 1) - i2;
        }
        return ((bl) ((View) this.ah.get(i2)).getLayoutParams()).f501f;
    }

    public int getCurrentItem() {
        return this.f445i;
    }

    public int getOffscreenPageLimit() {
        return this.f417A;
    }

    public int getPageMargin() {
        return this.f452p;
    }

    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        this.f436T = true;
    }

    protected void onDetachedFromWindow() {
        removeCallbacks(this.aj);
        if (!(this.f449m == null || this.f449m.isFinished())) {
            this.f449m.abortAnimation();
        }
        super.onDetachedFromWindow();
    }

    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (this.f452p > 0 && this.f453q != null && this.f441e.size() > 0 && this.f444h != null) {
            int scrollX = getScrollX();
            int width = getWidth();
            float f = ((float) this.f452p) / ((float) width);
            bk bkVar = (bk) this.f441e.get(0);
            float f2 = bkVar.f495d;
            int size = this.f441e.size();
            int i = bkVar.f492a;
            int i2 = ((bk) this.f441e.get(size - 1)).f492a;
            int i3 = 0;
            int i4 = i;
            while (i4 < i2) {
                float f3;
                while (i4 > bkVar.f492a && i3 < size) {
                    i3++;
                    bkVar = (bk) this.f441e.get(i3);
                }
                if (i4 == bkVar.f492a) {
                    f3 = (bkVar.f495d + bkVar.f494c) * ((float) width);
                    f2 = (bkVar.f495d + bkVar.f494c) + f;
                } else {
                    f3 = (1.0f + f2) * ((float) width);
                    f2 += 1.0f + f;
                }
                if (((float) this.f452p) + f3 > ((float) scrollX)) {
                    this.f453q.setBounds(Math.round(f3), this.f454r, Math.round(((float) this.f452p) + f3), this.f455s);
                    this.f453q.draw(canvas);
                }
                if (f3 <= ((float) (scrollX + width))) {
                    i4++;
                } else {
                    return;
                }
            }
        }
    }

    public boolean onInterceptTouchEvent(MotionEvent motionEvent) {
        int action = motionEvent.getAction() & 255;
        if (action == 3 || action == 1) {
            m396g();
            return false;
        }
        if (action != 0) {
            if (this.f418B) {
                return true;
            }
            if (this.f419C) {
                return false;
            }
        }
        float x;
        switch (action) {
            case 0:
                x = motionEvent.getX();
                this.f425I = x;
                this.f423G = x;
                x = motionEvent.getY();
                this.f426J = x;
                this.f424H = x;
                this.f427K = motionEvent.getPointerId(0);
                this.f419C = false;
                this.f450n = true;
                this.f449m.computeScrollOffset();
                if (this.ak == 2 && Math.abs(this.f449m.getFinalX() - this.f449m.getCurrX()) > this.f432P) {
                    this.f449m.abortAnimation();
                    this.f462z = false;
                    m401b();
                    this.f418B = true;
                    m397h();
                    setScrollState(1);
                    break;
                }
                m382a(false);
                this.f418B = false;
                break;
                break;
            case 2:
                action = this.f427K;
                if (action != -1) {
                    action = motionEvent.findPointerIndex(action);
                    float x2 = motionEvent.getX(action);
                    float f = x2 - this.f423G;
                    float abs = Math.abs(f);
                    float y = motionEvent.getY(action);
                    float abs2 = Math.abs(y - this.f426J);
                    if (f != 0.0f) {
                        x = this.f423G;
                        boolean z = (x < ((float) this.f421E) && f > 0.0f) || (x > ((float) (getWidth() - this.f421E)) && f < 0.0f);
                        if (!z && m383a(this, false, (int) f, (int) x2, (int) y)) {
                            this.f423G = x2;
                            this.f424H = y;
                            this.f419C = true;
                            return false;
                        }
                    }
                    if (abs > ((float) this.f422F) && 0.5f * abs > abs2) {
                        this.f418B = true;
                        m397h();
                        setScrollState(1);
                        this.f423G = f > 0.0f ? this.f425I + ((float) this.f422F) : this.f425I - ((float) this.f422F);
                        this.f424H = y;
                        setScrollingCacheEnabled(true);
                    } else if (abs2 > ((float) this.f422F)) {
                        this.f419C = true;
                    }
                    if (this.f418B && m386b(x2)) {
                        ao.m517a(this);
                        break;
                    }
                }
                break;
            case 6:
                m381a(motionEvent);
                break;
        }
        if (this.f428L == null) {
            this.f428L = VelocityTracker.obtain();
        }
        this.f428L.addMovement(motionEvent);
        return this.f418B;
    }

    protected void onLayout(boolean z, int i, int i2, int i3, int i4) {
        int max;
        int childCount = getChildCount();
        int i5 = i3 - i;
        int i6 = i4 - i2;
        int paddingLeft = getPaddingLeft();
        int paddingTop = getPaddingTop();
        int paddingRight = getPaddingRight();
        int paddingBottom = getPaddingBottom();
        int scrollX = getScrollX();
        int i7 = 0;
        int i8 = 0;
        while (i8 < childCount) {
            bl blVar;
            int measuredWidth;
            View childAt = getChildAt(i8);
            if (childAt.getVisibility() != 8) {
                blVar = (bl) childAt.getLayoutParams();
                if (blVar.f496a) {
                    int i9 = blVar.f497b & 112;
                    switch (blVar.f497b & 7) {
                        case 1:
                            max = Math.max((i5 - childAt.getMeasuredWidth()) / 2, paddingLeft);
                            break;
                        case 3:
                            max = paddingLeft;
                            paddingLeft = childAt.getMeasuredWidth() + paddingLeft;
                            break;
                        case 5:
                            measuredWidth = (i5 - paddingRight) - childAt.getMeasuredWidth();
                            paddingRight += childAt.getMeasuredWidth();
                            max = measuredWidth;
                            break;
                        default:
                            max = paddingLeft;
                            break;
                    }
                    int i10;
                    switch (i9) {
                        case C0107c.ActionPage_buttonRippleColor /*16*/:
                            measuredWidth = Math.max((i6 - childAt.getMeasuredHeight()) / 2, paddingTop);
                            i10 = paddingBottom;
                            paddingBottom = paddingTop;
                            paddingTop = i10;
                            break;
                        case 48:
                            measuredWidth = childAt.getMeasuredHeight() + paddingTop;
                            i10 = paddingTop;
                            paddingTop = paddingBottom;
                            paddingBottom = measuredWidth;
                            measuredWidth = i10;
                            break;
                        case 80:
                            measuredWidth = (i6 - paddingBottom) - childAt.getMeasuredHeight();
                            i10 = paddingBottom + childAt.getMeasuredHeight();
                            paddingBottom = paddingTop;
                            paddingTop = i10;
                            break;
                        default:
                            measuredWidth = paddingTop;
                            i10 = paddingBottom;
                            paddingBottom = paddingTop;
                            paddingTop = i10;
                            break;
                    }
                    max += scrollX;
                    childAt.layout(max, measuredWidth, childAt.getMeasuredWidth() + max, childAt.getMeasuredHeight() + measuredWidth);
                    measuredWidth = i7 + 1;
                    i7 = paddingBottom;
                    paddingBottom = paddingTop;
                    paddingTop = paddingRight;
                    paddingRight = paddingLeft;
                    i8++;
                    paddingLeft = paddingRight;
                    paddingRight = paddingTop;
                    paddingTop = i7;
                    i7 = measuredWidth;
                }
            }
            measuredWidth = i7;
            i7 = paddingTop;
            paddingTop = paddingRight;
            paddingRight = paddingLeft;
            i8++;
            paddingLeft = paddingRight;
            paddingRight = paddingTop;
            paddingTop = i7;
            i7 = measuredWidth;
        }
        max = (i5 - paddingLeft) - paddingRight;
        for (paddingRight = 0; paddingRight < childCount; paddingRight++) {
            View childAt2 = getChildAt(paddingRight);
            if (childAt2.getVisibility() != 8) {
                blVar = (bl) childAt2.getLayoutParams();
                if (!blVar.f496a) {
                    bk f = m394f();
                    if (f != null) {
                        i5 = ((int) (f.f495d * ((float) max))) + paddingLeft;
                        if (blVar.f499d) {
                            blVar.f499d = false;
                            childAt2.measure(MeasureSpec.makeMeasureSpec((int) (blVar.f498c * ((float) max)), 1073741824), MeasureSpec.makeMeasureSpec((i6 - paddingTop) - paddingBottom, 1073741824));
                        }
                        childAt2.layout(i5, paddingTop, childAt2.getMeasuredWidth() + i5, childAt2.getMeasuredHeight() + paddingTop);
                    }
                }
            }
        }
        this.f454r = paddingTop;
        this.f455s = i6 - paddingBottom;
        this.f439W = i7;
        if (this.f436T) {
            m376a(this.f445i, false, 0, false);
        }
        this.f436T = false;
    }

    protected void onMeasure(int i, int i2) {
        int i3;
        setMeasuredDimension(getDefaultSize(0, i), getDefaultSize(0, i2));
        int measuredWidth = getMeasuredWidth();
        this.f421E = Math.min(measuredWidth / 10, this.f420D);
        int paddingLeft = (measuredWidth - getPaddingLeft()) - getPaddingRight();
        int measuredHeight = (getMeasuredHeight() - getPaddingTop()) - getPaddingBottom();
        int childCount = getChildCount();
        for (int i4 = 0; i4 < childCount; i4++) {
            bl blVar;
            int i5;
            View childAt = getChildAt(i4);
            if (childAt.getVisibility() != 8) {
                blVar = (bl) childAt.getLayoutParams();
                if (blVar != null && blVar.f496a) {
                    int i6 = blVar.f497b & 7;
                    int i7 = blVar.f497b & 112;
                    i3 = Integer.MIN_VALUE;
                    i5 = Integer.MIN_VALUE;
                    Object obj = (i7 == 48 || i7 == 80) ? 1 : null;
                    Object obj2 = (i6 == 3 || i6 == 5) ? 1 : null;
                    if (obj != null) {
                        i3 = 1073741824;
                    } else if (obj2 != null) {
                        i5 = 1073741824;
                    }
                    if (blVar.width != -2) {
                        i7 = 1073741824;
                        i3 = blVar.width != -1 ? blVar.width : paddingLeft;
                    } else {
                        i7 = i3;
                        i3 = paddingLeft;
                    }
                    if (blVar.height != -2) {
                        i5 = 1073741824;
                        if (blVar.height != -1) {
                            measuredWidth = blVar.height;
                            childAt.measure(MeasureSpec.makeMeasureSpec(i3, i7), MeasureSpec.makeMeasureSpec(measuredWidth, i5));
                            if (obj != null) {
                                measuredHeight -= childAt.getMeasuredHeight();
                            } else if (obj2 != null) {
                                paddingLeft -= childAt.getMeasuredWidth();
                            }
                        }
                    }
                    measuredWidth = measuredHeight;
                    childAt.measure(MeasureSpec.makeMeasureSpec(i3, i7), MeasureSpec.makeMeasureSpec(measuredWidth, i5));
                    if (obj != null) {
                        measuredHeight -= childAt.getMeasuredHeight();
                    } else if (obj2 != null) {
                        paddingLeft -= childAt.getMeasuredWidth();
                    }
                }
            }
        }
        this.f458v = MeasureSpec.makeMeasureSpec(paddingLeft, 1073741824);
        this.f459w = MeasureSpec.makeMeasureSpec(measuredHeight, 1073741824);
        this.f460x = true;
        m401b();
        this.f460x = false;
        i3 = getChildCount();
        for (i5 = 0; i5 < i3; i5++) {
            View childAt2 = getChildAt(i5);
            if (childAt2.getVisibility() != 8) {
                blVar = (bl) childAt2.getLayoutParams();
                if (blVar == null || !blVar.f496a) {
                    childAt2.measure(MeasureSpec.makeMeasureSpec((int) (blVar.f498c * ((float) paddingLeft)), 1073741824), this.f459w);
                }
            }
        }
    }

    protected boolean onRequestFocusInDescendants(int i, Rect rect) {
        int i2;
        int i3 = -1;
        int childCount = getChildCount();
        if ((i & 2) != 0) {
            i3 = 1;
            i2 = 0;
        } else {
            i2 = childCount - 1;
            childCount = -1;
        }
        while (i2 != childCount) {
            View childAt = getChildAt(i2);
            if (childAt.getVisibility() == 0) {
                bk f = m394f();
                if (f != null && f.f492a == this.f445i && childAt.requestFocus(i, rect)) {
                    return true;
                }
            }
            i2 += i3;
        }
        return false;
    }

    public void onRestoreInstanceState(Parcelable parcelable) {
        if (parcelable instanceof SavedState) {
            SavedState savedState = (SavedState) parcelable;
            super.onRestoreInstanceState(savedState.f410b);
            if (this.f444h != null) {
                Parcelable parcelable2 = savedState.f412d;
                ClassLoader classLoader = savedState.f413e;
                m377a(savedState.f411c, false, true);
                return;
            }
            this.f446j = savedState.f411c;
            this.f447k = savedState.f412d;
            this.f448l = savedState.f413e;
            return;
        }
        super.onRestoreInstanceState(parcelable);
    }

    public Parcelable onSaveInstanceState() {
        Parcelable savedState = new SavedState(super.onSaveInstanceState());
        savedState.f411c = this.f445i;
        if (this.f444h != null) {
            savedState.f412d = null;
        }
        return savedState;
    }

    protected void onSizeChanged(int i, int i2, int i3, int i4) {
        super.onSizeChanged(i, i2, i3, i4);
        if (i != i3) {
            m375a(i, i3, this.f452p, this.f452p);
        }
    }

    public boolean onTouchEvent(MotionEvent motionEvent) {
        boolean z = false;
        if (this.f433Q) {
            return true;
        }
        if (motionEvent.getAction() == 0 && motionEvent.getEdgeFlags() != 0) {
            return false;
        }
        if (this.f444h == null || this.f444h.m506a() == 0) {
            return false;
        }
        if (this.f428L == null) {
            this.f428L = VelocityTracker.obtain();
        }
        this.f428L.addMovement(motionEvent);
        float x;
        int i;
        float f;
        switch (motionEvent.getAction() & 255) {
            case 0:
                this.f449m.abortAnimation();
                this.f462z = false;
                m401b();
                x = motionEvent.getX();
                this.f425I = x;
                this.f423G = x;
                x = motionEvent.getY();
                this.f426J = x;
                this.f424H = x;
                this.f427K = motionEvent.getPointerId(0);
                break;
            case 1:
                if (this.f418B) {
                    VelocityTracker velocityTracker = this.f428L;
                    velocityTracker.computeCurrentVelocity(1000, (float) this.f430N);
                    int a = (int) ak.m512a(velocityTracker, this.f427K);
                    this.f462z = true;
                    int clientWidth = getClientWidth();
                    int scrollX = getScrollX();
                    bk i2 = m398i();
                    float f2 = ((float) this.f452p) / ((float) clientWidth);
                    i = i2.f492a;
                    f = ((((float) scrollX) / ((float) clientWidth)) - i2.f495d) / (i2.f494c + f2);
                    if (Math.abs((int) (motionEvent.getX(motionEvent.findPointerIndex(this.f427K)) - this.f425I)) <= this.f431O || Math.abs(a) <= this.f429M) {
                        scrollX = i + ((int) ((i >= this.f445i ? 0.4f : 0.6f) + f));
                    } else {
                        if (a <= 0) {
                            i++;
                        }
                        scrollX = i;
                    }
                    if (this.f441e.size() > 0) {
                        scrollX = Math.max(((bk) this.f441e.get(0)).f492a, Math.min(scrollX, ((bk) this.f441e.get(this.f441e.size() - 1)).f492a));
                    }
                    m378a(scrollX, true, true, a);
                    z = m396g();
                    break;
                }
                break;
            case 2:
                if (!this.f418B) {
                    i = motionEvent.findPointerIndex(this.f427K);
                    if (i == -1) {
                        z = m396g();
                        break;
                    }
                    float x2 = motionEvent.getX(i);
                    f = Math.abs(x2 - this.f423G);
                    float y = motionEvent.getY(i);
                    x = Math.abs(y - this.f424H);
                    if (f > ((float) this.f422F) && f > x) {
                        this.f418B = true;
                        m397h();
                        this.f423G = x2 - this.f425I > 0.0f ? this.f425I + ((float) this.f422F) : this.f425I - ((float) this.f422F);
                        this.f424H = y;
                        setScrollState(1);
                        setScrollingCacheEnabled(true);
                        ViewParent parent = getParent();
                        if (parent != null) {
                            parent.requestDisallowInterceptTouchEvent(true);
                        }
                    }
                }
                if (this.f418B) {
                    z = m386b(motionEvent.getX(motionEvent.findPointerIndex(this.f427K))) | 0;
                    break;
                }
                break;
            case 3:
                if (this.f418B) {
                    m376a(this.f445i, true, 0, false);
                    z = m396g();
                    break;
                }
                break;
            case 5:
                i = ac.m503a(motionEvent);
                this.f423G = motionEvent.getX(i);
                this.f427K = motionEvent.getPointerId(i);
                break;
            case 6:
                m381a(motionEvent);
                this.f423G = motionEvent.getX(motionEvent.findPointerIndex(this.f427K));
                break;
        }
        if (z) {
            ao.m517a(this);
        }
        return true;
    }

    public void removeView(View view) {
        if (this.f460x) {
            removeViewInLayout(view);
        } else {
            super.removeView(view);
        }
    }

    public void setAdapter(ai aiVar) {
        int i;
        int i2 = false;
        if (this.f444h != null) {
            this.f444h.m507a(null);
            for (i = 0; i < this.f441e.size(); i++) {
                this.f441e.get(i);
                ai.m505b();
            }
            this.f441e.clear();
            int i3 = 0;
            while (i3 < getChildCount()) {
                if (!((bl) getChildAt(i3).getLayoutParams()).f496a) {
                    removeViewAt(i3);
                    i3--;
                }
                i3++;
            }
            this.f445i = 0;
            scrollTo(0, 0);
        }
        this.f444h = aiVar;
        this.f440b = 0;
        if (this.f444h != null) {
            if (this.f451o == null) {
                this.f451o = new bp();
            }
            this.f444h.m507a(this.f451o);
            this.f462z = false;
            boolean z = this.f436T;
            this.f436T = true;
            this.f440b = this.f444h.m506a();
            if (this.f446j >= 0) {
                m377a(this.f446j, false, true);
                this.f446j = -1;
                this.f447k = null;
                this.f448l = null;
            } else if (z) {
                requestLayout();
            } else {
                m401b();
            }
        }
        if (this.ad != null && !this.ad.isEmpty()) {
            i = this.ad.size();
            while (i2 < i) {
                this.ad.get(i2);
                i2++;
            }
        }
    }

    void setChildrenDrawingOrderEnabledCompat(boolean z) {
        if (VERSION.SDK_INT >= 7) {
            if (this.af == null) {
                try {
                    this.af = ViewGroup.class.getDeclaredMethod("setChildrenDrawingOrderEnabled", new Class[]{Boolean.TYPE});
                } catch (Throwable e) {
                    Log.e("ViewPager", "Can't find setChildrenDrawingOrderEnabled", e);
                }
            }
            try {
                this.af.invoke(this, new Object[]{Boolean.valueOf(z)});
            } catch (Throwable e2) {
                Log.e("ViewPager", "Error changing children drawing order", e2);
            }
        }
    }

    public void setCurrentItem(int i) {
        this.f462z = false;
        m377a(i, !this.f436T, false);
    }

    public void setOffscreenPageLimit(int i) {
        if (i <= 0) {
            Log.w("ViewPager", "Requested offscreen page limit " + i + " too small; defaulting to 1");
            i = 1;
        }
        if (i != this.f417A) {
            this.f417A = i;
            m401b();
        }
    }

    @Deprecated
    public void setOnPageChangeListener(bn bnVar) {
        this.ab = bnVar;
    }

    public void setPageMargin(int i) {
        int i2 = this.f452p;
        this.f452p = i;
        int width = getWidth();
        m375a(width, width, i, i2);
        requestLayout();
    }

    public void setPageMarginDrawable(int i) {
        setPageMarginDrawable(getContext().getResources().getDrawable(i));
    }

    public void setPageMarginDrawable(Drawable drawable) {
        this.f453q = drawable;
        if (drawable != null) {
            refreshDrawableState();
        }
        setWillNotDraw(drawable == null);
        invalidate();
    }

    protected boolean verifyDrawable(Drawable drawable) {
        return super.verifyDrawable(drawable) || drawable == this.f453q;
    }
}
