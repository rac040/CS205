package android.support.v4.view;

import android.view.LayoutInflater;

class C0100u implements C0099t {
    C0100u() {
    }

    public void mo167a(LayoutInflater layoutInflater, ab abVar) {
        layoutInflater.setFactory(abVar != null ? new C0080y(abVar) : null);
    }
}
