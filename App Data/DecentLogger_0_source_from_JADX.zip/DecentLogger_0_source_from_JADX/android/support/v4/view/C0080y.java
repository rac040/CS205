package android.support.v4.view;

import android.content.Context;
import android.util.AttributeSet;
import android.view.LayoutInflater.Factory;
import android.view.View;

class C0080y implements Factory {
    final ab f476a;

    C0080y(ab abVar) {
        this.f476a = abVar;
    }

    public View onCreateView(String str, Context context, AttributeSet attributeSet) {
        return this.f476a.mo53a(null, str, context, attributeSet);
    }

    public String toString() {
        return getClass().getName() + "{" + this.f476a + "}";
    }
}
