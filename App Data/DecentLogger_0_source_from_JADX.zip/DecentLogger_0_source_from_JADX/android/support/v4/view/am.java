package android.support.v4.view;

import android.view.VelocityTracker;

final class am implements an {
    am() {
    }

    public final float mo110a(VelocityTracker velocityTracker, int i) {
        return velocityTracker.getXVelocity(i);
    }
}
