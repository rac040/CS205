package android.support.v4.view;

class as extends at {
    as() {
    }
}
