package android.support.v4.view;

import android.os.Parcel;
import android.support.v4.p001b.C0032d;
import android.support.v4.view.ViewPager.SavedState;

final class bq implements C0032d {
    bq() {
    }

    public final /* synthetic */ Object mo108a(Parcel parcel, ClassLoader classLoader) {
        return new SavedState(parcel, classLoader);
    }

    public final /* bridge */ /* synthetic */ Object[] mo109a(int i) {
        return new SavedState[i];
    }
}
