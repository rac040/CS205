package android.support.v4.view;

import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import android.support.v4.p001b.C0030b;

public abstract class AbsSavedState implements Parcelable {
    public static final Creator CREATOR = C0030b.m295a(new C0079a());
    public static final AbsSavedState f409a = new C00521();
    final Parcelable f410b;

    final class C00521 extends AbsSavedState {
        C00521() {
            super();
        }
    }

    private AbsSavedState() {
        this.f410b = null;
    }

    protected AbsSavedState(Parcel parcel, ClassLoader classLoader) {
        Parcelable readParcelable = parcel.readParcelable(classLoader);
        if (readParcelable == null) {
            readParcelable = f409a;
        }
        this.f410b = readParcelable;
    }

    protected AbsSavedState(Parcelable parcelable) {
        if (parcelable == null) {
            throw new IllegalArgumentException("superState must not be null");
        }
        if (parcelable == f409a) {
            parcelable = null;
        }
        this.f410b = parcelable;
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeParcelable(this.f410b, i);
    }
}
