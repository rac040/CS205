package android.support.v4.view;

import android.view.View;

public interface be {
    Object mo126a(View view, Object obj);
}
