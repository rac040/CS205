package android.support.v4.view;

import android.view.View;

interface bb {
    bs mo111a(View view, bs bsVar);

    void mo112a(View view);

    void mo113a(View view, ah ahVar);

    void mo114a(View view, C0081b c0081b);

    void mo115a(View view, Runnable runnable);

    boolean mo116a(View view, int i);

    int mo117b(View view);

    bs mo118b(View view, bs bsVar);

    void mo119b(View view, int i);

    void mo120c(View view);

    int mo121d(View view);

    boolean mo122e(View view);

    void mo123f(View view);

    boolean mo124g(View view);
}
