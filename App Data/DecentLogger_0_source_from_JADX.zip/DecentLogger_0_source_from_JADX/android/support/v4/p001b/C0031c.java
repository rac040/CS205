package android.support.v4.p001b;

import android.os.Parcel;
import android.os.Parcelable.Creator;

final class C0031c implements Creator {
    final C0032d f371a;

    public C0031c(C0032d c0032d) {
        this.f371a = c0032d;
    }

    public final Object createFromParcel(Parcel parcel) {
        return this.f371a.mo108a(parcel, null);
    }

    public final Object[] newArray(int i) {
        return this.f371a.mo109a(i);
    }
}
