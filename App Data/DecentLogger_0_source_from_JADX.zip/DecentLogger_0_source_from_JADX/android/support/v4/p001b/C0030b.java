package android.support.v4.p001b;

import android.os.Build.VERSION;
import android.os.Parcelable.Creator;

public final class C0030b {
    public static Creator m295a(C0032d c0032d) {
        return VERSION.SDK_INT >= 13 ? new C0033e(c0032d) : new C0031c(c0032d);
    }
}
