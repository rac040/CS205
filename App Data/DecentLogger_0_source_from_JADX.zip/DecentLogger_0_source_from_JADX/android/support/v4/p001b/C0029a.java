package android.support.v4.p001b;

import android.os.Build.VERSION;

public final class C0029a {
    public static boolean m294a() {
        return VERSION.SDK_INT >= 24;
    }
}
