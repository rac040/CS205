package android.support.v4.p001b;

import android.os.Parcel;
import android.os.Parcelable.ClassLoaderCreator;

final class C0033e implements ClassLoaderCreator {
    private final C0032d f372a;

    public C0033e(C0032d c0032d) {
        this.f372a = c0032d;
    }

    public final Object createFromParcel(Parcel parcel) {
        return this.f372a.mo108a(parcel, null);
    }

    public final Object createFromParcel(Parcel parcel, ClassLoader classLoader) {
        return this.f372a.mo108a(parcel, classLoader);
    }

    public final Object[] newArray(int i) {
        return this.f372a.mo109a(i);
    }
}
