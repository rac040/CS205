package android.support.v4.p001b;

import android.os.Parcel;

public interface C0032d {
    Object mo108a(Parcel parcel, ClassLoader classLoader);

    Object[] mo109a(int i);
}
