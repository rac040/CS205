package android.support.v4.p000a;

public interface C0002c {
}
