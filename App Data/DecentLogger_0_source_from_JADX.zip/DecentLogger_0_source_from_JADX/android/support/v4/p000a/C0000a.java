package android.support.v4.p000a;

import android.support.v4.p002c.C0039d;

public final class C0000a {
    public int f0a;
    public C0002c f1b;
    public C0001b f2c;
    public boolean f3d;
    public boolean f4e;
    public boolean f5f;
    public boolean f6g;
    public boolean f7h;

    public final void m0a(C0001b c0001b) {
        if (this.f2c == null) {
            throw new IllegalStateException("No listener register");
        } else if (this.f2c != c0001b) {
            throw new IllegalArgumentException("Attempting to unregister the wrong listener");
        } else {
            this.f2c = null;
        }
    }

    public final void m1a(C0002c c0002c) {
        if (this.f1b == null) {
            throw new IllegalStateException("No listener register");
        } else if (this.f1b != c0002c) {
            throw new IllegalArgumentException("Attempting to unregister the wrong listener");
        } else {
            this.f1b = null;
        }
    }

    public final String toString() {
        StringBuilder stringBuilder = new StringBuilder(64);
        C0039d.m334a(this, stringBuilder);
        stringBuilder.append(" id=");
        stringBuilder.append(this.f0a);
        stringBuilder.append("}");
        return stringBuilder.toString();
    }
}
