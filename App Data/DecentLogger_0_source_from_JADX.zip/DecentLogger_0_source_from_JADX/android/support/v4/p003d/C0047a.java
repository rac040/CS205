package android.support.v4.p003d;

import android.content.Context;
import android.graphics.Canvas;
import android.os.Build.VERSION;

public final class C0047a {
    private static final C0048d f407b;
    private Object f408a;

    static {
        if (VERSION.SDK_INT >= 21) {
            f407b = new C0051e();
        } else if (VERSION.SDK_INT >= 14) {
            f407b = new C0050c();
        } else {
            f407b = new C0049b();
        }
    }

    public C0047a(Context context) {
        this.f408a = f407b.mo67a(context);
    }

    public final void m344a(int i, int i2) {
        f407b.mo68a(this.f408a, i, i2);
    }

    public final boolean m345a() {
        return f407b.mo69a(this.f408a);
    }

    @Deprecated
    public final boolean m346a(float f) {
        return f407b.mo70a(this.f408a, f);
    }

    public final boolean m347a(Canvas canvas) {
        return f407b.mo71a(this.f408a, canvas);
    }

    public final void m348b() {
        f407b.mo72b(this.f408a);
    }

    public final boolean m349c() {
        return f407b.mo73c(this.f408a);
    }
}
