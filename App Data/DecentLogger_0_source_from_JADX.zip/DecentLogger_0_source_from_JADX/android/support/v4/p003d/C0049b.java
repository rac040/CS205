package android.support.v4.p003d;

import android.content.Context;
import android.graphics.Canvas;

final class C0049b implements C0048d {
    C0049b() {
    }

    public final Object mo67a(Context context) {
        return null;
    }

    public final void mo68a(Object obj, int i, int i2) {
    }

    public final boolean mo69a(Object obj) {
        return true;
    }

    public final boolean mo70a(Object obj, float f) {
        return false;
    }

    public final boolean mo71a(Object obj, Canvas canvas) {
        return false;
    }

    public final void mo72b(Object obj) {
    }

    public final boolean mo73c(Object obj) {
        return false;
    }
}
