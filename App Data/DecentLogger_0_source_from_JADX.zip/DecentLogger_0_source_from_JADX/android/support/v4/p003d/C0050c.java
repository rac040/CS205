package android.support.v4.p003d;

import android.content.Context;
import android.graphics.Canvas;
import android.widget.EdgeEffect;

class C0050c implements C0048d {
    C0050c() {
    }

    public final Object mo67a(Context context) {
        return new EdgeEffect(context);
    }

    public final void mo68a(Object obj, int i, int i2) {
        ((EdgeEffect) obj).setSize(i, i2);
    }

    public final boolean mo69a(Object obj) {
        return ((EdgeEffect) obj).isFinished();
    }

    public final boolean mo70a(Object obj, float f) {
        ((EdgeEffect) obj).onPull(f);
        return true;
    }

    public final boolean mo71a(Object obj, Canvas canvas) {
        return ((EdgeEffect) obj).draw(canvas);
    }

    public final void mo72b(Object obj) {
        ((EdgeEffect) obj).finish();
    }

    public final boolean mo73c(Object obj) {
        EdgeEffect edgeEffect = (EdgeEffect) obj;
        edgeEffect.onRelease();
        return edgeEffect.isFinished();
    }
}
