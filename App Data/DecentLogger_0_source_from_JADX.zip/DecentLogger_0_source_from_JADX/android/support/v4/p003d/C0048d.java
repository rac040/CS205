package android.support.v4.p003d;

import android.content.Context;
import android.graphics.Canvas;

interface C0048d {
    Object mo67a(Context context);

    void mo68a(Object obj, int i, int i2);

    boolean mo69a(Object obj);

    boolean mo70a(Object obj, float f);

    boolean mo71a(Object obj, Canvas canvas);

    void mo72b(Object obj);

    boolean mo73c(Object obj);
}
