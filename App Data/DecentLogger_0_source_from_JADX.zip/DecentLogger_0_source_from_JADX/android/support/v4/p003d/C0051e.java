package android.support.v4.p003d;

final class C0051e extends C0050c {
    C0051e() {
    }
}
