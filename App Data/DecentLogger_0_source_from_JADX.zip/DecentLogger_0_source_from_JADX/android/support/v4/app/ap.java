package android.support.v4.app;

import android.support.v4.p000a.C0000a;

public interface ap {
    C0000a m52a();
}
