package android.support.v4.app;

import android.app.Notification;
import android.app.PendingIntent;
import android.content.Context;
import android.os.Bundle;
import java.util.ArrayList;

class bl implements bh {
    bl() {
    }

    public Notification mo14a(bb bbVar) {
        Notification notification = bbVar.f136F;
        Context context = bbVar.f138a;
        CharSequence charSequence = bbVar.f139b;
        CharSequence charSequence2 = bbVar.f140c;
        PendingIntent pendingIntent = bbVar.f141d;
        PendingIntent pendingIntent2 = bbVar.f142e;
        notification.setLatestEventInfo(context, charSequence, charSequence2, pendingIntent);
        notification.fullScreenIntent = pendingIntent2;
        if (bbVar.f147j > 0) {
            notification.flags |= 128;
        }
        if (bbVar.f133C != null) {
            notification.contentView = bbVar.f133C;
        }
        return notification;
    }

    public Bundle mo16a(Notification notification) {
        return null;
    }

    public ArrayList mo15a(aw[] awVarArr) {
        return null;
    }
}
