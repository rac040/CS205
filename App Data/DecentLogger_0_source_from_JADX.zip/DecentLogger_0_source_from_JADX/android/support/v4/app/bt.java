package android.support.v4.app;

import android.app.Notification;
import android.app.Notification.Builder;
import android.app.PendingIntent;
import android.content.Context;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.widget.RemoteViews;
import java.util.ArrayList;

public final class bt implements at, au {
    private Builder f186a;
    private Bundle f187b;
    private RemoteViews f188c;
    private RemoteViews f189d;

    public bt(Context context, Notification notification, CharSequence charSequence, CharSequence charSequence2, CharSequence charSequence3, RemoteViews remoteViews, int i, PendingIntent pendingIntent, PendingIntent pendingIntent2, Bitmap bitmap, int i2, int i3, boolean z, boolean z2, boolean z3, int i4, CharSequence charSequence4, boolean z4, ArrayList arrayList, Bundle bundle, String str, boolean z5, String str2, RemoteViews remoteViews2, RemoteViews remoteViews3) {
        this.f186a = new Builder(context).setWhen(notification.when).setShowWhen(z2).setSmallIcon(notification.icon, notification.iconLevel).setContent(notification.contentView).setTicker(notification.tickerText, remoteViews).setSound(notification.sound, notification.audioStreamType).setVibrate(notification.vibrate).setLights(notification.ledARGB, notification.ledOnMS, notification.ledOffMS).setOngoing((notification.flags & 2) != 0).setOnlyAlertOnce((notification.flags & 8) != 0).setAutoCancel((notification.flags & 16) != 0).setDefaults(notification.defaults).setContentTitle(charSequence).setContentText(charSequence2).setSubText(charSequence4).setContentInfo(charSequence3).setContentIntent(pendingIntent).setDeleteIntent(notification.deleteIntent).setFullScreenIntent(pendingIntent2, (notification.flags & 128) != 0).setLargeIcon(bitmap).setNumber(i).setUsesChronometer(z3).setPriority(i4).setProgress(i2, i3, z).setLocalOnly(z4).setGroup(str).setGroupSummary(z5).setSortKey(str2);
        this.f187b = new Bundle();
        if (bundle != null) {
            this.f187b.putAll(bundle);
        }
        if (!(arrayList == null || arrayList.isEmpty())) {
            this.f187b.putStringArray("android.people", (String[]) arrayList.toArray(new String[arrayList.size()]));
        }
        this.f188c = remoteViews2;
        this.f189d = remoteViews3;
    }

    public final Builder mo18a() {
        return this.f186a;
    }

    public final void mo19a(bz bzVar) {
        bs.m117a(this.f186a, bzVar);
    }

    public final Notification mo20b() {
        this.f186a.setExtras(this.f187b);
        Notification build = this.f186a.build();
        if (this.f188c != null) {
            build.contentView = this.f188c;
        }
        if (this.f189d != null) {
            build.bigContentView = this.f189d;
        }
        return build;
    }
}
