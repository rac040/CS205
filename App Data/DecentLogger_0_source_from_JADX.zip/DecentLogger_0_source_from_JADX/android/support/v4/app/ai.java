package android.support.v4.app;

import android.graphics.Rect;
import android.transition.Transition;
import android.transition.Transition.EpicenterCallback;

final class ai extends EpicenterCallback {
    final /* synthetic */ Rect f63a;

    ai(Rect rect) {
        this.f63a = rect;
    }

    public final Rect onGetEpicenter(Transition transition) {
        return this.f63a;
    }
}
