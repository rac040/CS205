package android.support.v4.app;

import android.app.Notification;
import android.os.Bundle;
import java.util.ArrayList;

class bo extends bl {
    bo() {
    }

    public Notification mo14a(bb bbVar) {
        au ceVar = new ce(bbVar.f138a, bbVar.f136F, bbVar.f139b, bbVar.f140c, bbVar.f145h, bbVar.f143f, bbVar.f146i, bbVar.f141d, bbVar.f142e, bbVar.f144g, bbVar.f153p, bbVar.f154q, bbVar.f155r, bbVar.f149l, bbVar.f147j, bbVar.f151n, bbVar.f160w, bbVar.f162y, bbVar.f156s, bbVar.f157t, bbVar.f158u, bbVar.f133C, bbVar.f134D);
        av.m71a((at) ceVar, bbVar.f159v);
        av.m74c(ceVar, bbVar.f150m);
        Notification b = ceVar.mo20b();
        if (bbVar.f150m != null) {
            bbVar.f150m.mo13a(mo16a(b));
        }
        return b;
    }

    public Bundle mo16a(Notification notification) {
        return cd.m131a(notification);
    }

    public ArrayList mo15a(aw[] awVarArr) {
        return cd.m133a((bz[]) awVarArr);
    }
}
