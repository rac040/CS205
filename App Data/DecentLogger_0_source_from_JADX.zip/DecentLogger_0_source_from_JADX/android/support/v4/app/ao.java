package android.support.v4.app;

public abstract class ao {
    public boolean mo5a() {
        return false;
    }
}
