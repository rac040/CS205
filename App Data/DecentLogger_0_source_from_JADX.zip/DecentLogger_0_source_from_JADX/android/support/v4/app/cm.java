package android.support.v4.app;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;

final class cm implements ck {
    cm() {
    }

    public final Bundle mo26a(Intent intent) {
        Log.w("RemoteInput", "RemoteInput is only supported from API Level 16");
        return null;
    }
}
