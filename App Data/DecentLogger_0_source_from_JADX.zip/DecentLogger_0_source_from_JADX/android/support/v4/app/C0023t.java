package android.support.v4.app;

public final class C0023t {
    public final C0020u f334a;

    C0023t(C0020u c0020u) {
        this.f334a = c0020u;
    }

    public final C0013l m229a(String str) {
        return this.f334a.f324f.m256a(str);
    }

    public final void m230a() {
        this.f334a.f324f.f358t = false;
    }

    public final void m231a(boolean z) {
        C0020u c0020u = this.f334a;
        c0020u.f326h = z;
        if (c0020u.f327i != null && c0020u.f329k) {
            c0020u.f329k = false;
            if (z) {
                c0020u.f327i.m58d();
            } else {
                c0020u.f327i.m57c();
            }
        }
    }

    public final boolean m232b() {
        return this.f334a.f324f.m281c();
    }

    public final void m233c() {
        C0020u c0020u = this.f334a;
        if (!c0020u.f329k) {
            c0020u.f329k = true;
            if (c0020u.f327i != null) {
                c0020u.f327i.m56b();
            } else if (!c0020u.f328j) {
                c0020u.f327i = c0020u.m215b("(root)");
                if (!(c0020u.f327i == null || c0020u.f327i.f90e)) {
                    c0020u.f327i.m56b();
                }
            }
            c0020u.f328j = true;
        }
    }
}
