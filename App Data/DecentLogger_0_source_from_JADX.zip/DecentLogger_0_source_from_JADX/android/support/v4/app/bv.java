package android.support.v4.app;

import android.app.Notification;
import android.app.Notification.Builder;
import android.app.PendingIntent;
import android.content.Context;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.widget.RemoteViews;
import java.util.ArrayList;
import java.util.Iterator;

public final class bv implements at, au {
    private Builder f190a;
    private Bundle f191b;
    private RemoteViews f192c;
    private RemoteViews f193d;
    private RemoteViews f194e;

    public bv(Context context, Notification notification, CharSequence charSequence, CharSequence charSequence2, CharSequence charSequence3, RemoteViews remoteViews, int i, PendingIntent pendingIntent, PendingIntent pendingIntent2, Bitmap bitmap, int i2, int i3, boolean z, boolean z2, boolean z3, int i4, CharSequence charSequence4, boolean z4, String str, ArrayList arrayList, Bundle bundle, int i5, int i6, Notification notification2, String str2, boolean z5, String str3, RemoteViews remoteViews2, RemoteViews remoteViews3, RemoteViews remoteViews4) {
        this.f190a = new Builder(context).setWhen(notification.when).setShowWhen(z2).setSmallIcon(notification.icon, notification.iconLevel).setContent(notification.contentView).setTicker(notification.tickerText, remoteViews).setSound(notification.sound, notification.audioStreamType).setVibrate(notification.vibrate).setLights(notification.ledARGB, notification.ledOnMS, notification.ledOffMS).setOngoing((notification.flags & 2) != 0).setOnlyAlertOnce((notification.flags & 8) != 0).setAutoCancel((notification.flags & 16) != 0).setDefaults(notification.defaults).setContentTitle(charSequence).setContentText(charSequence2).setSubText(charSequence4).setContentInfo(charSequence3).setContentIntent(pendingIntent).setDeleteIntent(notification.deleteIntent).setFullScreenIntent(pendingIntent2, (notification.flags & 128) != 0).setLargeIcon(bitmap).setNumber(i).setUsesChronometer(z3).setPriority(i4).setProgress(i2, i3, z).setLocalOnly(z4).setGroup(str2).setGroupSummary(z5).setSortKey(str3).setCategory(str).setColor(i5).setVisibility(i6).setPublicVersion(notification2);
        this.f191b = new Bundle();
        if (bundle != null) {
            this.f191b.putAll(bundle);
        }
        Iterator it = arrayList.iterator();
        while (it.hasNext()) {
            this.f190a.addPerson((String) it.next());
        }
        this.f192c = remoteViews2;
        this.f193d = remoteViews3;
        this.f194e = remoteViews4;
    }

    public final Builder mo18a() {
        return this.f190a;
    }

    public final void mo19a(bz bzVar) {
        bs.m117a(this.f190a, bzVar);
    }

    public final Notification mo20b() {
        this.f190a.setExtras(this.f191b);
        Notification build = this.f190a.build();
        if (this.f192c != null) {
            build.contentView = this.f192c;
        }
        if (this.f193d != null) {
            build.bigContentView = this.f193d;
        }
        if (this.f194e != null) {
            build.headsUpContentView = this.f194e;
        }
        return build;
    }
}
