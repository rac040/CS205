package android.support.v4.app;

import android.app.PendingIntent;
import android.os.Bundle;

public final class aw extends bz {
    public static final ca f109d = new ax();
    public int f110a;
    public CharSequence f111b;
    public PendingIntent f112c;
    private final Bundle f113e;
    private final ch[] f114f;
    private boolean f115g;

    private aw(int i, CharSequence charSequence, PendingIntent pendingIntent, Bundle bundle, ch[] chVarArr, boolean z) {
        this.f115g = false;
        this.f110a = i;
        this.f111b = bb.m89d(charSequence);
        this.f112c = pendingIntent;
        if (bundle == null) {
            bundle = new Bundle();
        }
        this.f113e = bundle;
        this.f114f = chVarArr;
        this.f115g = z;
    }

    public final int mo6a() {
        return this.f110a;
    }

    public final CharSequence mo7b() {
        return this.f111b;
    }

    public final PendingIntent mo8c() {
        return this.f112c;
    }

    public final Bundle mo9d() {
        return this.f113e;
    }

    public final boolean mo10e() {
        return this.f115g;
    }

    public final /* bridge */ /* synthetic */ cq[] mo11f() {
        return this.f114f;
    }
}
