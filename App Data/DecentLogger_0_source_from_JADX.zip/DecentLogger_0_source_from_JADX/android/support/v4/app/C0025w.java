package android.support.v4.app;

import android.content.Context;
import android.content.res.Configuration;
import android.content.res.TypedArray;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.os.Parcelable;
import android.support.v4.p002c.C0039d;
import android.support.v4.p002c.C0040e;
import android.support.v4.view.ab;
import android.support.v4.view.ao;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseArray;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.Animation.AnimationListener;
import android.view.animation.AnimationSet;
import android.view.animation.AnimationUtils;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.Interpolator;
import android.view.animation.ScaleAnimation;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

final class C0025w extends C0024v implements ab {
    static final Interpolator f335A = new DecelerateInterpolator(2.5f);
    static final Interpolator f336B = new DecelerateInterpolator(1.5f);
    static final Interpolator f337C = new AccelerateInterpolator(2.5f);
    static final Interpolator f338D = new AccelerateInterpolator(1.5f);
    static boolean f339a = false;
    static final boolean f340b;
    static Field f341r = null;
    ArrayList f342c;
    Runnable[] f343d;
    boolean f344e;
    ArrayList f345f;
    ArrayList f346g;
    ArrayList f347h;
    ArrayList f348i;
    ArrayList f349j;
    ArrayList f350k;
    ArrayList f351l;
    ArrayList f352m;
    int f353n = 0;
    C0020u f354o;
    C0015s f355p;
    C0013l f356q;
    boolean f357s;
    boolean f358t;
    boolean f359u;
    String f360v;
    boolean f361w;
    Bundle f362x = null;
    SparseArray f363y = null;
    Runnable f364z = new C0026x(this);

    static {
        boolean z = false;
        if (VERSION.SDK_INT >= 11) {
            z = true;
        }
        f340b = z;
    }

    C0025w() {
    }

    private C0013l m239a(Bundle bundle, String str) {
        int i = bundle.getInt(str, -1);
        if (i == -1) {
            return null;
        }
        if (i >= this.f345f.size()) {
            m245a(new IllegalStateException("Fragment no longer exists for key " + str + ": index " + i));
        }
        C0013l c0013l = (C0013l) this.f345f.get(i);
        if (c0013l != null) {
            return c0013l;
        }
        m245a(new IllegalStateException("Fragment no longer exists for key " + str + ": index " + i));
        return c0013l;
    }

    private static Animation m240a(float f, float f2) {
        Animation alphaAnimation = new AlphaAnimation(f, f2);
        alphaAnimation.setInterpolator(f336B);
        alphaAnimation.setDuration(220);
        return alphaAnimation;
    }

    private static Animation m241a(float f, float f2, float f3, float f4) {
        Animation animationSet = new AnimationSet(false);
        Animation scaleAnimation = new ScaleAnimation(f, f2, f, f2, 1, 0.5f, 1, 0.5f);
        scaleAnimation.setInterpolator(f335A);
        scaleAnimation.setDuration(220);
        animationSet.addAnimation(scaleAnimation);
        scaleAnimation = new AlphaAnimation(f3, f4);
        scaleAnimation.setInterpolator(f336B);
        scaleAnimation.setDuration(220);
        animationSet.addAnimation(scaleAnimation);
        return animationSet;
    }

    private Animation m242a(C0013l c0013l, int i, boolean z, int i2) {
        int i3 = c0013l.f273Q;
        C0013l.m170m();
        if (c0013l.f273Q != 0) {
            Animation loadAnimation = AnimationUtils.loadAnimation(this.f354o.f321c, c0013l.f273Q);
            if (loadAnimation != null) {
                return loadAnimation;
            }
        }
        if (i == 0) {
            return null;
        }
        Object obj = -1;
        switch (i) {
            case 4097:
                if (!z) {
                    obj = 2;
                    break;
                }
                obj = 1;
                break;
            case 4099:
                if (!z) {
                    obj = 6;
                    break;
                }
                obj = 5;
                break;
            case 8194:
                if (!z) {
                    obj = 4;
                    break;
                }
                obj = 3;
                break;
        }
        if (obj < null) {
            return null;
        }
        switch (obj) {
            case 1:
                return C0025w.m241a(1.125f, 1.0f, 0.0f, 1.0f);
            case 2:
                return C0025w.m241a(1.0f, 0.975f, 1.0f, 0.0f);
            case 3:
                return C0025w.m241a(0.975f, 1.0f, 0.0f, 1.0f);
            case 4:
                return C0025w.m241a(1.0f, 1.075f, 1.0f, 0.0f);
            case 5:
                return C0025w.m240a(0.0f, 1.0f);
            case 6:
                return C0025w.m240a(1.0f, 0.0f);
            default:
                if (i2 == 0 && this.f354o.mo50e()) {
                    i2 = this.f354o.mo51f();
                }
                return i2 == 0 ? null : null;
        }
    }

    private void m243a(int i, C0003a c0003a) {
        synchronized (this) {
            if (this.f350k == null) {
                this.f350k = new ArrayList();
            }
            int size = this.f350k.size();
            if (i < size) {
                if (f339a) {
                    Log.v("FragmentManager", "Setting back stack index " + i + " to " + c0003a);
                }
                this.f350k.set(i, c0003a);
            } else {
                while (size < i) {
                    this.f350k.add(null);
                    if (this.f351l == null) {
                        this.f351l = new ArrayList();
                    }
                    if (f339a) {
                        Log.v("FragmentManager", "Adding available back stack index " + size);
                    }
                    this.f351l.add(Integer.valueOf(size));
                    size++;
                }
                if (f339a) {
                    Log.v("FragmentManager", "Adding back stack index " + i + " with " + c0003a);
                }
                this.f350k.add(c0003a);
            }
        }
    }

    private static void m244a(View view, Animation animation) {
        Object obj = null;
        if (view != null && animation != null) {
            if (VERSION.SDK_INT >= 19 && ao.m526d(view) == 0 && ao.m528f(view)) {
                Object obj2;
                if (animation instanceof AlphaAnimation) {
                    obj2 = 1;
                } else {
                    if (animation instanceof AnimationSet) {
                        List animations = ((AnimationSet) animation).getAnimations();
                        for (int i = 0; i < animations.size(); i++) {
                            if (animations.get(i) instanceof AlphaAnimation) {
                                i = 1;
                                break;
                            }
                        }
                    }
                    obj2 = null;
                }
                if (obj2 != null) {
                    obj = 1;
                }
            }
            if (obj != null) {
                AnimationListener animationListener;
                try {
                    if (f341r == null) {
                        Field declaredField = Animation.class.getDeclaredField("mListener");
                        f341r = declaredField;
                        declaredField.setAccessible(true);
                    }
                    animationListener = (AnimationListener) f341r.get(animation);
                } catch (Throwable e) {
                    Log.e("FragmentManager", "No field with the name mListener is found in Animation class", e);
                    animationListener = null;
                } catch (Throwable e2) {
                    Log.e("FragmentManager", "Cannot access Animation's mListener field", e2);
                    animationListener = null;
                }
                ao.m524b(view, 2);
                animation.setAnimationListener(new aa(view, animation, animationListener));
            }
        }
    }

    private void m245a(RuntimeException runtimeException) {
        Log.e("FragmentManager", runtimeException.getMessage());
        Log.e("FragmentManager", "Activity state:");
        PrintWriter printWriter = new PrintWriter(new C0040e("FragmentManager"));
        if (this.f354o != null) {
            try {
                this.f354o.mo46a("  ", printWriter, new String[0]);
            } catch (Throwable e) {
                Log.e("FragmentManager", "Failed dumping state", e);
            }
        } else {
            try {
                mo55a("  ", null, printWriter, new String[0]);
            } catch (Throwable e2) {
                Log.e("FragmentManager", "Failed dumping state", e2);
            }
        }
        throw runtimeException;
    }

    private C0013l m246b(String str) {
        int size;
        C0013l c0013l;
        if (!(this.f346g == null || str == null)) {
            for (size = this.f346g.size() - 1; size >= 0; size--) {
                c0013l = (C0013l) this.f346g.get(size);
                if (c0013l != null && str.equals(c0013l.f265I)) {
                    return c0013l;
                }
            }
        }
        if (!(this.f345f == null || str == null)) {
            for (size = this.f345f.size() - 1; size >= 0; size--) {
                c0013l = (C0013l) this.f345f.get(size);
                if (c0013l != null && str.equals(c0013l.f265I)) {
                    return c0013l;
                }
            }
        }
        return null;
    }

    private void m247b(C0013l c0013l) {
        m264a(c0013l, this.f353n, 0, 0, false);
    }

    public static int m248c(int i) {
        switch (i) {
            case 4097:
                return 8194;
            case 4099:
                return 4099;
            case 8194:
                return 4097;
            default:
                return 0;
        }
    }

    private void m249c(C0013l c0013l) {
        if (c0013l.f276T != null) {
            if (this.f363y == null) {
                this.f363y = new SparseArray();
            } else {
                this.f363y.clear();
            }
            c0013l.f276T.saveHierarchyState(this.f363y);
            if (this.f363y.size() > 0) {
                c0013l.f287o = this.f363y;
                this.f363y = null;
            }
        }
    }

    private C0013l m250d(int i) {
        int size;
        C0013l c0013l;
        if (this.f346g != null) {
            for (size = this.f346g.size() - 1; size >= 0; size--) {
                c0013l = (C0013l) this.f346g.get(size);
                if (c0013l != null && c0013l.f263G == i) {
                    return c0013l;
                }
            }
        }
        if (this.f345f != null) {
            for (size = this.f345f.size() - 1; size >= 0; size--) {
                c0013l = (C0013l) this.f345f.get(size);
                if (c0013l != null && c0013l.f263G == i) {
                    return c0013l;
                }
            }
        }
        return null;
    }

    private void m251n() {
        if (this.f345f != null) {
            for (int i = 0; i < this.f345f.size(); i++) {
                C0013l c0013l = (C0013l) this.f345f.get(i);
                if (c0013l != null && c0013l.f277U) {
                    if (this.f344e) {
                        this.f361w = true;
                    } else {
                        c0013l.f277U = false;
                        m264a(c0013l, this.f353n, 0, 0, false);
                    }
                }
            }
        }
    }

    private void m252o() {
        if (this.f358t) {
            throw new IllegalStateException("Can not perform this action after onSaveInstanceState");
        } else if (this.f360v != null) {
            throw new IllegalStateException("Can not perform this action inside of " + this.f360v);
        }
    }

    private void m253p() {
        if (this.f361w) {
            int i = 0;
            for (int i2 = 0; i2 < this.f345f.size(); i2++) {
                C0013l c0013l = (C0013l) this.f345f.get(i2);
                if (!(c0013l == null || c0013l.f279W == null)) {
                    i |= c0013l.f279W.mo5a();
                }
            }
            if (i == 0) {
                this.f361w = false;
                m251n();
            }
        }
    }

    public final int m254a(C0003a c0003a) {
        int size;
        synchronized (this) {
            if (this.f351l == null || this.f351l.size() <= 0) {
                if (this.f350k == null) {
                    this.f350k = new ArrayList();
                }
                size = this.f350k.size();
                if (f339a) {
                    Log.v("FragmentManager", "Setting back stack index " + size + " to " + c0003a);
                }
                this.f350k.add(c0003a);
            } else {
                size = ((Integer) this.f351l.remove(this.f351l.size() - 1)).intValue();
                if (f339a) {
                    Log.v("FragmentManager", "Adding back stack index " + size + " with " + c0003a);
                }
                this.f350k.set(size, c0003a);
            }
        }
        return size;
    }

    public final ag mo52a() {
        return new C0003a(this);
    }

    public final C0013l m256a(String str) {
        if (!(this.f345f == null || str == null)) {
            for (int size = this.f345f.size() - 1; size >= 0; size--) {
                C0013l c0013l = (C0013l) this.f345f.get(size);
                if (c0013l != null) {
                    if (!str.equals(c0013l.f289q)) {
                        c0013l = c0013l.f260D != null ? c0013l.f260D.m256a(str) : null;
                    }
                    if (c0013l != null) {
                        return c0013l;
                    }
                }
            }
        }
        return null;
    }

    public final View mo53a(View view, String str, Context context, AttributeSet attributeSet) {
        if (!"fragment".equals(str)) {
            return null;
        }
        String attributeValue = attributeSet.getAttributeValue(null, "class");
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, ac.f60a);
        String string = attributeValue == null ? obtainStyledAttributes.getString(0) : attributeValue;
        int resourceId = obtainStyledAttributes.getResourceId(1, -1);
        String string2 = obtainStyledAttributes.getString(2);
        obtainStyledAttributes.recycle();
        if (!C0013l.m165b(this.f354o.f321c, string)) {
            return null;
        }
        int id = view != null ? view.getId() : 0;
        if (id == -1 && resourceId == -1 && string2 == null) {
            throw new IllegalArgumentException(attributeSet.getPositionDescription() + ": Must specify unique android:id, android:tag, or have a parent with an id for " + string);
        }
        C0013l c0013l;
        C0013l d = resourceId != -1 ? m250d(resourceId) : null;
        if (d == null && string2 != null) {
            d = m246b(string2);
        }
        if (d == null && id != -1) {
            d = m250d(id);
        }
        if (f339a) {
            Log.v("FragmentManager", "onCreateView: id=0x" + Integer.toHexString(resourceId) + " fname=" + string + " existing=" + d);
        }
        if (d == null) {
            C0013l a = C0013l.m162a(context, string);
            a.f296x = true;
            a.f263G = resourceId != 0 ? resourceId : id;
            a.f264H = id;
            a.f265I = string2;
            a.f297y = true;
            a.f258B = this;
            a.f259C = this.f354o;
            Bundle bundle = a.f286n;
            a.m187k();
            m265a(a, true);
            c0013l = a;
        } else if (d.f297y) {
            throw new IllegalArgumentException(attributeSet.getPositionDescription() + ": Duplicate id 0x" + Integer.toHexString(resourceId) + ", tag " + string2 + ", or parent id 0x" + Integer.toHexString(id) + " with another fragment for " + string);
        } else {
            d.f297y = true;
            d.f259C = this.f354o;
            if (!d.f269M) {
                Bundle bundle2 = d.f286n;
                d.m187k();
            }
            c0013l = d;
        }
        if (this.f353n > 0 || !c0013l.f296x) {
            m247b(c0013l);
        } else {
            m264a(c0013l, 1, 0, 0, false);
        }
        if (c0013l.f275S == null) {
            throw new IllegalStateException("Fragment " + string + " did not create a view.");
        }
        if (resourceId != 0) {
            c0013l.f275S.setId(resourceId);
        }
        if (c0013l.f275S.getTag() == null) {
            c0013l.f275S.setTag(string2);
        }
        return c0013l.f275S;
    }

    public final void mo54a(int i) {
        if (i < 0) {
            throw new IllegalArgumentException("Bad id: " + i);
        }
        m267a(new C0027y(this, i), false);
    }

    final void m259a(int i, int i2, int i3, boolean z) {
        if (this.f354o == null && i != 0) {
            throw new IllegalStateException("No host");
        } else if (z || this.f353n != i) {
            this.f353n = i;
            if (this.f345f != null) {
                int i4 = 0;
                int i5 = 0;
                while (i4 < this.f345f.size()) {
                    int a;
                    C0013l c0013l = (C0013l) this.f345f.get(i4);
                    if (c0013l != null) {
                        m264a(c0013l, i, i2, i3, false);
                        if (c0013l.f279W != null) {
                            a = i5 | c0013l.f279W.mo5a();
                            i4++;
                            i5 = a;
                        }
                    }
                    a = i5;
                    i4++;
                    i5 = a;
                }
                if (i5 == 0) {
                    m251n();
                }
                if (this.f357s && this.f354o != null && this.f353n == 5) {
                    this.f354o.mo49d();
                    this.f357s = false;
                }
            }
        }
    }

    public final void m260a(Configuration configuration) {
        if (this.f346g != null) {
            for (int i = 0; i < this.f346g.size(); i++) {
                C0013l c0013l = (C0013l) this.f346g.get(i);
                if (c0013l != null) {
                    c0013l.onConfigurationChanged(configuration);
                    if (c0013l.f260D != null) {
                        c0013l.f260D.m260a(configuration);
                    }
                }
            }
        }
    }

    final void m261a(Parcelable parcelable, ad adVar) {
        if (parcelable != null) {
            FragmentManagerState fragmentManagerState = (FragmentManagerState) parcelable;
            if (fragmentManagerState.f19a != null) {
                List list;
                int size;
                int i;
                C0013l c0013l;
                List list2;
                if (adVar != null) {
                    list = adVar.f61a;
                    List list3 = adVar.f62b;
                    if (list != null) {
                        size = list.size();
                    } else {
                        boolean z = false;
                    }
                    for (i = 0; i < size; i++) {
                        c0013l = (C0013l) list.get(i);
                        if (f339a) {
                            Log.v("FragmentManager", "restoreAllState: re-attaching retained " + c0013l);
                        }
                        FragmentState fragmentState = fragmentManagerState.f19a[c0013l.f288p];
                        fragmentState.f33l = c0013l;
                        c0013l.f287o = null;
                        c0013l.f257A = 0;
                        c0013l.f297y = false;
                        c0013l.f294v = false;
                        c0013l.f291s = null;
                        if (fragmentState.f32k != null) {
                            fragmentState.f32k.setClassLoader(this.f354o.f321c.getClassLoader());
                            c0013l.f287o = fragmentState.f32k.getSparseParcelableArray("android:view_state");
                            c0013l.f286n = fragmentState.f32k;
                        }
                    }
                    list2 = list3;
                } else {
                    list2 = null;
                }
                this.f345f = new ArrayList(fragmentManagerState.f19a.length);
                if (this.f347h != null) {
                    this.f347h.clear();
                }
                int i2 = 0;
                while (i2 < fragmentManagerState.f19a.length) {
                    FragmentState fragmentState2 = fragmentManagerState.f19a[i2];
                    if (fragmentState2 != null) {
                        ad adVar2 = (list2 == null || i2 >= list2.size()) ? null : (ad) list2.get(i2);
                        C0020u c0020u = this.f354o;
                        C0013l c0013l2 = this.f356q;
                        if (fragmentState2.f33l == null) {
                            Context context = c0020u.f321c;
                            if (fragmentState2.f30i != null) {
                                fragmentState2.f30i.setClassLoader(context.getClassLoader());
                            }
                            fragmentState2.f33l = C0013l.m163a(context, fragmentState2.f22a, fragmentState2.f30i);
                            if (fragmentState2.f32k != null) {
                                fragmentState2.f32k.setClassLoader(context.getClassLoader());
                                fragmentState2.f33l.f286n = fragmentState2.f32k;
                            }
                            fragmentState2.f33l.m174a(fragmentState2.f23b, c0013l2);
                            fragmentState2.f33l.f296x = fragmentState2.f24c;
                            fragmentState2.f33l.f298z = true;
                            fragmentState2.f33l.f263G = fragmentState2.f25d;
                            fragmentState2.f33l.f264H = fragmentState2.f26e;
                            fragmentState2.f33l.f265I = fragmentState2.f27f;
                            fragmentState2.f33l.f268L = fragmentState2.f28g;
                            fragmentState2.f33l.f267K = fragmentState2.f29h;
                            fragmentState2.f33l.f266J = fragmentState2.f31j;
                            fragmentState2.f33l.f258B = c0020u.f324f;
                            if (f339a) {
                                Log.v("FragmentManager", "Instantiated fragment " + fragmentState2.f33l);
                            }
                        }
                        fragmentState2.f33l.f261E = adVar2;
                        c0013l = fragmentState2.f33l;
                        if (f339a) {
                            Log.v("FragmentManager", "restoreAllState: active #" + i2 + ": " + c0013l);
                        }
                        this.f345f.add(c0013l);
                        fragmentState2.f33l = null;
                    } else {
                        this.f345f.add(null);
                        if (this.f347h == null) {
                            this.f347h = new ArrayList();
                        }
                        if (f339a) {
                            Log.v("FragmentManager", "restoreAllState: avail #" + i2);
                        }
                        this.f347h.add(Integer.valueOf(i2));
                    }
                    i2++;
                }
                if (adVar != null) {
                    list = adVar.f61a;
                    if (list != null) {
                        i2 = list.size();
                    } else {
                        boolean z2 = false;
                    }
                    for (i = 0; i < i2; i++) {
                        c0013l = (C0013l) list.get(i);
                        if (c0013l.f292t >= 0) {
                            if (c0013l.f292t < this.f345f.size()) {
                                c0013l.f291s = (C0013l) this.f345f.get(c0013l.f292t);
                            } else {
                                Log.w("FragmentManager", "Re-attaching retained fragment " + c0013l + " target no longer exists: " + c0013l.f292t);
                                c0013l.f291s = null;
                            }
                        }
                    }
                }
                if (fragmentManagerState.f20b != null) {
                    this.f346g = new ArrayList(fragmentManagerState.f20b.length);
                    for (size = 0; size < fragmentManagerState.f20b.length; size++) {
                        c0013l = (C0013l) this.f345f.get(fragmentManagerState.f20b[size]);
                        if (c0013l == null) {
                            m245a(new IllegalStateException("No instantiated fragment for index #" + fragmentManagerState.f20b[size]));
                        }
                        c0013l.f294v = true;
                        if (f339a) {
                            Log.v("FragmentManager", "restoreAllState: added #" + size + ": " + c0013l);
                        }
                        if (this.f346g.contains(c0013l)) {
                            throw new IllegalStateException("Already added!");
                        }
                        this.f346g.add(c0013l);
                    }
                } else {
                    this.f346g = null;
                }
                if (fragmentManagerState.f21c != null) {
                    this.f348i = new ArrayList(fragmentManagerState.f21c.length);
                    for (int i3 = 0; i3 < fragmentManagerState.f21c.length; i3++) {
                        C0003a a = fragmentManagerState.f21c[i3].m2a(this);
                        if (f339a) {
                            Log.v("FragmentManager", "restoreAllState: back stack #" + i3 + " (index " + a.f49p + "): " + a);
                            a.m33a("  ", new PrintWriter(new C0040e("FragmentManager")), false);
                        }
                        this.f348i.add(a);
                        if (a.f49p >= 0) {
                            m243a(a.f49p, a);
                        }
                    }
                    return;
                }
                this.f348i = null;
            }
        }
    }

    final void m262a(C0013l c0013l) {
        if (c0013l.f288p < 0) {
            if (this.f347h == null || this.f347h.size() <= 0) {
                if (this.f345f == null) {
                    this.f345f = new ArrayList();
                }
                c0013l.m174a(this.f345f.size(), this.f356q);
                this.f345f.add(c0013l);
            } else {
                c0013l.m174a(((Integer) this.f347h.remove(this.f347h.size() - 1)).intValue(), this.f356q);
                this.f345f.set(c0013l.f288p, c0013l);
            }
            if (f339a) {
                Log.v("FragmentManager", "Allocated fragment index " + c0013l);
            }
        }
    }

    public final void m263a(C0013l c0013l, int i, int i2) {
        if (f339a) {
            Log.v("FragmentManager", "remove: " + c0013l + " nesting=" + c0013l.f257A);
        }
        boolean z = !(c0013l.f257A > 0);
        if (!c0013l.f267K || z) {
            if (this.f346g != null) {
                this.f346g.remove(c0013l);
            }
            if (c0013l.f270N && c0013l.f271O) {
                this.f357s = true;
            }
            c0013l.f294v = false;
            c0013l.f295w = true;
            m264a(c0013l, z ? 0 : 1, i, i2, false);
        }
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    final void m264a(android.support.v4.app.C0013l r11, int r12, int r13, int r14, boolean r15) {
        /*
        r10 = this;
        r9 = 4;
        r6 = 3;
        r5 = 1;
        r7 = 0;
        r3 = 0;
        r0 = r11.f294v;
        if (r0 == 0) goto L_0x000d;
    L_0x0009:
        r0 = r11.f267K;
        if (r0 == 0) goto L_0x0010;
    L_0x000d:
        if (r12 <= r5) goto L_0x0010;
    L_0x000f:
        r12 = r5;
    L_0x0010:
        r0 = r11.f295w;
        if (r0 == 0) goto L_0x001a;
    L_0x0014:
        r0 = r11.f283k;
        if (r12 <= r0) goto L_0x001a;
    L_0x0018:
        r12 = r11.f283k;
    L_0x001a:
        r0 = r11.f277U;
        if (r0 == 0) goto L_0x0025;
    L_0x001e:
        r0 = r11.f283k;
        if (r0 >= r9) goto L_0x0025;
    L_0x0022:
        if (r12 <= r6) goto L_0x0025;
    L_0x0024:
        r12 = r6;
    L_0x0025:
        r0 = r11.f283k;
        if (r0 >= r12) goto L_0x03e2;
    L_0x0029:
        r0 = r11.f296x;
        if (r0 == 0) goto L_0x0032;
    L_0x002d:
        r0 = r11.f297y;
        if (r0 != 0) goto L_0x0032;
    L_0x0031:
        return;
    L_0x0032:
        r0 = r11.f284l;
        if (r0 == 0) goto L_0x0040;
    L_0x0036:
        r11.f284l = r7;
        r2 = r11.f285m;
        r0 = r10;
        r1 = r11;
        r4 = r3;
        r0.m264a(r1, r2, r3, r4, r5);
    L_0x0040:
        r0 = r11.f283k;
        switch(r0) {
            case 0: goto L_0x0076;
            case 1: goto L_0x018f;
            case 2: goto L_0x031d;
            case 3: goto L_0x0322;
            case 4: goto L_0x0381;
            default: goto L_0x0045;
        };
    L_0x0045:
        r0 = r11.f283k;
        if (r0 == r12) goto L_0x0031;
    L_0x0049:
        r0 = "FragmentManager";
        r1 = new java.lang.StringBuilder;
        r2 = "moveToState: Fragment state for ";
        r1.<init>(r2);
        r1 = r1.append(r11);
        r2 = " not updated inline; expected state ";
        r1 = r1.append(r2);
        r1 = r1.append(r12);
        r2 = " found ";
        r1 = r1.append(r2);
        r2 = r11.f283k;
        r1 = r1.append(r2);
        r1 = r1.toString();
        android.util.Log.w(r0, r1);
        r11.f283k = r12;
        goto L_0x0031;
    L_0x0076:
        r0 = f339a;
        if (r0 == 0) goto L_0x008e;
    L_0x007a:
        r0 = "FragmentManager";
        r1 = new java.lang.StringBuilder;
        r2 = "moveto CREATED: ";
        r1.<init>(r2);
        r1 = r1.append(r11);
        r1 = r1.toString();
        android.util.Log.v(r0, r1);
    L_0x008e:
        r0 = r11.f286n;
        if (r0 == 0) goto L_0x00d4;
    L_0x0092:
        r0 = r11.f286n;
        r1 = r10.f354o;
        r1 = r1.f321c;
        r1 = r1.getClassLoader();
        r0.setClassLoader(r1);
        r0 = r11.f286n;
        r1 = "android:view_state";
        r0 = r0.getSparseParcelableArray(r1);
        r11.f287o = r0;
        r0 = r11.f286n;
        r1 = "android:target_state";
        r0 = r10.m239a(r0, r1);
        r11.f291s = r0;
        r0 = r11.f291s;
        if (r0 == 0) goto L_0x00c1;
    L_0x00b7:
        r0 = r11.f286n;
        r1 = "android:target_req_state";
        r0 = r0.getInt(r1, r3);
        r11.f293u = r0;
    L_0x00c1:
        r0 = r11.f286n;
        r1 = "android:user_visible_hint";
        r0 = r0.getBoolean(r1, r5);
        r11.f278V = r0;
        r0 = r11.f278V;
        if (r0 != 0) goto L_0x00d4;
    L_0x00cf:
        r11.f277U = r5;
        if (r12 <= r6) goto L_0x00d4;
    L_0x00d3:
        r12 = r6;
    L_0x00d4:
        r0 = r10.f354o;
        r11.f259C = r0;
        r0 = r10.f356q;
        r11.f262F = r0;
        r0 = r10.f356q;
        if (r0 == 0) goto L_0x010e;
    L_0x00e0:
        r0 = r10.f356q;
        r0 = r0.f260D;
    L_0x00e4:
        r11.f258B = r0;
        r11.f272P = r3;
        r0 = r10.f354o;
        r0 = r0.f321c;
        r11.mo28a(r0);
        r0 = r11.f272P;
        if (r0 != 0) goto L_0x0113;
    L_0x00f3:
        r0 = new android.support.v4.app.cu;
        r1 = new java.lang.StringBuilder;
        r2 = "Fragment ";
        r1.<init>(r2);
        r1 = r1.append(r11);
        r2 = " did not call through to super.onAttach()";
        r1 = r1.append(r2);
        r1 = r1.toString();
        r0.<init>(r1);
        throw r0;
    L_0x010e:
        r0 = r10.f354o;
        r0 = r0.f324f;
        goto L_0x00e4;
    L_0x0113:
        r0 = r11.f262F;
        if (r0 == 0) goto L_0x011c;
    L_0x0117:
        r0 = r11.f262F;
        android.support.v4.app.C0013l.m169l();
    L_0x011c:
        r0 = r11.f269M;
        if (r0 != 0) goto L_0x0150;
    L_0x0120:
        r0 = r11.f286n;
        r1 = r11.f260D;
        if (r1 == 0) goto L_0x012a;
    L_0x0126:
        r1 = r11.f260D;
        r1.f358t = r3;
    L_0x012a:
        r11.f283k = r5;
        r11.f272P = r3;
        r11.mo29a(r0);
        r0 = r11.f272P;
        if (r0 != 0) goto L_0x0157;
    L_0x0135:
        r0 = new android.support.v4.app.cu;
        r1 = new java.lang.StringBuilder;
        r2 = "Fragment ";
        r1.<init>(r2);
        r1 = r1.append(r11);
        r2 = " did not call through to super.onCreate()";
        r1 = r1.append(r2);
        r1 = r1.toString();
        r0.<init>(r1);
        throw r0;
    L_0x0150:
        r0 = r11.f286n;
        r11.m183e(r0);
        r11.f283k = r5;
    L_0x0157:
        r11.f269M = r3;
        r0 = r11.f296x;
        if (r0 == 0) goto L_0x018f;
    L_0x015d:
        r0 = r11.f286n;
        r11.mo31b(r0);
        r0 = r11.f286n;
        r0 = r11.m188p();
        r11.f275S = r0;
        r0 = r11.f275S;
        if (r0 == 0) goto L_0x02bc;
    L_0x016e:
        r0 = r11.f275S;
        r11.f276T = r0;
        r0 = android.os.Build.VERSION.SDK_INT;
        r1 = 11;
        if (r0 < r1) goto L_0x02b2;
    L_0x0178:
        r0 = r11.f275S;
        android.support.v4.view.ao.m527e(r0);
    L_0x017d:
        r0 = r11.f266J;
        if (r0 == 0) goto L_0x0188;
    L_0x0181:
        r0 = r11.f275S;
        r1 = 8;
        r0.setVisibility(r1);
    L_0x0188:
        r0 = r11.f275S;
        r0 = r11.f286n;
        android.support.v4.app.C0013l.m171n();
    L_0x018f:
        if (r12 <= r5) goto L_0x031d;
    L_0x0191:
        r0 = f339a;
        if (r0 == 0) goto L_0x01a9;
    L_0x0195:
        r0 = "FragmentManager";
        r1 = new java.lang.StringBuilder;
        r2 = "moveto ACTIVITY_CREATED: ";
        r1.<init>(r2);
        r1 = r1.append(r11);
        r1 = r1.toString();
        android.util.Log.v(r0, r1);
    L_0x01a9:
        r0 = r11.f296x;
        if (r0 != 0) goto L_0x0281;
    L_0x01ad:
        r0 = r11.f264H;
        if (r0 == 0) goto L_0x0642;
    L_0x01b1:
        r0 = r11.f264H;
        r1 = -1;
        if (r0 != r1) goto L_0x01d3;
    L_0x01b6:
        r0 = new java.lang.IllegalArgumentException;
        r1 = new java.lang.StringBuilder;
        r2 = "Cannot create fragment ";
        r1.<init>(r2);
        r1 = r1.append(r11);
        r2 = " for a container view with no id";
        r1 = r1.append(r2);
        r1 = r1.toString();
        r0.<init>(r1);
        r10.m245a(r0);
    L_0x01d3:
        r0 = r10.f355p;
        r1 = r11.f264H;
        r0 = r0.mo37a(r1);
        r0 = (android.view.ViewGroup) r0;
        if (r0 != 0) goto L_0x0236;
    L_0x01df:
        r1 = r11.f298z;
        if (r1 != 0) goto L_0x0236;
    L_0x01e3:
        r1 = r11.f259C;	 Catch:{ NotFoundException -> 0x0202 }
        if (r1 != 0) goto L_0x02c0;
    L_0x01e7:
        r1 = new java.lang.IllegalStateException;	 Catch:{ NotFoundException -> 0x0202 }
        r2 = new java.lang.StringBuilder;	 Catch:{ NotFoundException -> 0x0202 }
        r4 = "Fragment ";
        r2.<init>(r4);	 Catch:{ NotFoundException -> 0x0202 }
        r2 = r2.append(r11);	 Catch:{ NotFoundException -> 0x0202 }
        r4 = " not attached to Activity";
        r2 = r2.append(r4);	 Catch:{ NotFoundException -> 0x0202 }
        r2 = r2.toString();	 Catch:{ NotFoundException -> 0x0202 }
        r1.<init>(r2);	 Catch:{ NotFoundException -> 0x0202 }
        throw r1;	 Catch:{ NotFoundException -> 0x0202 }
    L_0x0202:
        r1 = move-exception;
        r1 = "unknown";
    L_0x0205:
        r2 = new java.lang.IllegalArgumentException;
        r4 = new java.lang.StringBuilder;
        r8 = "No view found for id 0x";
        r4.<init>(r8);
        r8 = r11.f264H;
        r8 = java.lang.Integer.toHexString(r8);
        r4 = r4.append(r8);
        r8 = " (";
        r4 = r4.append(r8);
        r1 = r4.append(r1);
        r4 = ") for fragment ";
        r1 = r1.append(r4);
        r1 = r1.append(r11);
        r1 = r1.toString();
        r2.<init>(r1);
        r10.m245a(r2);
    L_0x0236:
        r11.f274R = r0;
        r1 = r11.f286n;
        r11.mo31b(r1);
        r1 = r11.f286n;
        r1 = r11.m188p();
        r11.f275S = r1;
        r1 = r11.f275S;
        if (r1 == 0) goto L_0x02d9;
    L_0x0249:
        r1 = r11.f275S;
        r11.f276T = r1;
        r1 = android.os.Build.VERSION.SDK_INT;
        r2 = 11;
        if (r1 < r2) goto L_0x02d0;
    L_0x0253:
        r1 = r11.f275S;
        android.support.v4.view.ao.m527e(r1);
    L_0x0258:
        if (r0 == 0) goto L_0x026f;
    L_0x025a:
        r1 = r10.m242a(r11, r13, r5, r14);
        if (r1 == 0) goto L_0x026a;
    L_0x0260:
        r2 = r11.f275S;
        android.support.v4.app.C0025w.m244a(r2, r1);
        r2 = r11.f275S;
        r2.startAnimation(r1);
    L_0x026a:
        r1 = r11.f275S;
        r0.addView(r1);
    L_0x026f:
        r0 = r11.f266J;
        if (r0 == 0) goto L_0x027a;
    L_0x0273:
        r0 = r11.f275S;
        r1 = 8;
        r0.setVisibility(r1);
    L_0x027a:
        r0 = r11.f275S;
        r0 = r11.f286n;
        android.support.v4.app.C0013l.m171n();
    L_0x0281:
        r0 = r11.f286n;
        r1 = r11.f260D;
        if (r1 == 0) goto L_0x028b;
    L_0x0287:
        r1 = r11.f260D;
        r1.f358t = r3;
    L_0x028b:
        r1 = 2;
        r11.f283k = r1;
        r11.f272P = r3;
        r11.mo33c(r0);
        r0 = r11.f272P;
        if (r0 != 0) goto L_0x02dc;
    L_0x0297:
        r0 = new android.support.v4.app.cu;
        r1 = new java.lang.StringBuilder;
        r2 = "Fragment ";
        r1.<init>(r2);
        r1 = r1.append(r11);
        r2 = " did not call through to super.onActivityCreated()";
        r1 = r1.append(r2);
        r1 = r1.toString();
        r0.<init>(r1);
        throw r0;
    L_0x02b2:
        r0 = r11.f275S;
        r0 = android.support.v4.app.as.m66a(r0);
        r11.f275S = r0;
        goto L_0x017d;
    L_0x02bc:
        r11.f276T = r7;
        goto L_0x018f;
    L_0x02c0:
        r1 = r11.f259C;	 Catch:{ NotFoundException -> 0x0202 }
        r1 = r1.f321c;	 Catch:{ NotFoundException -> 0x0202 }
        r1 = r1.getResources();	 Catch:{ NotFoundException -> 0x0202 }
        r2 = r11.f264H;	 Catch:{ NotFoundException -> 0x0202 }
        r1 = r1.getResourceName(r2);	 Catch:{ NotFoundException -> 0x0202 }
        goto L_0x0205;
    L_0x02d0:
        r1 = r11.f275S;
        r1 = android.support.v4.app.as.m66a(r1);
        r11.f275S = r1;
        goto L_0x0258;
    L_0x02d9:
        r11.f276T = r7;
        goto L_0x0281;
    L_0x02dc:
        r0 = r11.f260D;
        if (r0 == 0) goto L_0x02e5;
    L_0x02e0:
        r0 = r11.f260D;
        r0.m288h();
    L_0x02e5:
        r0 = r11.f275S;
        if (r0 == 0) goto L_0x031b;
    L_0x02e9:
        r0 = r11.f286n;
        r0 = r11.f287o;
        if (r0 == 0) goto L_0x02f8;
    L_0x02ef:
        r0 = r11.f276T;
        r1 = r11.f287o;
        r0.restoreHierarchyState(r1);
        r11.f287o = r7;
    L_0x02f8:
        r11.f272P = r3;
        r11.f272P = r5;
        r0 = r11.f272P;
        if (r0 != 0) goto L_0x031b;
    L_0x0300:
        r0 = new android.support.v4.app.cu;
        r1 = new java.lang.StringBuilder;
        r2 = "Fragment ";
        r1.<init>(r2);
        r1 = r1.append(r11);
        r2 = " did not call through to super.onViewStateRestored()";
        r1 = r1.append(r2);
        r1 = r1.toString();
        r0.<init>(r1);
        throw r0;
    L_0x031b:
        r11.f286n = r7;
    L_0x031d:
        r0 = 2;
        if (r12 <= r0) goto L_0x0322;
    L_0x0320:
        r11.f283k = r6;
    L_0x0322:
        if (r12 <= r6) goto L_0x0381;
    L_0x0324:
        r0 = f339a;
        if (r0 == 0) goto L_0x033c;
    L_0x0328:
        r0 = "FragmentManager";
        r1 = new java.lang.StringBuilder;
        r2 = "moveto STARTED: ";
        r1.<init>(r2);
        r1 = r1.append(r11);
        r1 = r1.toString();
        android.util.Log.v(r0, r1);
    L_0x033c:
        r0 = r11.f260D;
        if (r0 == 0) goto L_0x0349;
    L_0x0340:
        r0 = r11.f260D;
        r0.f358t = r3;
        r0 = r11.f260D;
        r0.m281c();
    L_0x0349:
        r11.f283k = r9;
        r11.f272P = r3;
        r11.mo32c();
        r0 = r11.f272P;
        if (r0 != 0) goto L_0x036f;
    L_0x0354:
        r0 = new android.support.v4.app.cu;
        r1 = new java.lang.StringBuilder;
        r2 = "Fragment ";
        r1.<init>(r2);
        r1 = r1.append(r11);
        r2 = " did not call through to super.onStart()";
        r1 = r1.append(r2);
        r1 = r1.toString();
        r0.<init>(r1);
        throw r0;
    L_0x036f:
        r0 = r11.f260D;
        if (r0 == 0) goto L_0x0378;
    L_0x0373:
        r0 = r11.f260D;
        r0.m289i();
    L_0x0378:
        r0 = r11.f279W;
        if (r0 == 0) goto L_0x0381;
    L_0x037c:
        r0 = r11.f279W;
        r0.m60f();
    L_0x0381:
        if (r12 <= r9) goto L_0x0045;
    L_0x0383:
        r0 = f339a;
        if (r0 == 0) goto L_0x039b;
    L_0x0387:
        r0 = "FragmentManager";
        r1 = new java.lang.StringBuilder;
        r2 = "moveto RESUMED: ";
        r1.<init>(r2);
        r1 = r1.append(r11);
        r1 = r1.toString();
        android.util.Log.v(r0, r1);
    L_0x039b:
        r0 = r11.f260D;
        if (r0 == 0) goto L_0x03a8;
    L_0x039f:
        r0 = r11.f260D;
        r0.f358t = r3;
        r0 = r11.f260D;
        r0.m281c();
    L_0x03a8:
        r0 = 5;
        r11.f283k = r0;
        r11.f272P = r3;
        r11.f272P = r5;
        r0 = r11.f272P;
        if (r0 != 0) goto L_0x03ce;
    L_0x03b3:
        r0 = new android.support.v4.app.cu;
        r1 = new java.lang.StringBuilder;
        r2 = "Fragment ";
        r1.<init>(r2);
        r1 = r1.append(r11);
        r2 = " did not call through to super.onResume()";
        r1 = r1.append(r2);
        r1 = r1.toString();
        r0.<init>(r1);
        throw r0;
    L_0x03ce:
        r0 = r11.f260D;
        if (r0 == 0) goto L_0x03dc;
    L_0x03d2:
        r0 = r11.f260D;
        r0.m290j();
        r0 = r11.f260D;
        r0.m281c();
    L_0x03dc:
        r11.f286n = r7;
        r11.f287o = r7;
        goto L_0x0045;
    L_0x03e2:
        r0 = r11.f283k;
        if (r0 <= r12) goto L_0x0045;
    L_0x03e6:
        r0 = r11.f283k;
        switch(r0) {
            case 1: goto L_0x03ed;
            case 2: goto L_0x04b6;
            case 3: goto L_0x0499;
            case 4: goto L_0x0450;
            case 5: goto L_0x0407;
            default: goto L_0x03eb;
        };
    L_0x03eb:
        goto L_0x0045;
    L_0x03ed:
        if (r12 > 0) goto L_0x0045;
    L_0x03ef:
        r0 = r10.f359u;
        if (r0 == 0) goto L_0x03fe;
    L_0x03f3:
        r0 = r11.f284l;
        if (r0 == 0) goto L_0x03fe;
    L_0x03f7:
        r0 = r11.f284l;
        r11.f284l = r7;
        r0.clearAnimation();
    L_0x03fe:
        r0 = r11.f284l;
        if (r0 == 0) goto L_0x0556;
    L_0x0402:
        r11.f285m = r12;
        r12 = r5;
        goto L_0x0045;
    L_0x0407:
        r0 = 5;
        if (r12 >= r0) goto L_0x0450;
    L_0x040a:
        r0 = f339a;
        if (r0 == 0) goto L_0x0422;
    L_0x040e:
        r0 = "FragmentManager";
        r1 = new java.lang.StringBuilder;
        r2 = "movefrom RESUMED: ";
        r1.<init>(r2);
        r1 = r1.append(r11);
        r1 = r1.toString();
        android.util.Log.v(r0, r1);
    L_0x0422:
        r0 = r11.f260D;
        if (r0 == 0) goto L_0x042b;
    L_0x0426:
        r0 = r11.f260D;
        r0.m274b(r9);
    L_0x042b:
        r11.f283k = r9;
        r11.f272P = r3;
        r11.f272P = r5;
        r0 = r11.f272P;
        if (r0 != 0) goto L_0x0450;
    L_0x0435:
        r0 = new android.support.v4.app.cu;
        r1 = new java.lang.StringBuilder;
        r2 = "Fragment ";
        r1.<init>(r2);
        r1 = r1.append(r11);
        r2 = " did not call through to super.onPause()";
        r1 = r1.append(r2);
        r1 = r1.toString();
        r0.<init>(r1);
        throw r0;
    L_0x0450:
        if (r12 >= r9) goto L_0x0499;
    L_0x0452:
        r0 = f339a;
        if (r0 == 0) goto L_0x046a;
    L_0x0456:
        r0 = "FragmentManager";
        r1 = new java.lang.StringBuilder;
        r2 = "movefrom STARTED: ";
        r1.<init>(r2);
        r1 = r1.append(r11);
        r1 = r1.toString();
        android.util.Log.v(r0, r1);
    L_0x046a:
        r0 = r11.f260D;
        if (r0 == 0) goto L_0x0473;
    L_0x046e:
        r0 = r11.f260D;
        r0.m291k();
    L_0x0473:
        r11.f283k = r6;
        r11.f272P = r3;
        r11.mo34d();
        r0 = r11.f272P;
        if (r0 != 0) goto L_0x0499;
    L_0x047e:
        r0 = new android.support.v4.app.cu;
        r1 = new java.lang.StringBuilder;
        r2 = "Fragment ";
        r1.<init>(r2);
        r1 = r1.append(r11);
        r2 = " did not call through to super.onStop()";
        r1 = r1.append(r2);
        r1 = r1.toString();
        r0.<init>(r1);
        throw r0;
    L_0x0499:
        if (r12 >= r6) goto L_0x04b6;
    L_0x049b:
        r0 = f339a;
        if (r0 == 0) goto L_0x04b3;
    L_0x049f:
        r0 = "FragmentManager";
        r1 = new java.lang.StringBuilder;
        r2 = "movefrom STOPPED: ";
        r1.<init>(r2);
        r1 = r1.append(r11);
        r1 = r1.toString();
        android.util.Log.v(r0, r1);
    L_0x04b3:
        r11.m189q();
    L_0x04b6:
        r0 = 2;
        if (r12 >= r0) goto L_0x03ed;
    L_0x04b9:
        r0 = f339a;
        if (r0 == 0) goto L_0x04d1;
    L_0x04bd:
        r0 = "FragmentManager";
        r1 = new java.lang.StringBuilder;
        r2 = "movefrom ACTIVITY_CREATED: ";
        r1.<init>(r2);
        r1 = r1.append(r11);
        r1 = r1.toString();
        android.util.Log.v(r0, r1);
    L_0x04d1:
        r0 = r11.f275S;
        if (r0 == 0) goto L_0x04e4;
    L_0x04d5:
        r0 = r10.f354o;
        r0 = r0.mo47b();
        if (r0 == 0) goto L_0x04e4;
    L_0x04dd:
        r0 = r11.f287o;
        if (r0 != 0) goto L_0x04e4;
    L_0x04e1:
        r10.m249c(r11);
    L_0x04e4:
        r0 = r11.f260D;
        if (r0 == 0) goto L_0x04ed;
    L_0x04e8:
        r0 = r11.f260D;
        r0.m274b(r5);
    L_0x04ed:
        r11.f283k = r5;
        r11.f272P = r3;
        r11.mo36e();
        r0 = r11.f272P;
        if (r0 != 0) goto L_0x0513;
    L_0x04f8:
        r0 = new android.support.v4.app.cu;
        r1 = new java.lang.StringBuilder;
        r2 = "Fragment ";
        r1.<init>(r2);
        r1 = r1.append(r11);
        r2 = " did not call through to super.onDestroyView()";
        r1 = r1.append(r2);
        r1 = r1.toString();
        r0.<init>(r1);
        throw r0;
    L_0x0513:
        r0 = r11.f279W;
        if (r0 == 0) goto L_0x051c;
    L_0x0517:
        r0 = r11.f279W;
        r0.m59e();
    L_0x051c:
        r0 = r11.f275S;
        if (r0 == 0) goto L_0x054e;
    L_0x0520:
        r0 = r11.f274R;
        if (r0 == 0) goto L_0x054e;
    L_0x0524:
        r0 = r10.f353n;
        if (r0 <= 0) goto L_0x063f;
    L_0x0528:
        r0 = r10.f359u;
        if (r0 != 0) goto L_0x063f;
    L_0x052c:
        r0 = r10.m242a(r11, r13, r3, r14);
    L_0x0530:
        if (r0 == 0) goto L_0x0547;
    L_0x0532:
        r1 = r11.f275S;
        r11.f284l = r1;
        r11.f285m = r12;
        r1 = r11.f275S;
        r2 = new android.support.v4.app.z;
        r2.<init>(r10, r1, r0, r11);
        r0.setAnimationListener(r2);
        r1 = r11.f275S;
        r1.startAnimation(r0);
    L_0x0547:
        r0 = r11.f274R;
        r1 = r11.f275S;
        r0.removeView(r1);
    L_0x054e:
        r11.f274R = r7;
        r11.f275S = r7;
        r11.f276T = r7;
        goto L_0x03ed;
    L_0x0556:
        r0 = f339a;
        if (r0 == 0) goto L_0x056e;
    L_0x055a:
        r0 = "FragmentManager";
        r1 = new java.lang.StringBuilder;
        r2 = "movefrom CREATED: ";
        r1.<init>(r2);
        r1 = r1.append(r11);
        r1 = r1.toString();
        android.util.Log.v(r0, r1);
    L_0x056e:
        r0 = r11.f269M;
        if (r0 != 0) goto L_0x0599;
    L_0x0572:
        r11.m190r();
    L_0x0575:
        r11.f272P = r3;
        r11.mo27a();
        r0 = r11.f272P;
        if (r0 != 0) goto L_0x059c;
    L_0x057e:
        r0 = new android.support.v4.app.cu;
        r1 = new java.lang.StringBuilder;
        r2 = "Fragment ";
        r1.<init>(r2);
        r1 = r1.append(r11);
        r2 = " did not call through to super.onDetach()";
        r1 = r1.append(r2);
        r1 = r1.toString();
        r0.<init>(r1);
        throw r0;
    L_0x0599:
        r11.f283k = r3;
        goto L_0x0575;
    L_0x059c:
        r0 = r11.f260D;
        if (r0 == 0) goto L_0x05c6;
    L_0x05a0:
        r0 = r11.f269M;
        if (r0 != 0) goto L_0x05bf;
    L_0x05a4:
        r0 = new java.lang.IllegalStateException;
        r1 = new java.lang.StringBuilder;
        r2 = "Child FragmentManager of ";
        r1.<init>(r2);
        r1 = r1.append(r11);
        r2 = " was not  destroyed and this fragment is not retaining instance";
        r1 = r1.append(r2);
        r1 = r1.toString();
        r0.<init>(r1);
        throw r0;
    L_0x05bf:
        r0 = r11.f260D;
        r0.m292l();
        r11.f260D = r7;
    L_0x05c6:
        if (r15 != 0) goto L_0x0045;
    L_0x05c8:
        r0 = r11.f269M;
        if (r0 != 0) goto L_0x0637;
    L_0x05cc:
        r0 = r11.f288p;
        if (r0 < 0) goto L_0x0045;
    L_0x05d0:
        r0 = f339a;
        if (r0 == 0) goto L_0x05e8;
    L_0x05d4:
        r0 = "FragmentManager";
        r1 = new java.lang.StringBuilder;
        r2 = "Freeing fragment index ";
        r1.<init>(r2);
        r1 = r1.append(r11);
        r1 = r1.toString();
        android.util.Log.v(r0, r1);
    L_0x05e8:
        r0 = r10.f345f;
        r1 = r11.f288p;
        r0.set(r1, r7);
        r0 = r10.f347h;
        if (r0 != 0) goto L_0x05fa;
    L_0x05f3:
        r0 = new java.util.ArrayList;
        r0.<init>();
        r10.f347h = r0;
    L_0x05fa:
        r0 = r10.f347h;
        r1 = r11.f288p;
        r1 = java.lang.Integer.valueOf(r1);
        r0.add(r1);
        r0 = r10.f354o;
        r1 = r11.f289q;
        r0.m212a(r1);
        r0 = -1;
        r11.f288p = r0;
        r11.f289q = r7;
        r11.f294v = r3;
        r11.f295w = r3;
        r11.f296x = r3;
        r11.f297y = r3;
        r11.f298z = r3;
        r11.f257A = r3;
        r11.f258B = r7;
        r11.f260D = r7;
        r11.f259C = r7;
        r11.f263G = r3;
        r11.f264H = r3;
        r11.f265I = r7;
        r11.f266J = r3;
        r11.f267K = r3;
        r11.f269M = r3;
        r11.f279W = r7;
        r11.f280X = r3;
        r11.f281Y = r3;
        goto L_0x0045;
    L_0x0637:
        r11.f259C = r7;
        r11.f262F = r7;
        r11.f258B = r7;
        goto L_0x0045;
    L_0x063f:
        r0 = r7;
        goto L_0x0530;
    L_0x0642:
        r0 = r7;
        goto L_0x0236;
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.v4.app.w.a(android.support.v4.app.l, int, int, int, boolean):void");
    }

    public final void m265a(C0013l c0013l, boolean z) {
        if (this.f346g == null) {
            this.f346g = new ArrayList();
        }
        if (f339a) {
            Log.v("FragmentManager", "add: " + c0013l);
        }
        m262a(c0013l);
        if (!c0013l.f267K) {
            if (this.f346g.contains(c0013l)) {
                throw new IllegalStateException("Fragment already added: " + c0013l);
            }
            this.f346g.add(c0013l);
            c0013l.f294v = true;
            c0013l.f295w = false;
            if (c0013l.f270N && c0013l.f271O) {
                this.f357s = true;
            }
            if (z) {
                m247b(c0013l);
            }
        }
    }

    public final void m266a(C0020u c0020u, C0015s c0015s, C0013l c0013l) {
        if (this.f354o != null) {
            throw new IllegalStateException("Already attached");
        }
        this.f354o = c0020u;
        this.f355p = c0015s;
        this.f356q = c0013l;
    }

    public final void m267a(Runnable runnable, boolean z) {
        if (!z) {
            m252o();
        }
        synchronized (this) {
            if (this.f359u || this.f354o == null) {
                throw new IllegalStateException("Activity has been destroyed");
            }
            if (this.f342c == null) {
                this.f342c = new ArrayList();
            }
            this.f342c.add(runnable);
            if (this.f342c.size() == 1) {
                this.f354o.f322d.removeCallbacks(this.f364z);
                this.f354o.f322d.post(this.f364z);
            }
        }
    }

    public final void mo55a(String str, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] strArr) {
        int size;
        int i;
        C0013l c0013l;
        int i2 = 0;
        String str2 = str + "    ";
        if (this.f345f != null) {
            size = this.f345f.size();
            if (size > 0) {
                printWriter.print(str);
                printWriter.print("Active Fragments in ");
                printWriter.print(Integer.toHexString(System.identityHashCode(this)));
                printWriter.println(":");
                for (i = 0; i < size; i++) {
                    c0013l = (C0013l) this.f345f.get(i);
                    printWriter.print(str);
                    printWriter.print("  #");
                    printWriter.print(i);
                    printWriter.print(": ");
                    printWriter.println(c0013l);
                    if (c0013l != null) {
                        printWriter.print(str2);
                        printWriter.print("mFragmentId=#");
                        printWriter.print(Integer.toHexString(c0013l.f263G));
                        printWriter.print(" mContainerId=#");
                        printWriter.print(Integer.toHexString(c0013l.f264H));
                        printWriter.print(" mTag=");
                        printWriter.println(c0013l.f265I);
                        printWriter.print(str2);
                        printWriter.print("mState=");
                        printWriter.print(c0013l.f283k);
                        printWriter.print(" mIndex=");
                        printWriter.print(c0013l.f288p);
                        printWriter.print(" mWho=");
                        printWriter.print(c0013l.f289q);
                        printWriter.print(" mBackStackNesting=");
                        printWriter.println(c0013l.f257A);
                        printWriter.print(str2);
                        printWriter.print("mAdded=");
                        printWriter.print(c0013l.f294v);
                        printWriter.print(" mRemoving=");
                        printWriter.print(c0013l.f295w);
                        printWriter.print(" mFromLayout=");
                        printWriter.print(c0013l.f296x);
                        printWriter.print(" mInLayout=");
                        printWriter.println(c0013l.f297y);
                        printWriter.print(str2);
                        printWriter.print("mHidden=");
                        printWriter.print(c0013l.f266J);
                        printWriter.print(" mDetached=");
                        printWriter.print(c0013l.f267K);
                        printWriter.print(" mMenuVisible=");
                        printWriter.print(c0013l.f271O);
                        printWriter.print(" mHasMenu=");
                        printWriter.println(c0013l.f270N);
                        printWriter.print(str2);
                        printWriter.print("mRetainInstance=");
                        printWriter.print(c0013l.f268L);
                        printWriter.print(" mRetaining=");
                        printWriter.print(c0013l.f269M);
                        printWriter.print(" mUserVisibleHint=");
                        printWriter.println(c0013l.f278V);
                        if (c0013l.f258B != null) {
                            printWriter.print(str2);
                            printWriter.print("mFragmentManager=");
                            printWriter.println(c0013l.f258B);
                        }
                        if (c0013l.f259C != null) {
                            printWriter.print(str2);
                            printWriter.print("mHost=");
                            printWriter.println(c0013l.f259C);
                        }
                        if (c0013l.f262F != null) {
                            printWriter.print(str2);
                            printWriter.print("mParentFragment=");
                            printWriter.println(c0013l.f262F);
                        }
                        if (c0013l.f290r != null) {
                            printWriter.print(str2);
                            printWriter.print("mArguments=");
                            printWriter.println(c0013l.f290r);
                        }
                        if (c0013l.f286n != null) {
                            printWriter.print(str2);
                            printWriter.print("mSavedFragmentState=");
                            printWriter.println(c0013l.f286n);
                        }
                        if (c0013l.f287o != null) {
                            printWriter.print(str2);
                            printWriter.print("mSavedViewState=");
                            printWriter.println(c0013l.f287o);
                        }
                        if (c0013l.f291s != null) {
                            printWriter.print(str2);
                            printWriter.print("mTarget=");
                            printWriter.print(c0013l.f291s);
                            printWriter.print(" mTargetRequestCode=");
                            printWriter.println(c0013l.f293u);
                        }
                        if (c0013l.f273Q != 0) {
                            printWriter.print(str2);
                            printWriter.print("mNextAnim=");
                            printWriter.println(c0013l.f273Q);
                        }
                        if (c0013l.f274R != null) {
                            printWriter.print(str2);
                            printWriter.print("mContainer=");
                            printWriter.println(c0013l.f274R);
                        }
                        if (c0013l.f275S != null) {
                            printWriter.print(str2);
                            printWriter.print("mView=");
                            printWriter.println(c0013l.f275S);
                        }
                        if (c0013l.f276T != null) {
                            printWriter.print(str2);
                            printWriter.print("mInnerView=");
                            printWriter.println(c0013l.f275S);
                        }
                        if (c0013l.f284l != null) {
                            printWriter.print(str2);
                            printWriter.print("mAnimatingAway=");
                            printWriter.println(c0013l.f284l);
                            printWriter.print(str2);
                            printWriter.print("mStateAfterAnimating=");
                            printWriter.println(c0013l.f285m);
                        }
                        if (c0013l.f279W != null) {
                            printWriter.print(str2);
                            printWriter.println("Loader Manager:");
                            c0013l.f279W.m54a(str2 + "  ", printWriter);
                        }
                        if (c0013l.f260D != null) {
                            printWriter.print(str2);
                            printWriter.println("Child " + c0013l.f260D + ":");
                            c0013l.f260D.mo55a(str2 + "  ", fileDescriptor, printWriter, strArr);
                        }
                    }
                }
            }
        }
        if (this.f346g != null) {
            size = this.f346g.size();
            if (size > 0) {
                printWriter.print(str);
                printWriter.println("Added Fragments:");
                for (i = 0; i < size; i++) {
                    c0013l = (C0013l) this.f346g.get(i);
                    printWriter.print(str);
                    printWriter.print("  #");
                    printWriter.print(i);
                    printWriter.print(": ");
                    printWriter.println(c0013l.toString());
                }
            }
        }
        if (this.f349j != null) {
            size = this.f349j.size();
            if (size > 0) {
                printWriter.print(str);
                printWriter.println("Fragments Created Menus:");
                for (i = 0; i < size; i++) {
                    c0013l = (C0013l) this.f349j.get(i);
                    printWriter.print(str);
                    printWriter.print("  #");
                    printWriter.print(i);
                    printWriter.print(": ");
                    printWriter.println(c0013l.toString());
                }
            }
        }
        if (this.f348i != null) {
            size = this.f348i.size();
            if (size > 0) {
                printWriter.print(str);
                printWriter.println("Back Stack:");
                for (i = 0; i < size; i++) {
                    C0003a c0003a = (C0003a) this.f348i.get(i);
                    printWriter.print(str);
                    printWriter.print("  #");
                    printWriter.print(i);
                    printWriter.print(": ");
                    printWriter.println(c0003a.toString());
                    c0003a.m32a(str2, printWriter);
                }
            }
        }
        synchronized (this) {
            if (this.f350k != null) {
                int size2 = this.f350k.size();
                if (size2 > 0) {
                    printWriter.print(str);
                    printWriter.println("Back Stack Indices:");
                    for (i = 0; i < size2; i++) {
                        c0003a = (C0003a) this.f350k.get(i);
                        printWriter.print(str);
                        printWriter.print("  #");
                        printWriter.print(i);
                        printWriter.print(": ");
                        printWriter.println(c0003a);
                    }
                }
            }
            if (this.f351l != null && this.f351l.size() > 0) {
                printWriter.print(str);
                printWriter.print("mAvailBackStackIndices: ");
                printWriter.println(Arrays.toString(this.f351l.toArray()));
            }
        }
        if (this.f342c != null) {
            i = this.f342c.size();
            if (i > 0) {
                printWriter.print(str);
                printWriter.println("Pending Actions:");
                while (i2 < i) {
                    Runnable runnable = (Runnable) this.f342c.get(i2);
                    printWriter.print(str);
                    printWriter.print("  #");
                    printWriter.print(i2);
                    printWriter.print(": ");
                    printWriter.println(runnable);
                    i2++;
                }
            }
        }
        printWriter.print(str);
        printWriter.println("FragmentManager misc state:");
        printWriter.print(str);
        printWriter.print("  mHost=");
        printWriter.println(this.f354o);
        printWriter.print(str);
        printWriter.print("  mContainer=");
        printWriter.println(this.f355p);
        if (this.f356q != null) {
            printWriter.print(str);
            printWriter.print("  mParent=");
            printWriter.println(this.f356q);
        }
        printWriter.print(str);
        printWriter.print("  mCurState=");
        printWriter.print(this.f353n);
        printWriter.print(" mStateSaved=");
        printWriter.print(this.f358t);
        printWriter.print(" mDestroyed=");
        printWriter.println(this.f359u);
        if (this.f357s) {
            printWriter.print(str);
            printWriter.print("  mNeedMenuInvalidate=");
            printWriter.println(this.f357s);
        }
        if (this.f360v != null) {
            printWriter.print(str);
            printWriter.print("  mNoTransactionsBecause=");
            printWriter.println(this.f360v);
        }
        if (this.f347h != null && this.f347h.size() > 0) {
            printWriter.print(str);
            printWriter.print("  mAvailIndices: ");
            printWriter.println(Arrays.toString(this.f347h.toArray()));
        }
    }

    public final void m269a(boolean z) {
        if (this.f346g != null) {
            for (int size = this.f346g.size() - 1; size >= 0; size--) {
                C0013l c0013l = (C0013l) this.f346g.get(size);
                if (!(c0013l == null || c0013l.f260D == null)) {
                    c0013l.f260D.m269a(z);
                }
            }
        }
    }

    final boolean m270a(int i, int i2) {
        if (this.f348i == null) {
            return false;
        }
        int i3;
        C0003a c0003a;
        if (i >= 0 || (i2 & 1) != 0) {
            int size;
            i3 = -1;
            if (i >= 0) {
                size = this.f348i.size() - 1;
                while (size >= 0) {
                    c0003a = (C0003a) this.f348i.get(size);
                    if (i >= 0 && i == c0003a.f49p) {
                        break;
                    }
                    size--;
                }
                if (size < 0) {
                    return false;
                }
                if ((i2 & 1) != 0) {
                    size--;
                    while (size >= 0) {
                        c0003a = (C0003a) this.f348i.get(size);
                        if (i < 0 || i != c0003a.f49p) {
                            break;
                        }
                        size--;
                    }
                }
                i3 = size;
            }
            if (i3 == this.f348i.size() - 1) {
                return false;
            }
            ArrayList arrayList = new ArrayList();
            for (size = this.f348i.size() - 1; size > i3; size--) {
                arrayList.add(this.f348i.remove(size));
            }
            int size2 = arrayList.size() - 1;
            SparseArray sparseArray = new SparseArray();
            SparseArray sparseArray2 = new SparseArray();
            if (this.f353n > 0) {
                for (size = 0; size <= size2; size++) {
                    ((C0003a) arrayList.get(size)).m31a(sparseArray, sparseArray2);
                }
            }
            C0008f c0008f = null;
            int i4 = 0;
            while (i4 <= size2) {
                if (f339a) {
                    Log.v("FragmentManager", "Popping back stack state: " + arrayList.get(i4));
                }
                i4++;
                c0008f = ((C0003a) arrayList.get(i4)).m28a(i4 == size2, c0008f, sparseArray, sparseArray2);
            }
        } else {
            i3 = this.f348i.size() - 1;
            if (i3 < 0) {
                return false;
            }
            c0003a = (C0003a) this.f348i.remove(i3);
            SparseArray sparseArray3 = new SparseArray();
            SparseArray sparseArray4 = new SparseArray();
            if (this.f353n > 0) {
                c0003a.m31a(sparseArray3, sparseArray4);
            }
            c0003a.m28a(true, null, sparseArray3, sparseArray4);
        }
        m282d();
        return true;
    }

    public final boolean m271a(Menu menu) {
        if (this.f346g == null) {
            return false;
        }
        boolean z = false;
        for (int i = 0; i < this.f346g.size(); i++) {
            C0013l c0013l = (C0013l) this.f346g.get(i);
            if (c0013l != null) {
                int i2;
                if (c0013l.f266J) {
                    i2 = 0;
                } else {
                    i2 = (c0013l.f270N && c0013l.f271O) ? 1 : 0;
                    if (c0013l.f260D != null) {
                        i2 |= c0013l.f260D.m271a(menu);
                    }
                }
                if (i2 != 0) {
                    z = true;
                }
            }
        }
        return z;
    }

    public final boolean m272a(Menu menu, MenuInflater menuInflater) {
        boolean z;
        int i = 0;
        ArrayList arrayList = null;
        if (this.f346g != null) {
            int i2 = 0;
            z = false;
            while (i2 < this.f346g.size()) {
                boolean z2;
                C0013l c0013l = (C0013l) this.f346g.get(i2);
                if (c0013l != null) {
                    int i3;
                    if (c0013l.f266J) {
                        i3 = 0;
                    } else {
                        i3 = (c0013l.f270N && c0013l.f271O) ? 1 : 0;
                        if (c0013l.f260D != null) {
                            i3 |= c0013l.f260D.m272a(menu, menuInflater);
                        }
                    }
                    if (i3 != 0) {
                        if (arrayList == null) {
                            arrayList = new ArrayList();
                        }
                        arrayList.add(c0013l);
                        z2 = true;
                        i2++;
                        z = z2;
                    }
                }
                z2 = z;
                i2++;
                z = z2;
            }
        } else {
            z = false;
        }
        if (this.f349j != null) {
            while (i < this.f349j.size()) {
                c0013l = (C0013l) this.f349j.get(i);
                if (arrayList == null || !arrayList.contains(c0013l)) {
                    C0013l.m172o();
                }
                i++;
            }
        }
        this.f349j = arrayList;
        return z;
    }

    public final boolean m273a(MenuItem menuItem) {
        if (this.f346g == null) {
            return false;
        }
        for (int i = 0; i < this.f346g.size(); i++) {
            C0013l c0013l = (C0013l) this.f346g.get(i);
            if (c0013l != null) {
                boolean z = (c0013l.f266J || c0013l.f260D == null || !c0013l.f260D.m273a(menuItem)) ? false : true;
                if (z) {
                    return true;
                }
            }
        }
        return false;
    }

    final void m274b(int i) {
        m259a(i, 0, 0, false);
    }

    public final void m275b(C0013l c0013l, int i, int i2) {
        if (f339a) {
            Log.v("FragmentManager", "hide: " + c0013l);
        }
        if (!c0013l.f266J) {
            c0013l.f266J = true;
            if (c0013l.f275S != null) {
                Animation a = m242a(c0013l, i, false, i2);
                if (a != null) {
                    C0025w.m244a(c0013l.f275S, a);
                    c0013l.f275S.startAnimation(a);
                }
                c0013l.f275S.setVisibility(8);
            }
            if (c0013l.f294v && c0013l.f270N && c0013l.f271O) {
                this.f357s = true;
            }
            C0013l.m166h();
        }
    }

    public final void m276b(Menu menu) {
        if (this.f346g != null) {
            for (int i = 0; i < this.f346g.size(); i++) {
                C0013l c0013l = (C0013l) this.f346g.get(i);
                if (!(c0013l == null || c0013l.f266J || c0013l.f260D == null)) {
                    c0013l.f260D.m276b(menu);
                }
            }
        }
    }

    public final void m277b(boolean z) {
        if (this.f346g != null) {
            for (int size = this.f346g.size() - 1; size >= 0; size--) {
                C0013l c0013l = (C0013l) this.f346g.get(size);
                if (!(c0013l == null || c0013l.f260D == null)) {
                    c0013l.f260D.m277b(z);
                }
            }
        }
    }

    public final boolean mo56b() {
        m252o();
        m281c();
        return m270a(-1, 0);
    }

    public final boolean m279b(MenuItem menuItem) {
        if (this.f346g == null) {
            return false;
        }
        for (int i = 0; i < this.f346g.size(); i++) {
            C0013l c0013l = (C0013l) this.f346g.get(i);
            if (c0013l != null) {
                boolean z = (c0013l.f266J || c0013l.f260D == null || !c0013l.f260D.m279b(menuItem)) ? false : true;
                if (z) {
                    return true;
                }
            }
        }
        return false;
    }

    public final void m280c(C0013l c0013l, int i, int i2) {
        if (f339a) {
            Log.v("FragmentManager", "show: " + c0013l);
        }
        if (c0013l.f266J) {
            c0013l.f266J = false;
            if (c0013l.f275S != null) {
                Animation a = m242a(c0013l, i, true, i2);
                if (a != null) {
                    C0025w.m244a(c0013l.f275S, a);
                    c0013l.f275S.startAnimation(a);
                }
                c0013l.f275S.setVisibility(0);
            }
            if (c0013l.f294v && c0013l.f270N && c0013l.f271O) {
                this.f357s = true;
            }
            C0013l.m166h();
        }
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final boolean m281c() {
        /*
        r6 = this;
        r2 = 1;
        r1 = 0;
        r0 = r6.f344e;
        if (r0 == 0) goto L_0x000e;
    L_0x0006:
        r0 = new java.lang.IllegalStateException;
        r1 = "FragmentManager is already executing transactions";
        r0.<init>(r1);
        throw r0;
    L_0x000e:
        r0 = android.os.Looper.myLooper();
        r3 = r6.f354o;
        r3 = r3.f322d;
        r3 = r3.getLooper();
        if (r0 == r3) goto L_0x0024;
    L_0x001c:
        r0 = new java.lang.IllegalStateException;
        r1 = "Must be called from main thread of fragment host";
        r0.<init>(r1);
        throw r0;
    L_0x0024:
        r0 = r1;
    L_0x0025:
        monitor-enter(r6);
        r3 = r6.f342c;	 Catch:{ all -> 0x0074 }
        if (r3 == 0) goto L_0x0032;
    L_0x002a:
        r3 = r6.f342c;	 Catch:{ all -> 0x0074 }
        r3 = r3.size();	 Catch:{ all -> 0x0074 }
        if (r3 != 0) goto L_0x0037;
    L_0x0032:
        monitor-exit(r6);	 Catch:{ all -> 0x0074 }
        r6.m253p();
        return r0;
    L_0x0037:
        r0 = r6.f342c;	 Catch:{ all -> 0x0074 }
        r3 = r0.size();	 Catch:{ all -> 0x0074 }
        r0 = r6.f343d;	 Catch:{ all -> 0x0074 }
        if (r0 == 0) goto L_0x0046;
    L_0x0041:
        r0 = r6.f343d;	 Catch:{ all -> 0x0074 }
        r0 = r0.length;	 Catch:{ all -> 0x0074 }
        if (r0 >= r3) goto L_0x004a;
    L_0x0046:
        r0 = new java.lang.Runnable[r3];	 Catch:{ all -> 0x0074 }
        r6.f343d = r0;	 Catch:{ all -> 0x0074 }
    L_0x004a:
        r0 = r6.f342c;	 Catch:{ all -> 0x0074 }
        r4 = r6.f343d;	 Catch:{ all -> 0x0074 }
        r0.toArray(r4);	 Catch:{ all -> 0x0074 }
        r0 = r6.f342c;	 Catch:{ all -> 0x0074 }
        r0.clear();	 Catch:{ all -> 0x0074 }
        r0 = r6.f354o;	 Catch:{ all -> 0x0074 }
        r0 = r0.f322d;	 Catch:{ all -> 0x0074 }
        r4 = r6.f364z;	 Catch:{ all -> 0x0074 }
        r0.removeCallbacks(r4);	 Catch:{ all -> 0x0074 }
        monitor-exit(r6);	 Catch:{ all -> 0x0074 }
        r6.f344e = r2;
        r0 = r1;
    L_0x0063:
        if (r0 >= r3) goto L_0x0077;
    L_0x0065:
        r4 = r6.f343d;
        r4 = r4[r0];
        r4.run();
        r4 = r6.f343d;
        r5 = 0;
        r4[r0] = r5;
        r0 = r0 + 1;
        goto L_0x0063;
    L_0x0074:
        r0 = move-exception;
        monitor-exit(r6);	 Catch:{ all -> 0x0074 }
        throw r0;
    L_0x0077:
        r6.f344e = r1;
        r0 = r2;
        goto L_0x0025;
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.v4.app.w.c():boolean");
    }

    final void m282d() {
        if (this.f352m != null) {
            for (int i = 0; i < this.f352m.size(); i++) {
                this.f352m.get(i);
            }
        }
    }

    public final void m283d(C0013l c0013l, int i, int i2) {
        if (f339a) {
            Log.v("FragmentManager", "detach: " + c0013l);
        }
        if (!c0013l.f267K) {
            c0013l.f267K = true;
            if (c0013l.f294v) {
                if (this.f346g != null) {
                    if (f339a) {
                        Log.v("FragmentManager", "remove from detach: " + c0013l);
                    }
                    this.f346g.remove(c0013l);
                }
                if (c0013l.f270N && c0013l.f271O) {
                    this.f357s = true;
                }
                c0013l.f294v = false;
                m264a(c0013l, 1, i, i2, false);
            }
        }
    }

    final ad m284e() {
        List list;
        List list2;
        if (this.f345f != null) {
            int i = 0;
            list = null;
            list2 = null;
            while (i < this.f345f.size()) {
                ArrayList arrayList;
                C0013l c0013l = (C0013l) this.f345f.get(i);
                if (c0013l != null) {
                    boolean z;
                    if (c0013l.f268L) {
                        if (list2 == null) {
                            arrayList = new ArrayList();
                        }
                        arrayList.add(c0013l);
                        c0013l.f269M = true;
                        c0013l.f292t = c0013l.f291s != null ? c0013l.f291s.f288p : -1;
                        if (f339a) {
                            Log.v("FragmentManager", "retainNonConfig: keeping retained " + c0013l);
                        }
                    }
                    if (c0013l.f260D != null) {
                        ad e = c0013l.f260D.m284e();
                        if (e != null) {
                            ArrayList arrayList2;
                            if (list == null) {
                                arrayList2 = new ArrayList();
                                for (int i2 = 0; i2 < i; i2++) {
                                    arrayList2.add(null);
                                }
                            } else {
                                arrayList2 = list;
                            }
                            arrayList2.add(e);
                            list = arrayList2;
                            z = true;
                            if (!(list == null || r0)) {
                                list.add(null);
                            }
                        }
                    }
                    z = false;
                    list.add(null);
                }
                i++;
                Object obj = arrayList;
            }
        } else {
            list = null;
            list2 = null;
        }
        return (list2 == null && list == null) ? null : new ad(list2, list);
    }

    public final void m285e(C0013l c0013l, int i, int i2) {
        if (f339a) {
            Log.v("FragmentManager", "attach: " + c0013l);
        }
        if (c0013l.f267K) {
            c0013l.f267K = false;
            if (!c0013l.f294v) {
                if (this.f346g == null) {
                    this.f346g = new ArrayList();
                }
                if (this.f346g.contains(c0013l)) {
                    throw new IllegalStateException("Fragment already added: " + c0013l);
                }
                if (f339a) {
                    Log.v("FragmentManager", "add from attach: " + c0013l);
                }
                this.f346g.add(c0013l);
                c0013l.f294v = true;
                if (c0013l.f270N && c0013l.f271O) {
                    this.f357s = true;
                }
                m264a(c0013l, this.f353n, i, i2, false);
            }
        }
    }

    final Parcelable m286f() {
        BackStackState[] backStackStateArr = null;
        m281c();
        if (f340b) {
            this.f358t = true;
        }
        if (this.f345f == null || this.f345f.size() <= 0) {
            return null;
        }
        int size = this.f345f.size();
        FragmentState[] fragmentStateArr = new FragmentState[size];
        int i = 0;
        boolean z = false;
        while (i < size) {
            boolean z2;
            C0013l c0013l = (C0013l) this.f345f.get(i);
            if (c0013l != null) {
                if (c0013l.f288p < 0) {
                    m245a(new IllegalStateException("Failure saving state: active " + c0013l + " has cleared index: " + c0013l.f288p));
                }
                FragmentState fragmentState = new FragmentState(c0013l);
                fragmentStateArr[i] = fragmentState;
                if (c0013l.f283k <= 0 || fragmentState.f32k != null) {
                    fragmentState.f32k = c0013l.f286n;
                } else {
                    Bundle bundle;
                    if (this.f362x == null) {
                        this.f362x = new Bundle();
                    }
                    c0013l.m185f(this.f362x);
                    if (this.f362x.isEmpty()) {
                        bundle = null;
                    } else {
                        bundle = this.f362x;
                        this.f362x = null;
                    }
                    if (c0013l.f275S != null) {
                        m249c(c0013l);
                    }
                    if (c0013l.f287o != null) {
                        if (bundle == null) {
                            bundle = new Bundle();
                        }
                        bundle.putSparseParcelableArray("android:view_state", c0013l.f287o);
                    }
                    if (!c0013l.f278V) {
                        if (bundle == null) {
                            bundle = new Bundle();
                        }
                        bundle.putBoolean("android:user_visible_hint", c0013l.f278V);
                    }
                    fragmentState.f32k = bundle;
                    if (c0013l.f291s != null) {
                        if (c0013l.f291s.f288p < 0) {
                            m245a(new IllegalStateException("Failure saving state: " + c0013l + " has target not in fragment manager: " + c0013l.f291s));
                        }
                        if (fragmentState.f32k == null) {
                            fragmentState.f32k = new Bundle();
                        }
                        bundle = fragmentState.f32k;
                        String str = "android:target_state";
                        C0013l c0013l2 = c0013l.f291s;
                        if (c0013l2.f288p < 0) {
                            m245a(new IllegalStateException("Fragment " + c0013l2 + " is not currently in the FragmentManager"));
                        }
                        bundle.putInt(str, c0013l2.f288p);
                        if (c0013l.f293u != 0) {
                            fragmentState.f32k.putInt("android:target_req_state", c0013l.f293u);
                        }
                    }
                }
                if (f339a) {
                    Log.v("FragmentManager", "Saved state of " + c0013l + ": " + fragmentState.f32k);
                }
                z2 = true;
            } else {
                z2 = z;
            }
            i++;
            z = z2;
        }
        if (z) {
            int[] iArr;
            int i2;
            FragmentManagerState fragmentManagerState;
            if (this.f346g != null) {
                i = this.f346g.size();
                if (i > 0) {
                    iArr = new int[i];
                    for (i2 = 0; i2 < i; i2++) {
                        iArr[i2] = ((C0013l) this.f346g.get(i2)).f288p;
                        if (iArr[i2] < 0) {
                            m245a(new IllegalStateException("Failure saving state: active " + this.f346g.get(i2) + " has cleared index: " + iArr[i2]));
                        }
                        if (f339a) {
                            Log.v("FragmentManager", "saveAllState: adding fragment #" + i2 + ": " + this.f346g.get(i2));
                        }
                    }
                    if (this.f348i != null) {
                        i = this.f348i.size();
                        if (i > 0) {
                            backStackStateArr = new BackStackState[i];
                            for (i2 = 0; i2 < i; i2++) {
                                backStackStateArr[i2] = new BackStackState((C0003a) this.f348i.get(i2));
                                if (f339a) {
                                    Log.v("FragmentManager", "saveAllState: adding back stack #" + i2 + ": " + this.f348i.get(i2));
                                }
                            }
                        }
                    }
                    fragmentManagerState = new FragmentManagerState();
                    fragmentManagerState.f19a = fragmentStateArr;
                    fragmentManagerState.f20b = iArr;
                    fragmentManagerState.f21c = backStackStateArr;
                    return fragmentManagerState;
                }
            }
            iArr = null;
            if (this.f348i != null) {
                i = this.f348i.size();
                if (i > 0) {
                    backStackStateArr = new BackStackState[i];
                    for (i2 = 0; i2 < i; i2++) {
                        backStackStateArr[i2] = new BackStackState((C0003a) this.f348i.get(i2));
                        if (f339a) {
                            Log.v("FragmentManager", "saveAllState: adding back stack #" + i2 + ": " + this.f348i.get(i2));
                        }
                    }
                }
            }
            fragmentManagerState = new FragmentManagerState();
            fragmentManagerState.f19a = fragmentStateArr;
            fragmentManagerState.f20b = iArr;
            fragmentManagerState.f21c = backStackStateArr;
            return fragmentManagerState;
        } else if (!f339a) {
            return null;
        } else {
            Log.v("FragmentManager", "saveAllState: no fragments!");
            return null;
        }
    }

    public final void m287g() {
        this.f358t = false;
        m274b(1);
    }

    public final void m288h() {
        this.f358t = false;
        m274b(2);
    }

    public final void m289i() {
        this.f358t = false;
        m274b(4);
    }

    public final void m290j() {
        this.f358t = false;
        m274b(5);
    }

    public final void m291k() {
        this.f358t = true;
        m274b(3);
    }

    public final void m292l() {
        this.f359u = true;
        m281c();
        m274b(0);
        this.f354o = null;
        this.f355p = null;
        this.f356q = null;
    }

    public final void m293m() {
        if (this.f346g != null) {
            for (int i = 0; i < this.f346g.size(); i++) {
                C0013l c0013l = (C0013l) this.f346g.get(i);
                if (c0013l != null) {
                    c0013l.onLowMemory();
                    if (c0013l.f260D != null) {
                        c0013l.f260D.m293m();
                    }
                }
            }
        }
    }

    public final String toString() {
        StringBuilder stringBuilder = new StringBuilder(128);
        stringBuilder.append("FragmentManager{");
        stringBuilder.append(Integer.toHexString(System.identityHashCode(this)));
        stringBuilder.append(" in ");
        if (this.f356q != null) {
            C0039d.m334a(this.f356q, stringBuilder);
        } else {
            C0039d.m334a(this.f354o, stringBuilder);
        }
        stringBuilder.append("}}");
        return stringBuilder.toString();
    }
}
