package android.support.v4.app;

import android.app.Notification;
import android.app.Notification.Action;
import android.app.Notification.Action.Builder;
import android.app.RemoteInput;
import android.os.Bundle;

final class bs {
    static Action m116a(bz bzVar) {
        Builder addExtras = new Builder(bzVar.mo6a(), bzVar.mo7b(), bzVar.mo8c()).addExtras(bzVar.mo9d());
        cq[] f = bzVar.mo11f();
        if (f != null) {
            for (RemoteInput addRemoteInput : co.m158a(f)) {
                addExtras.addRemoteInput(addRemoteInput);
            }
        }
        return addExtras.build();
    }

    public static void m117a(Notification.Builder builder, bz bzVar) {
        Builder builder2 = new Builder(bzVar.mo6a(), bzVar.mo7b(), bzVar.mo8c());
        if (bzVar.mo11f() != null) {
            for (RemoteInput addRemoteInput : co.m158a(bzVar.mo11f())) {
                builder2.addRemoteInput(addRemoteInput);
            }
        }
        Bundle bundle = bzVar.mo9d() != null ? new Bundle(bzVar.mo9d()) : new Bundle();
        bundle.putBoolean("android.support.allowGeneratedReplies", bzVar.mo10e());
        builder2.addExtras(bundle);
        builder.addAction(builder2.build());
    }
}
