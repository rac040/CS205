package android.support.v4.app;

final class C0027y implements Runnable {
    final /* synthetic */ int f366a;
    final /* synthetic */ int f367b = 1;
    final /* synthetic */ C0025w f368c;

    C0027y(C0025w c0025w, int i) {
        this.f368c = c0025w;
        this.f366a = i;
    }

    public final void run() {
        C0025w c0025w = this.f368c;
        C0020u c0020u = this.f368c.f354o;
        c0025w.m270a(this.f366a, this.f367b);
    }
}
