package android.support.v4.app;

import android.os.Bundle;

public abstract class cq {
    protected abstract String mo21a();

    protected abstract CharSequence mo22b();

    protected abstract CharSequence[] mo23c();

    protected abstract boolean mo24d();

    protected abstract Bundle mo25e();
}
