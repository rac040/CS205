package android.support.v4.app;

import android.support.v4.p002c.C0035a;
import android.view.View;
import android.view.ViewTreeObserver.OnPreDrawListener;
import java.util.ArrayList;
import java.util.Map;

final class C0005c implements OnPreDrawListener {
    final /* synthetic */ View f196a;
    final /* synthetic */ Object f197b;
    final /* synthetic */ ArrayList f198c;
    final /* synthetic */ C0008f f199d;
    final /* synthetic */ Object f200e;
    final /* synthetic */ Object f201f;
    final /* synthetic */ boolean f202g;
    final /* synthetic */ C0013l f203h;
    final /* synthetic */ C0013l f204i;
    final /* synthetic */ C0003a f205j;

    C0005c(C0003a c0003a, View view, Object obj, ArrayList arrayList, C0008f c0008f, Object obj2, Object obj3, boolean z, C0013l c0013l, C0013l c0013l2) {
        this.f205j = c0003a;
        this.f196a = view;
        this.f197b = obj;
        this.f198c = arrayList;
        this.f199d = c0008f;
        this.f200e = obj2;
        this.f201f = obj3;
        this.f202g = z;
        this.f203h = c0013l;
        this.f204i = c0013l2;
    }

    public final boolean onPreDraw() {
        this.f196a.getViewTreeObserver().removeOnPreDrawListener(this);
        ah.m43a(this.f197b, this.f198c);
        this.f198c.remove(this.f199d.f251d);
        ah.m42a(this.f200e, this.f201f, this.f197b, this.f198c, false);
        this.f198c.clear();
        C0035a a = C0003a.m9a(this.f205j, this.f199d, this.f202g, this.f203h);
        ah.m40a(this.f197b, this.f199d.f251d, (Map) a, this.f198c);
        C0003a.m14a(this.f205j, a, this.f199d);
        C0003a.m18a(this.f203h, this.f204i, this.f202g, a);
        ah.m42a(this.f200e, this.f201f, this.f197b, this.f198c, true);
        return true;
    }
}
