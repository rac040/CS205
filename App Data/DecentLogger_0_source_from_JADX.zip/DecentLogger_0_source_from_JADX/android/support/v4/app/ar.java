package android.support.v4.app;

import android.os.Bundle;
import android.support.v4.p000a.C0000a;
import android.support.v4.p000a.C0001b;
import android.support.v4.p000a.C0002c;
import android.support.v4.p002c.C0039d;
import android.util.Log;
import java.io.PrintWriter;

final class ar implements C0001b, C0002c {
    final int f93a;
    final Bundle f94b;
    ap f95c;
    C0000a f96d;
    boolean f97e;
    boolean f98f;
    Object f99g;
    boolean f100h;
    boolean f101i;
    boolean f102j;
    boolean f103k;
    boolean f104l;
    boolean f105m;
    ar f106n;
    final /* synthetic */ aq f107o;

    final void m62a() {
        if (aq.f86a) {
            Log.v("LoaderManager", "  Stopping: " + this);
        }
        this.f100h = false;
        if (!this.f101i && this.f96d != null && this.f105m) {
            this.f105m = false;
            this.f96d.m1a((C0002c) this);
            this.f96d.m0a((C0001b) this);
            this.f96d.f3d = false;
        }
    }

    final void m63a(C0000a c0000a, Object obj) {
        if (this.f95c != null) {
            String str;
            if (this.f107o.f92g != null) {
                String str2 = this.f107o.f92g.f324f.f360v;
                this.f107o.f92g.f324f.f360v = "onLoadFinished";
                str = str2;
            } else {
                str = null;
            }
            try {
                if (aq.f86a) {
                    StringBuilder append = new StringBuilder("  onLoadFinished in ").append(c0000a).append(": ");
                    StringBuilder stringBuilder = new StringBuilder(64);
                    C0039d.m334a(obj, stringBuilder);
                    stringBuilder.append("}");
                    Log.v("LoaderManager", append.append(stringBuilder.toString()).toString());
                }
                if (this.f107o.f92g != null) {
                    this.f107o.f92g.f324f.f360v = str;
                }
                this.f98f = true;
            } catch (Throwable th) {
                if (this.f107o.f92g != null) {
                    this.f107o.f92g.f324f.f360v = str;
                }
            }
        }
    }

    public final void m64a(String str, PrintWriter printWriter) {
        while (true) {
            printWriter.print(str);
            printWriter.print("mId=");
            printWriter.print(this.f93a);
            printWriter.print(" mArgs=");
            printWriter.println(this.f94b);
            printWriter.print(str);
            printWriter.print("mCallbacks=");
            printWriter.println(this.f95c);
            printWriter.print(str);
            printWriter.print("mLoader=");
            printWriter.println(this.f96d);
            if (this.f96d != null) {
                C0000a c0000a = this.f96d;
                String str2 = str + "  ";
                printWriter.print(str2);
                printWriter.print("mId=");
                printWriter.print(c0000a.f0a);
                printWriter.print(" mListener=");
                printWriter.println(c0000a.f1b);
                if (c0000a.f3d || c0000a.f6g || c0000a.f7h) {
                    printWriter.print(str2);
                    printWriter.print("mStarted=");
                    printWriter.print(c0000a.f3d);
                    printWriter.print(" mContentChanged=");
                    printWriter.print(c0000a.f6g);
                    printWriter.print(" mProcessingChange=");
                    printWriter.println(c0000a.f7h);
                }
                if (c0000a.f4e || c0000a.f5f) {
                    printWriter.print(str2);
                    printWriter.print("mAbandoned=");
                    printWriter.print(c0000a.f4e);
                    printWriter.print(" mReset=");
                    printWriter.println(c0000a.f5f);
                }
            }
            if (this.f97e || this.f98f) {
                printWriter.print(str);
                printWriter.print("mHaveData=");
                printWriter.print(this.f97e);
                printWriter.print("  mDeliveredData=");
                printWriter.println(this.f98f);
                printWriter.print(str);
                printWriter.print("mData=");
                printWriter.println(this.f99g);
            }
            printWriter.print(str);
            printWriter.print("mStarted=");
            printWriter.print(this.f100h);
            printWriter.print(" mReportNextStart=");
            printWriter.print(this.f103k);
            printWriter.print(" mDestroyed=");
            printWriter.println(this.f104l);
            printWriter.print(str);
            printWriter.print("mRetaining=");
            printWriter.print(this.f101i);
            printWriter.print(" mRetainingStarted=");
            printWriter.print(this.f102j);
            printWriter.print(" mListenerRegistered=");
            printWriter.println(this.f105m);
            if (this.f106n != null) {
                printWriter.print(str);
                printWriter.println("Pending Loader ");
                printWriter.print(this.f106n);
                printWriter.println(":");
                this = this.f106n;
                str = str + "  ";
            } else {
                return;
            }
        }
    }

    final void m65b() {
        while (true) {
            C0001b c0001b;
            if (aq.f86a) {
                Log.v("LoaderManager", "  Destroying: " + c0001b);
            }
            c0001b.f104l = true;
            boolean z = c0001b.f98f;
            c0001b.f98f = false;
            if (c0001b.f95c != null && c0001b.f96d != null && c0001b.f97e && z) {
                String str;
                if (aq.f86a) {
                    Log.v("LoaderManager", "  Resetting: " + c0001b);
                }
                if (c0001b.f107o.f92g != null) {
                    str = c0001b.f107o.f92g.f324f.f360v;
                    c0001b.f107o.f92g.f324f.f360v = "onLoaderReset";
                } else {
                    str = null;
                }
                if (c0001b.f107o.f92g != null) {
                    c0001b.f107o.f92g.f324f.f360v = str;
                }
            }
            c0001b.f95c = null;
            c0001b.f99g = null;
            c0001b.f97e = false;
            if (c0001b.f96d != null) {
                if (c0001b.f105m) {
                    c0001b.f105m = false;
                    c0001b.f96d.m1a((C0002c) c0001b);
                    c0001b.f96d.m0a(c0001b);
                }
                C0000a c0000a = c0001b.f96d;
                c0000a.f5f = true;
                c0000a.f3d = false;
                c0000a.f4e = false;
                c0000a.f6g = false;
                c0000a.f7h = false;
            }
            if (c0001b.f106n != null) {
                c0001b = c0001b.f106n;
            } else {
                return;
            }
        }
    }

    public final String toString() {
        StringBuilder stringBuilder = new StringBuilder(64);
        stringBuilder.append("LoaderInfo{");
        stringBuilder.append(Integer.toHexString(System.identityHashCode(this)));
        stringBuilder.append(" #");
        stringBuilder.append(this.f93a);
        stringBuilder.append(" : ");
        C0039d.m334a(this.f96d, stringBuilder);
        stringBuilder.append("}}");
        return stringBuilder.toString();
    }
}
