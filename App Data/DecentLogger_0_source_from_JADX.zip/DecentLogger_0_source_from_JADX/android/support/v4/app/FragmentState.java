package android.support.v4.app;

import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;

final class FragmentState implements Parcelable {
    public static final Creator CREATOR = new af();
    final String f22a;
    final int f23b;
    final boolean f24c;
    final int f25d;
    final int f26e;
    final String f27f;
    final boolean f28g;
    final boolean f29h;
    final Bundle f30i;
    final boolean f31j;
    Bundle f32k;
    C0013l f33l;

    public FragmentState(Parcel parcel) {
        boolean z = true;
        this.f22a = parcel.readString();
        this.f23b = parcel.readInt();
        this.f24c = parcel.readInt() != 0;
        this.f25d = parcel.readInt();
        this.f26e = parcel.readInt();
        this.f27f = parcel.readString();
        this.f28g = parcel.readInt() != 0;
        this.f29h = parcel.readInt() != 0;
        this.f30i = parcel.readBundle();
        if (parcel.readInt() == 0) {
            z = false;
        }
        this.f31j = z;
        this.f32k = parcel.readBundle();
    }

    public FragmentState(C0013l c0013l) {
        this.f22a = c0013l.getClass().getName();
        this.f23b = c0013l.f288p;
        this.f24c = c0013l.f296x;
        this.f25d = c0013l.f263G;
        this.f26e = c0013l.f264H;
        this.f27f = c0013l.f265I;
        this.f28g = c0013l.f268L;
        this.f29h = c0013l.f267K;
        this.f30i = c0013l.f290r;
        this.f31j = c0013l.f266J;
    }

    public final int describeContents() {
        return 0;
    }

    public final void writeToParcel(Parcel parcel, int i) {
        int i2 = 1;
        parcel.writeString(this.f22a);
        parcel.writeInt(this.f23b);
        parcel.writeInt(this.f24c ? 1 : 0);
        parcel.writeInt(this.f25d);
        parcel.writeInt(this.f26e);
        parcel.writeString(this.f27f);
        parcel.writeInt(this.f28g ? 1 : 0);
        parcel.writeInt(this.f29h ? 1 : 0);
        parcel.writeBundle(this.f30i);
        if (!this.f31j) {
            i2 = 0;
        }
        parcel.writeInt(i2);
        parcel.writeBundle(this.f32k);
    }
}
