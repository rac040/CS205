package android.support.v4.app;

import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;

final class FragmentManagerState implements Parcelable {
    public static final Creator CREATOR = new ae();
    FragmentState[] f19a;
    int[] f20b;
    BackStackState[] f21c;

    public FragmentManagerState(Parcel parcel) {
        this.f19a = (FragmentState[]) parcel.createTypedArray(FragmentState.CREATOR);
        this.f20b = parcel.createIntArray();
        this.f21c = (BackStackState[]) parcel.createTypedArray(BackStackState.CREATOR);
    }

    public final int describeContents() {
        return 0;
    }

    public final void writeToParcel(Parcel parcel, int i) {
        parcel.writeTypedArray(this.f19a, i);
        parcel.writeIntArray(this.f20b);
        parcel.writeTypedArray(this.f21c, i);
    }
}
