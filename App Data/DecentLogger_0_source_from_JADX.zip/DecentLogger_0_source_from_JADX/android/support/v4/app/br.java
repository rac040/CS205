package android.support.v4.app;

import android.app.Notification;
import android.app.PendingIntent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.os.Parcelable;
import java.util.ArrayList;

public final class br implements bd {
    public int f173a;
    public int f174b = 8388613;
    private ArrayList f175c = new ArrayList();
    private int f176d = 1;
    private PendingIntent f177e;
    private ArrayList f178f = new ArrayList();
    private Bitmap f179g;
    private int f180h = -1;
    private int f181i = 0;
    private int f182j;
    private int f183k = 80;
    private int f184l;
    private String f185m;

    public final bb mo17a(bb bbVar) {
        Bundle bundle = new Bundle();
        if (!this.f175c.isEmpty()) {
            bundle.putParcelableArrayList("actions", av.f108a.mo15a((aw[]) this.f175c.toArray(new aw[this.f175c.size()])));
        }
        if (this.f176d != 1) {
            bundle.putInt("flags", this.f176d);
        }
        if (this.f177e != null) {
            bundle.putParcelable("displayIntent", this.f177e);
        }
        if (!this.f178f.isEmpty()) {
            bundle.putParcelableArray("pages", (Parcelable[]) this.f178f.toArray(new Notification[this.f178f.size()]));
        }
        if (this.f179g != null) {
            bundle.putParcelable("background", this.f179g);
        }
        if (this.f173a != 0) {
            bundle.putInt("contentIcon", this.f173a);
        }
        if (this.f174b != 8388613) {
            bundle.putInt("contentIconGravity", this.f174b);
        }
        if (this.f180h != -1) {
            bundle.putInt("contentActionIndex", this.f180h);
        }
        if (this.f181i != 0) {
            bundle.putInt("customSizePreset", this.f181i);
        }
        if (this.f182j != 0) {
            bundle.putInt("customContentHeight", this.f182j);
        }
        if (this.f183k != 80) {
            bundle.putInt("gravity", this.f183k);
        }
        if (this.f184l != 0) {
            bundle.putInt("hintScreenTimeout", this.f184l);
        }
        if (this.f185m != null) {
            bundle.putString("dismissalId", this.f185m);
        }
        if (bbVar.f162y == null) {
            bbVar.f162y = new Bundle();
        }
        bbVar.f162y.putBundle("android.wearable.EXTENSIONS", bundle);
        return bbVar;
    }

    public final void m115a(int i, boolean z) {
        if (z) {
            this.f176d |= i;
        } else {
            this.f176d &= i ^ -1;
        }
    }

    public final /* synthetic */ Object clone() {
        br brVar = new br();
        brVar.f175c = new ArrayList(this.f175c);
        brVar.f176d = this.f176d;
        brVar.f177e = this.f177e;
        brVar.f178f = new ArrayList(this.f178f);
        brVar.f179g = this.f179g;
        brVar.f173a = this.f173a;
        brVar.f174b = this.f174b;
        brVar.f180h = this.f180h;
        brVar.f181i = this.f181i;
        brVar.f182j = this.f182j;
        brVar.f183k = this.f183k;
        brVar.f184l = this.f184l;
        brVar.f185m = this.f185m;
        return brVar;
    }
}
