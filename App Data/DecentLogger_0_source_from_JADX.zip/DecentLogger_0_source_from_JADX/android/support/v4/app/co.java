package android.support.v4.app;

import android.app.RemoteInput;
import android.app.RemoteInput.Builder;

final class co {
    static RemoteInput[] m158a(cq[] cqVarArr) {
        if (cqVarArr == null) {
            return null;
        }
        RemoteInput[] remoteInputArr = new RemoteInput[cqVarArr.length];
        for (int i = 0; i < cqVarArr.length; i++) {
            cq cqVar = cqVarArr[i];
            remoteInputArr[i] = new Builder(cqVar.mo21a()).setLabel(cqVar.mo22b()).setChoices(cqVar.mo23c()).setAllowFreeFormInput(cqVar.mo24d()).addExtras(cqVar.mo25e()).build();
        }
        return remoteInputArr;
    }
}
