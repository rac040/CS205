package android.support.v4.app;

import android.util.AndroidRuntimeException;

final class cu extends AndroidRuntimeException {
    public cu(String str) {
        super(str);
    }
}
