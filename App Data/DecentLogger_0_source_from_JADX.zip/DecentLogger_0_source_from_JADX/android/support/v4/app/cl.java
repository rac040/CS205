package android.support.v4.app;

import android.app.RemoteInput;
import android.content.Intent;
import android.os.Bundle;

final class cl implements ck {
    cl() {
    }

    public final Bundle mo26a(Intent intent) {
        return RemoteInput.getResultsFromIntent(intent);
    }
}
