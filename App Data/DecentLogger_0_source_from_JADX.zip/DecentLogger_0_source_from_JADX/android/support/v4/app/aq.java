package android.support.v4.app;

import android.support.v4.p000a.C0000a;
import android.support.v4.p002c.C0039d;
import android.support.v4.p002c.C0046m;
import android.util.Log;
import java.io.PrintWriter;
import java.lang.reflect.Modifier;

final class aq extends ao {
    static boolean f86a = false;
    final C0046m f87b;
    final C0046m f88c;
    final String f89d;
    boolean f90e;
    boolean f91f;
    C0020u f92g;

    public final void m54a(String str, PrintWriter printWriter) {
        int i = 0;
        if (this.f87b.m339b() > 0) {
            printWriter.print(str);
            printWriter.println("Active Loaders:");
            String str2 = str + "    ";
            for (int i2 = 0; i2 < this.f87b.m339b(); i2++) {
                ar arVar = (ar) this.f87b.m343d(i2);
                printWriter.print(str);
                printWriter.print("  #");
                printWriter.print(this.f87b.m341c(i2));
                printWriter.print(": ");
                printWriter.println(arVar.toString());
                arVar.m64a(str2, printWriter);
            }
        }
        if (this.f88c.m339b() > 0) {
            printWriter.print(str);
            printWriter.println("Inactive Loaders:");
            String str3 = str + "    ";
            while (i < this.f88c.m339b()) {
                arVar = (ar) this.f88c.m343d(i);
                printWriter.print(str);
                printWriter.print("  #");
                printWriter.print(this.f88c.m341c(i));
                printWriter.print(": ");
                printWriter.println(arVar.toString());
                arVar.m64a(str3, printWriter);
                i++;
            }
        }
    }

    public final boolean mo5a() {
        int b = this.f87b.m339b();
        boolean z = false;
        for (int i = 0; i < b; i++) {
            ar arVar = (ar) this.f87b.m343d(i);
            int i2 = (!arVar.f100h || arVar.f98f) ? 0 : 1;
            z |= i2;
        }
        return z;
    }

    final void m56b() {
        if (f86a) {
            Log.v("LoaderManager", "Starting in " + this);
        }
        if (this.f90e) {
            Throwable runtimeException = new RuntimeException("here");
            runtimeException.fillInStackTrace();
            Log.w("LoaderManager", "Called doStart when already started: " + this, runtimeException);
            return;
        }
        this.f90e = true;
        for (int b = this.f87b.m339b() - 1; b >= 0; b--) {
            ar arVar = (ar) this.f87b.m343d(b);
            if (arVar.f101i && arVar.f102j) {
                arVar.f100h = true;
            } else if (arVar.f100h) {
                continue;
            } else {
                arVar.f100h = true;
                if (f86a) {
                    Log.v("LoaderManager", "  Starting: " + arVar);
                }
                if (arVar.f96d == null && arVar.f95c != null) {
                    arVar.f96d = arVar.f95c.m52a();
                }
                if (arVar.f96d == null) {
                    continue;
                } else if (!arVar.f96d.getClass().isMemberClass() || Modifier.isStatic(arVar.f96d.getClass().getModifiers())) {
                    if (!arVar.f105m) {
                        C0000a c0000a = arVar.f96d;
                        int i = arVar.f93a;
                        if (c0000a.f1b != null) {
                            throw new IllegalStateException("There is already a listener registered");
                        }
                        c0000a.f1b = arVar;
                        c0000a.f0a = i;
                        c0000a = arVar.f96d;
                        if (c0000a.f2c != null) {
                            throw new IllegalStateException("There is already a listener registered");
                        }
                        c0000a.f2c = arVar;
                        arVar.f105m = true;
                    }
                    C0000a c0000a2 = arVar.f96d;
                    c0000a2.f3d = true;
                    c0000a2.f5f = false;
                    c0000a2.f4e = false;
                } else {
                    throw new IllegalArgumentException("Object returned from onCreateLoader must not be a non-static inner member class: " + arVar.f96d);
                }
            }
        }
    }

    final void m57c() {
        if (f86a) {
            Log.v("LoaderManager", "Stopping in " + this);
        }
        if (this.f90e) {
            for (int b = this.f87b.m339b() - 1; b >= 0; b--) {
                ((ar) this.f87b.m343d(b)).m62a();
            }
            this.f90e = false;
            return;
        }
        Throwable runtimeException = new RuntimeException("here");
        runtimeException.fillInStackTrace();
        Log.w("LoaderManager", "Called doStop when not started: " + this, runtimeException);
    }

    final void m58d() {
        if (f86a) {
            Log.v("LoaderManager", "Retaining in " + this);
        }
        if (this.f90e) {
            this.f91f = true;
            this.f90e = false;
            for (int b = this.f87b.m339b() - 1; b >= 0; b--) {
                ar arVar = (ar) this.f87b.m343d(b);
                if (f86a) {
                    Log.v("LoaderManager", "  Retaining: " + arVar);
                }
                arVar.f101i = true;
                arVar.f102j = arVar.f100h;
                arVar.f100h = false;
                arVar.f95c = null;
            }
            return;
        }
        Throwable runtimeException = new RuntimeException("here");
        runtimeException.fillInStackTrace();
        Log.w("LoaderManager", "Called doRetain when not started: " + this, runtimeException);
    }

    final void m59e() {
        for (int b = this.f87b.m339b() - 1; b >= 0; b--) {
            ((ar) this.f87b.m343d(b)).f103k = true;
        }
    }

    final void m60f() {
        for (int b = this.f87b.m339b() - 1; b >= 0; b--) {
            ar arVar = (ar) this.f87b.m343d(b);
            if (arVar.f100h && arVar.f103k) {
                arVar.f103k = false;
                if (arVar.f97e && !arVar.f101i) {
                    arVar.m63a(arVar.f96d, arVar.f99g);
                }
            }
        }
    }

    final void m61g() {
        int b;
        if (!this.f91f) {
            if (f86a) {
                Log.v("LoaderManager", "Destroying Active in " + this);
            }
            for (b = this.f87b.m339b() - 1; b >= 0; b--) {
                ((ar) this.f87b.m343d(b)).m65b();
            }
            this.f87b.m342c();
        }
        if (f86a) {
            Log.v("LoaderManager", "Destroying Inactive in " + this);
        }
        for (b = this.f88c.m339b() - 1; b >= 0; b--) {
            ((ar) this.f88c.m343d(b)).m65b();
        }
        this.f88c.m342c();
    }

    public final String toString() {
        StringBuilder stringBuilder = new StringBuilder(128);
        stringBuilder.append("LoaderManager{");
        stringBuilder.append(Integer.toHexString(System.identityHashCode(this)));
        stringBuilder.append(" in ");
        C0039d.m334a(this.f92g, stringBuilder);
        stringBuilder.append("}}");
        return stringBuilder.toString();
    }
}
