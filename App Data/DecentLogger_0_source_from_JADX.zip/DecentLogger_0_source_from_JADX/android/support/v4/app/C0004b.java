package android.support.v4.app;

import android.view.View;

final class C0004b implements an {
    final /* synthetic */ C0013l f128a;
    final /* synthetic */ C0003a f129b;

    C0004b(C0003a c0003a, C0013l c0013l) {
        this.f129b = c0003a;
        this.f128a = c0013l;
    }

    public final View mo12a() {
        return this.f128a.f275S;
    }
}
