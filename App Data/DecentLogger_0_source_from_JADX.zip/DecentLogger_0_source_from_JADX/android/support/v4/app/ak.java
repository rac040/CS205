package android.support.v4.app;

import android.graphics.Rect;
import android.transition.Transition;
import android.transition.Transition.EpicenterCallback;

final class ak extends EpicenterCallback {
    final /* synthetic */ am f72a;
    private Rect f73b;

    ak(am amVar) {
        this.f72a = amVar;
    }

    public final Rect onGetEpicenter(Transition transition) {
        if (this.f73b == null && this.f72a.f85a != null) {
            this.f73b = ah.m36a(this.f72a.f85a);
        }
        return this.f73b;
    }
}
