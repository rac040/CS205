package android.support.v4.app;

import android.support.v4.p002c.C0035a;
import android.view.View;
import java.util.ArrayList;

public final class C0008f {
    public C0035a f248a = new C0035a();
    public ArrayList f249b = new ArrayList();
    public am f250c = new am();
    public View f251d;
    final /* synthetic */ C0003a f252e;

    public C0008f(C0003a c0003a) {
        this.f252e = c0003a;
    }
}
