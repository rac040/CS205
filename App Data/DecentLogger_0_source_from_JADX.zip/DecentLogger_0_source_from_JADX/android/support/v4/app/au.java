package android.support.v4.app;

import android.app.Notification;
import android.app.Notification.Builder;

public interface au {
    Builder mo18a();

    Notification mo20b();
}
