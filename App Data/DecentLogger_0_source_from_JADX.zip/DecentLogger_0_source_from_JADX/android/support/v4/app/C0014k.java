package android.support.v4.app;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnCancelListener;
import android.content.DialogInterface.OnDismissListener;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;

public class C0014k extends C0013l implements OnCancelListener, OnDismissListener {
    int f299a = 0;
    int f300b = 0;
    boolean f301c = true;
    public boolean f302d = true;
    int f303e = -1;
    Dialog f304f;
    boolean f305g;
    boolean f306h;
    boolean f307i;

    public final void mo27a() {
        super.mo27a();
        if (!this.f307i && !this.f306h) {
            this.f306h = true;
        }
    }

    public final void mo28a(Context context) {
        super.mo28a(context);
        if (!this.f307i) {
            this.f306h = false;
        }
    }

    public final void mo29a(Bundle bundle) {
        super.mo29a(bundle);
        this.f302d = this.H == 0;
        if (bundle != null) {
            this.f299a = bundle.getInt("android:style", 0);
            this.f300b = bundle.getInt("android:theme", 0);
            this.f301c = bundle.getBoolean("android:cancelable", true);
            this.f302d = bundle.getBoolean("android:showsDialog", this.f302d);
            this.f303e = bundle.getInt("android:backStackId", -1);
        }
    }

    public void mo197a(C0024v c0024v, String str) {
        this.f306h = false;
        this.f307i = true;
        ag a = c0024v.mo52a();
        a.mo3a(this, str);
        a.mo1a();
    }

    public Dialog mo30b() {
        return new Dialog(m184f(), this.f300b);
    }

    public final LayoutInflater mo31b(Bundle bundle) {
        if (!this.f302d) {
            return super.mo31b(bundle);
        }
        this.f304f = mo30b();
        if (this.f304f == null) {
            return (LayoutInflater) this.C.f321c.getSystemService("layout_inflater");
        }
        Dialog dialog = this.f304f;
        switch (this.f299a) {
            case 1:
            case 2:
                break;
            case 3:
                dialog.getWindow().addFlags(24);
                break;
        }
        dialog.requestWindowFeature(1);
        return (LayoutInflater) this.f304f.getContext().getSystemService("layout_inflater");
    }

    public final void mo32c() {
        super.mo32c();
        if (this.f304f != null) {
            this.f305g = false;
            this.f304f.show();
        }
    }

    public final void mo33c(Bundle bundle) {
        super.mo33c(bundle);
        if (this.f302d) {
            View view = this.f275S;
            if (view != null) {
                if (view.getParent() != null) {
                    throw new IllegalStateException("DialogFragment can not be attached to a container view");
                }
                this.f304f.setContentView(view);
            }
            Activity f = m184f();
            if (f != null) {
                this.f304f.setOwnerActivity(f);
            }
            this.f304f.setCancelable(this.f301c);
            this.f304f.setOnCancelListener(this);
            this.f304f.setOnDismissListener(this);
            if (bundle != null) {
                Bundle bundle2 = bundle.getBundle("android:savedDialogState");
                if (bundle2 != null) {
                    this.f304f.onRestoreInstanceState(bundle2);
                }
            }
        }
    }

    public final void mo34d() {
        super.mo34d();
        if (this.f304f != null) {
            this.f304f.hide();
        }
    }

    public final void mo35d(Bundle bundle) {
        super.mo35d(bundle);
        if (this.f304f != null) {
            Bundle onSaveInstanceState = this.f304f.onSaveInstanceState();
            if (onSaveInstanceState != null) {
                bundle.putBundle("android:savedDialogState", onSaveInstanceState);
            }
        }
        if (this.f299a != 0) {
            bundle.putInt("android:style", this.f299a);
        }
        if (this.f300b != 0) {
            bundle.putInt("android:theme", this.f300b);
        }
        if (!this.f301c) {
            bundle.putBoolean("android:cancelable", this.f301c);
        }
        if (!this.f302d) {
            bundle.putBoolean("android:showsDialog", this.f302d);
        }
        if (this.f303e != -1) {
            bundle.putInt("android:backStackId", this.f303e);
        }
    }

    public final void mo36e() {
        super.mo36e();
        if (this.f304f != null) {
            this.f305g = true;
            this.f304f.dismiss();
            this.f304f = null;
        }
    }

    public void onCancel(DialogInterface dialogInterface) {
    }

    public void onDismiss(DialogInterface dialogInterface) {
        if (!this.f305g && !this.f306h) {
            this.f306h = true;
            this.f307i = false;
            if (this.f304f != null) {
                this.f304f.dismiss();
                this.f304f = null;
            }
            this.f305g = true;
            if (this.f303e >= 0) {
                this.f258B.mo54a(this.f303e);
                this.f303e = -1;
                return;
            }
            ag a = this.f258B.mo52a();
            a.mo2a(this);
            a.mo4b();
        }
    }
}
