package android.support.v4.app;

import java.io.FileDescriptor;
import java.io.PrintWriter;

public abstract class C0024v {
    public abstract ag mo52a();

    public abstract void mo54a(int i);

    public abstract void mo55a(String str, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] strArr);

    public abstract boolean mo56b();
}
