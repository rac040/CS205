package android.support.v4.app;

import android.app.Notification;
import android.app.Notification.Builder;
import android.app.PendingIntent;
import android.content.Context;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.util.SparseArray;
import android.widget.RemoteViews;
import java.util.ArrayList;
import java.util.List;

public final class cg implements at, au {
    private Builder f216a;
    private Bundle f217b;
    private List f218c = new ArrayList();
    private RemoteViews f219d;
    private RemoteViews f220e;

    public cg(Context context, Notification notification, CharSequence charSequence, CharSequence charSequence2, CharSequence charSequence3, RemoteViews remoteViews, int i, PendingIntent pendingIntent, PendingIntent pendingIntent2, Bitmap bitmap, int i2, int i3, boolean z, boolean z2, boolean z3, int i4, CharSequence charSequence4, boolean z4, ArrayList arrayList, Bundle bundle, String str, boolean z5, String str2, RemoteViews remoteViews2, RemoteViews remoteViews3) {
        this.f216a = new Builder(context).setWhen(notification.when).setShowWhen(z2).setSmallIcon(notification.icon, notification.iconLevel).setContent(notification.contentView).setTicker(notification.tickerText, remoteViews).setSound(notification.sound, notification.audioStreamType).setVibrate(notification.vibrate).setLights(notification.ledARGB, notification.ledOnMS, notification.ledOffMS).setOngoing((notification.flags & 2) != 0).setOnlyAlertOnce((notification.flags & 8) != 0).setAutoCancel((notification.flags & 16) != 0).setDefaults(notification.defaults).setContentTitle(charSequence).setContentText(charSequence2).setSubText(charSequence4).setContentInfo(charSequence3).setContentIntent(pendingIntent).setDeleteIntent(notification.deleteIntent).setFullScreenIntent(pendingIntent2, (notification.flags & 128) != 0).setLargeIcon(bitmap).setNumber(i).setUsesChronometer(z3).setPriority(i4).setProgress(i2, i3, z);
        this.f217b = new Bundle();
        if (bundle != null) {
            this.f217b.putAll(bundle);
        }
        if (!(arrayList == null || arrayList.isEmpty())) {
            this.f217b.putStringArray("android.people", (String[]) arrayList.toArray(new String[arrayList.size()]));
        }
        if (z4) {
            this.f217b.putBoolean("android.support.localOnly", true);
        }
        if (str != null) {
            this.f217b.putString("android.support.groupKey", str);
            if (z5) {
                this.f217b.putBoolean("android.support.isGroupSummary", true);
            } else {
                this.f217b.putBoolean("android.support.useSideChannel", true);
            }
        }
        if (str2 != null) {
            this.f217b.putString("android.support.sortKey", str2);
        }
        this.f219d = remoteViews2;
        this.f220e = remoteViews3;
    }

    public final Builder mo18a() {
        return this.f216a;
    }

    public final void mo19a(bz bzVar) {
        this.f218c.add(cd.m130a(this.f216a, bzVar));
    }

    public final Notification mo20b() {
        SparseArray a = cd.m132a(this.f218c);
        if (a != null) {
            this.f217b.putSparseParcelableArray("android.support.actionExtras", a);
        }
        this.f216a.setExtras(this.f217b);
        Notification build = this.f216a.build();
        if (this.f219d != null) {
            build.contentView = this.f219d;
        }
        if (this.f220e != null) {
            build.bigContentView = this.f220e;
        }
        return build;
    }
}
