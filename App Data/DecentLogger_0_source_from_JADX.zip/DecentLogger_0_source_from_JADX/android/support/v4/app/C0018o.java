package android.support.v4.app;

import android.content.Context;
import android.content.Intent;
import android.content.IntentSender;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.content.res.Resources.NotFoundException;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.os.Handler;
import android.os.Parcelable;
import android.support.v4.p002c.C0034l;
import android.support.v4.p002c.C0038c;
import android.support.v4.p002c.C0046m;
import android.util.AttributeSet;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import java.io.FileDescriptor;
import java.io.PrintWriter;

public final class C0018o extends C0012j {
    final Handler f309c = new C0019p(this);
    public final C0023t f310d = new C0023t(new C0021q(this));
    boolean f311e;
    boolean f312f;
    boolean f313g;
    boolean f314h;
    boolean f315i;
    boolean f316j;
    int f317k;
    C0046m f318l;

    private static String m206a(View view) {
        char c = 'F';
        char c2 = '.';
        StringBuilder stringBuilder = new StringBuilder(128);
        stringBuilder.append(view.getClass().getName());
        stringBuilder.append('{');
        stringBuilder.append(Integer.toHexString(System.identityHashCode(view)));
        stringBuilder.append(' ');
        switch (view.getVisibility()) {
            case 0:
                stringBuilder.append('V');
                break;
            case 4:
                stringBuilder.append('I');
                break;
            case 8:
                stringBuilder.append('G');
                break;
            default:
                stringBuilder.append('.');
                break;
        }
        stringBuilder.append(view.isFocusable() ? 'F' : '.');
        stringBuilder.append(view.isEnabled() ? 'E' : '.');
        stringBuilder.append(view.willNotDraw() ? '.' : 'D');
        stringBuilder.append(view.isHorizontalScrollBarEnabled() ? 'H' : '.');
        stringBuilder.append(view.isVerticalScrollBarEnabled() ? 'V' : '.');
        stringBuilder.append(view.isClickable() ? 'C' : '.');
        stringBuilder.append(view.isLongClickable() ? 'L' : '.');
        stringBuilder.append(' ');
        if (!view.isFocused()) {
            c = '.';
        }
        stringBuilder.append(c);
        stringBuilder.append(view.isSelected() ? 'S' : '.');
        if (view.isPressed()) {
            c2 = 'P';
        }
        stringBuilder.append(c2);
        stringBuilder.append(' ');
        stringBuilder.append(view.getLeft());
        stringBuilder.append(',');
        stringBuilder.append(view.getTop());
        stringBuilder.append('-');
        stringBuilder.append(view.getRight());
        stringBuilder.append(',');
        stringBuilder.append(view.getBottom());
        int id = view.getId();
        if (id != -1) {
            stringBuilder.append(" #");
            stringBuilder.append(Integer.toHexString(id));
            Resources resources = view.getResources();
            if (!(id == 0 || resources == null)) {
                String str;
                switch (-16777216 & id) {
                    case 16777216:
                        str = "android";
                        break;
                    case 2130706432:
                        str = "app";
                        break;
                    default:
                        try {
                            str = resources.getResourcePackageName(id);
                            break;
                        } catch (NotFoundException e) {
                            break;
                        }
                }
                String resourceTypeName = resources.getResourceTypeName(id);
                String resourceEntryName = resources.getResourceEntryName(id);
                stringBuilder.append(" ");
                stringBuilder.append(str);
                stringBuilder.append(":");
                stringBuilder.append(resourceTypeName);
                stringBuilder.append("/");
                stringBuilder.append(resourceEntryName);
            }
        }
        stringBuilder.append("}");
        return stringBuilder.toString();
    }

    private void m207a(String str, PrintWriter printWriter, View view) {
        printWriter.print(str);
        if (view == null) {
            printWriter.println("null");
            return;
        }
        printWriter.println(C0018o.m206a(view));
        if (view instanceof ViewGroup) {
            ViewGroup viewGroup = (ViewGroup) view;
            int childCount = viewGroup.getChildCount();
            if (childCount > 0) {
                String str2 = str + "  ";
                for (int i = 0; i < childCount; i++) {
                    m207a(str2, printWriter, viewGroup.getChildAt(i));
                }
            }
        }
    }

    final View mo39a(View view, String str, Context context, AttributeSet attributeSet) {
        return this.f310d.f334a.f324f.mo53a(view, str, context, attributeSet);
    }

    protected final void m209a() {
        this.f310d.f334a.f324f.m290j();
    }

    final void m210a(boolean z) {
        if (!this.f314h) {
            this.f314h = true;
            this.f315i = z;
            this.f309c.removeMessages(1);
            this.f310d.m231a(this.f315i);
            this.f310d.f334a.f324f.m274b(2);
        } else if (z) {
            this.f310d.m233c();
            this.f310d.m231a(true);
        }
    }

    public final void dump(String str, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] strArr) {
        int i = VERSION.SDK_INT;
        printWriter.print(str);
        printWriter.print("Local FragmentActivity ");
        printWriter.print(Integer.toHexString(System.identityHashCode(this)));
        printWriter.println(" State:");
        String str2 = str + "  ";
        printWriter.print(str2);
        printWriter.print("mCreated=");
        printWriter.print(this.f311e);
        printWriter.print("mResumed=");
        printWriter.print(this.f312f);
        printWriter.print(" mStopped=");
        printWriter.print(this.f313g);
        printWriter.print(" mReallyStopped=");
        printWriter.println(this.f314h);
        C0020u c0020u = this.f310d.f334a;
        printWriter.print(str2);
        printWriter.print("mLoadersStarted=");
        printWriter.println(c0020u.f329k);
        if (c0020u.f327i != null) {
            printWriter.print(str2);
            printWriter.print("Loader Manager ");
            printWriter.print(Integer.toHexString(System.identityHashCode(c0020u.f327i)));
            printWriter.println(":");
            c0020u.f327i.m54a(str2 + "  ", printWriter);
        }
        this.f310d.f334a.f324f.mo55a(str, fileDescriptor, printWriter, strArr);
        printWriter.print(str);
        printWriter.println("View Hierarchy:");
        m207a(str + "  ", printWriter, getWindow().getDecorView());
    }

    protected final void onActivityResult(int i, int i2, Intent intent) {
        this.f310d.m230a();
        int i3 = i >> 16;
        if (i3 != 0) {
            int i4 = i3 - 1;
            String str = (String) this.f318l.m337a(i4);
            this.f318l.m340b(i4);
            if (str == null) {
                Log.w("FragmentActivity", "Activity result delivered for unknown Fragment.");
                return;
            } else if (this.f310d.m229a(str) == null) {
                Log.w("FragmentActivity", "Activity result no fragment exists for who: " + str);
                return;
            } else {
                C0013l.m167i();
                return;
            }
        }
        super.onActivityResult(i, i2, intent);
    }

    public final void onBackPressed() {
        if (!this.f310d.f334a.f324f.mo56b()) {
            super.onBackPressed();
        }
    }

    public final void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        this.f310d.f334a.f324f.m260a(configuration);
    }

    protected final void onCreate(Bundle bundle) {
        C0023t c0023t = this.f310d;
        c0023t.f334a.f324f.m266a(c0023t.f334a, c0023t.f334a, null);
        super.onCreate(bundle);
        C0022r c0022r = (C0022r) getLastNonConfigurationInstance();
        if (c0022r != null) {
            this.f310d.f334a.f325g = c0022r.f333c;
        }
        if (bundle != null) {
            this.f310d.f334a.f324f.m261a(bundle.getParcelable("android:support:fragments"), c0022r != null ? c0022r.f332b : null);
            if (bundle.containsKey("android:support:next_request_index")) {
                this.f317k = bundle.getInt("android:support:next_request_index");
                int[] intArray = bundle.getIntArray("android:support:request_indicies");
                String[] stringArray = bundle.getStringArray("android:support:request_fragment_who");
                if (intArray == null || stringArray == null || intArray.length != stringArray.length) {
                    Log.w("FragmentActivity", "Invalid requestCode mapping in savedInstanceState.");
                } else {
                    this.f318l = new C0046m(intArray.length);
                    for (int i = 0; i < intArray.length; i++) {
                        C0046m c0046m = this.f318l;
                        int i2 = intArray[i];
                        String str = stringArray[i];
                        int a = C0038c.m332a(c0046m.f404c, c0046m.f406e, i2);
                        if (a >= 0) {
                            c0046m.f405d[a] = str;
                        } else {
                            a ^= -1;
                            if (a >= c0046m.f406e || c0046m.f405d[a] != C0046m.f402a) {
                                if (c0046m.f403b && c0046m.f406e >= c0046m.f404c.length) {
                                    c0046m.m338a();
                                    a = C0038c.m332a(c0046m.f404c, c0046m.f406e, i2) ^ -1;
                                }
                                if (c0046m.f406e >= c0046m.f404c.length) {
                                    int a2 = C0038c.m331a(c0046m.f406e + 1);
                                    Object obj = new int[a2];
                                    Object obj2 = new Object[a2];
                                    System.arraycopy(c0046m.f404c, 0, obj, 0, c0046m.f404c.length);
                                    System.arraycopy(c0046m.f405d, 0, obj2, 0, c0046m.f405d.length);
                                    c0046m.f404c = obj;
                                    c0046m.f405d = obj2;
                                }
                                if (c0046m.f406e - a != 0) {
                                    System.arraycopy(c0046m.f404c, a, c0046m.f404c, a + 1, c0046m.f406e - a);
                                    System.arraycopy(c0046m.f405d, a, c0046m.f405d, a + 1, c0046m.f406e - a);
                                }
                                c0046m.f404c[a] = i2;
                                c0046m.f405d[a] = str;
                                c0046m.f406e++;
                            } else {
                                c0046m.f404c[a] = i2;
                                c0046m.f405d[a] = str;
                            }
                        }
                    }
                }
            }
        }
        if (this.f318l == null) {
            this.f318l = new C0046m();
            this.f317k = 0;
        }
        this.f310d.f334a.f324f.m287g();
    }

    public final boolean onCreatePanelMenu(int i, Menu menu) {
        if (i != 0) {
            return super.onCreatePanelMenu(i, menu);
        }
        return VERSION.SDK_INT >= 11 ? super.onCreatePanelMenu(i, menu) | this.f310d.f334a.f324f.m272a(menu, getMenuInflater()) : true;
    }

    public final /* bridge */ /* synthetic */ View onCreateView(View view, String str, Context context, AttributeSet attributeSet) {
        return super.onCreateView(view, str, context, attributeSet);
    }

    public final /* bridge */ /* synthetic */ View onCreateView(String str, Context context, AttributeSet attributeSet) {
        return super.onCreateView(str, context, attributeSet);
    }

    protected final void onDestroy() {
        super.onDestroy();
        m210a(false);
        this.f310d.f334a.f324f.m292l();
        C0020u c0020u = this.f310d.f334a;
        if (c0020u.f327i != null) {
            c0020u.f327i.m61g();
        }
    }

    public final void onLowMemory() {
        super.onLowMemory();
        this.f310d.f334a.f324f.m293m();
    }

    public final boolean onMenuItemSelected(int i, MenuItem menuItem) {
        if (super.onMenuItemSelected(i, menuItem)) {
            return true;
        }
        switch (i) {
            case 0:
                return this.f310d.f334a.f324f.m273a(menuItem);
            case 6:
                return this.f310d.f334a.f324f.m279b(menuItem);
            default:
                return false;
        }
    }

    public final void onMultiWindowModeChanged(boolean z) {
        this.f310d.f334a.f324f.m269a(z);
    }

    protected final void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        this.f310d.m230a();
    }

    public final void onPanelClosed(int i, Menu menu) {
        switch (i) {
            case 0:
                this.f310d.f334a.f324f.m276b(menu);
                break;
        }
        super.onPanelClosed(i, menu);
    }

    protected final void onPause() {
        super.onPause();
        this.f312f = false;
        if (this.f309c.hasMessages(2)) {
            this.f309c.removeMessages(2);
            m209a();
        }
        this.f310d.f334a.f324f.m274b(4);
    }

    public final void onPictureInPictureModeChanged(boolean z) {
        this.f310d.f334a.f324f.m277b(z);
    }

    protected final void onPostResume() {
        super.onPostResume();
        this.f309c.removeMessages(2);
        m209a();
        this.f310d.m232b();
    }

    public final boolean onPreparePanel(int i, View view, Menu menu) {
        if (i != 0 || menu == null) {
            return super.onPreparePanel(i, view, menu);
        }
        if (this.f316j) {
            this.f316j = false;
            menu.clear();
            onCreatePanelMenu(i, menu);
        }
        return super.onPreparePanel(0, view, menu) | this.f310d.f334a.f324f.m271a(menu);
    }

    public final void onRequestPermissionsResult(int i, String[] strArr, int[] iArr) {
        int i2 = (i >> 16) & 65535;
        if (i2 != 0) {
            int i3 = i2 - 1;
            String str = (String) this.f318l.m337a(i3);
            this.f318l.m340b(i3);
            if (str == null) {
                Log.w("FragmentActivity", "Activity result delivered for unknown Fragment.");
            } else if (this.f310d.m229a(str) == null) {
                Log.w("FragmentActivity", "Activity result no fragment exists for who: " + str);
            } else {
                C0013l.m168j();
            }
        }
    }

    protected final void onResume() {
        super.onResume();
        this.f309c.sendEmptyMessage(2);
        this.f312f = true;
        this.f310d.m232b();
    }

    public final Object onRetainNonConfigurationInstance() {
        int i;
        int i2 = 0;
        if (this.f313g) {
            m210a(true);
        }
        ad e = this.f310d.f334a.f324f.m284e();
        C0020u c0020u = this.f310d.f334a;
        if (c0020u.f325g != null) {
            int size = c0020u.f325g.size();
            aq[] aqVarArr = new aq[size];
            for (int i3 = size - 1; i3 >= 0; i3--) {
                aqVarArr[i3] = (aq) c0020u.f325g.m306c(i3);
            }
            boolean z = c0020u.f326h;
            i = 0;
            while (i2 < size) {
                aq aqVar = aqVarArr[i2];
                if (!aqVar.f91f && z) {
                    if (!aqVar.f90e) {
                        aqVar.m56b();
                    }
                    aqVar.m58d();
                }
                if (aqVar.f91f) {
                    i = true;
                } else {
                    aqVar.m61g();
                    c0020u.f325g.remove(aqVar.f89d);
                }
                i2++;
            }
        } else {
            i = 0;
        }
        C0034l c0034l = i != 0 ? c0020u.f325g : null;
        if (e == null && c0034l == null) {
            return null;
        }
        C0022r c0022r = new C0022r();
        c0022r.f331a = null;
        c0022r.f332b = e;
        c0022r.f333c = c0034l;
        return c0022r;
    }

    protected final void onSaveInstanceState(Bundle bundle) {
        super.onSaveInstanceState(bundle);
        Parcelable f = this.f310d.f334a.f324f.m286f();
        if (f != null) {
            bundle.putParcelable("android:support:fragments", f);
        }
        if (this.f318l.m339b() > 0) {
            bundle.putInt("android:support:next_request_index", this.f317k);
            int[] iArr = new int[this.f318l.m339b()];
            String[] strArr = new String[this.f318l.m339b()];
            for (int i = 0; i < this.f318l.m339b(); i++) {
                iArr[i] = this.f318l.m341c(i);
                strArr[i] = (String) this.f318l.m343d(i);
            }
            bundle.putIntArray("android:support:request_indicies", iArr);
            bundle.putStringArray("android:support:request_fragment_who", strArr);
        }
    }

    protected final void onStart() {
        super.onStart();
        this.f313g = false;
        this.f314h = false;
        this.f309c.removeMessages(1);
        if (!this.f311e) {
            this.f311e = true;
            this.f310d.f334a.f324f.m288h();
        }
        this.f310d.m230a();
        this.f310d.m232b();
        this.f310d.m233c();
        this.f310d.f334a.f324f.m289i();
        C0020u c0020u = this.f310d.f334a;
        if (c0020u.f325g != null) {
            int i;
            int size = c0020u.f325g.size();
            aq[] aqVarArr = new aq[size];
            for (i = size - 1; i >= 0; i--) {
                aqVarArr[i] = (aq) c0020u.f325g.m306c(i);
            }
            for (i = 0; i < size; i++) {
                aq aqVar = aqVarArr[i];
                if (aqVar.f91f) {
                    if (aq.f86a) {
                        Log.v("LoaderManager", "Finished Retaining in " + aqVar);
                    }
                    aqVar.f91f = false;
                    for (int b = aqVar.f87b.m339b() - 1; b >= 0; b--) {
                        ar arVar = (ar) aqVar.f87b.m343d(b);
                        if (arVar.f101i) {
                            if (aq.f86a) {
                                Log.v("LoaderManager", "  Finished Retaining: " + arVar);
                            }
                            arVar.f101i = false;
                            if (!(arVar.f100h == arVar.f102j || arVar.f100h)) {
                                arVar.m62a();
                            }
                        }
                        if (arVar.f100h && arVar.f97e && !arVar.f103k) {
                            arVar.m63a(arVar.f96d, arVar.f99g);
                        }
                    }
                }
                aqVar.m60f();
            }
        }
    }

    public final void onStateNotSaved() {
        this.f310d.m230a();
    }

    protected final void onStop() {
        super.onStop();
        this.f313g = true;
        this.f309c.sendEmptyMessage(1);
        this.f310d.f334a.f324f.m291k();
    }

    public final void startActivityForResult(Intent intent, int i) {
        if (!(this.b || i == -1)) {
            C0010h.m160a(i);
        }
        super.startActivityForResult(intent, i);
    }

    public final /* bridge */ /* synthetic */ void startActivityForResult(Intent intent, int i, Bundle bundle) {
        super.startActivityForResult(intent, i, bundle);
    }

    public final /* bridge */ /* synthetic */ void startIntentSenderForResult(IntentSender intentSender, int i, Intent intent, int i2, int i3, int i4) {
        super.startIntentSenderForResult(intentSender, i, intent, i2, i3, i4);
    }

    public final /* bridge */ /* synthetic */ void startIntentSenderForResult(IntentSender intentSender, int i, Intent intent, int i2, int i3, int i4, Bundle bundle) {
        super.startIntentSenderForResult(intentSender, i, intent, i2, i3, i4, bundle);
    }
}
