package android.support.v4.app;

import android.os.Build.VERSION;
import android.support.v4.p002c.C0035a;
import android.support.v4.p002c.C0036f;
import android.support.v4.p002c.C0040e;
import android.transition.Transition;
import android.transition.TransitionManager;
import android.transition.TransitionSet;
import android.util.Log;
import android.util.SparseArray;
import android.view.View;
import android.view.ViewGroup;
import java.io.PrintWriter;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.Map;

final class C0003a extends ag implements Runnable {
    static final boolean f34a = (VERSION.SDK_INT >= 21);
    final C0025w f35b;
    C0007e f36c;
    C0007e f37d;
    int f38e;
    int f39f;
    int f40g;
    int f41h;
    int f42i;
    int f43j;
    int f44k;
    boolean f45l;
    boolean f46m = true;
    String f47n;
    boolean f48o;
    int f49p = -1;
    int f50q;
    CharSequence f51r;
    int f52s;
    CharSequence f53t;
    ArrayList f54u;
    ArrayList f55v;

    public C0003a(C0025w c0025w) {
        this.f35b = c0025w;
    }

    private int m7a(boolean z) {
        if (this.f48o) {
            throw new IllegalStateException("commit already called");
        }
        if (C0025w.f339a) {
            Log.v("FragmentManager", "Commit: " + this);
            m32a("  ", new PrintWriter(new C0040e("FragmentManager")));
        }
        this.f48o = true;
        if (this.f45l) {
            this.f49p = this.f35b.m254a(this);
        } else {
            this.f49p = -1;
        }
        this.f35b.m267a((Runnable) this, z);
        return this.f49p;
    }

    private C0008f m8a(SparseArray sparseArray, SparseArray sparseArray2, boolean z) {
        int i = 0;
        C0008f c0008f = new C0008f(this);
        c0008f.f251d = new View(this.f35b.f354o.f321c);
        int i2 = 0;
        int i3 = 0;
        while (i2 < sparseArray.size()) {
            int i4 = m21a(sparseArray.keyAt(i2), c0008f, z, sparseArray, sparseArray2) ? 1 : i3;
            i2++;
            i3 = i4;
        }
        while (i < sparseArray2.size()) {
            i4 = sparseArray2.keyAt(i);
            if (sparseArray.get(i4) == null && m21a(i4, c0008f, z, sparseArray, sparseArray2)) {
                i3 = 1;
            }
            i++;
        }
        return i3 == 0 ? null : c0008f;
    }

    static /* synthetic */ C0035a m9a(C0003a c0003a, C0008f c0008f, boolean z, C0013l c0013l) {
        C0035a a;
        Map c0035a = new C0035a();
        View view = c0013l.f275S;
        if (!(view == null || c0003a.f54u == null)) {
            ah.m45a(c0035a, view);
            if (z) {
                a = C0003a.m11a(c0003a.f54u, c0003a.f55v, (C0035a) c0035a);
            } else {
                C0036f.m309a(c0035a, c0003a.f55v);
            }
        }
        ct ctVar;
        if (z) {
            if (c0013l.ai != null) {
                ctVar = c0013l.ai;
            }
            c0003a.m16a(c0008f, a, true);
        } else {
            if (c0013l.ah != null) {
                ctVar = c0013l.ah;
            }
            C0003a.m22b(c0008f, a, true);
        }
        return a;
    }

    private C0035a m10a(C0008f c0008f, C0013l c0013l, boolean z) {
        C0035a c0035a = new C0035a();
        if (this.f54u != null) {
            ah.m45a((Map) c0035a, c0013l.f275S);
            if (z) {
                C0036f.m309a((Map) c0035a, this.f55v);
            } else {
                c0035a = C0003a.m11a(this.f54u, this.f55v, c0035a);
            }
        }
        ct ctVar;
        if (z) {
            if (c0013l.ah != null) {
                ctVar = c0013l.ah;
            }
            m16a(c0008f, c0035a, false);
        } else {
            if (c0013l.ai != null) {
                ctVar = c0013l.ai;
            }
            C0003a.m22b(c0008f, c0035a, false);
        }
        return c0035a;
    }

    private static C0035a m11a(ArrayList arrayList, ArrayList arrayList2, C0035a c0035a) {
        if (c0035a.isEmpty()) {
            return c0035a;
        }
        C0035a c0035a2 = new C0035a();
        int size = arrayList.size();
        for (int i = 0; i < size; i++) {
            View view = (View) c0035a.get(arrayList.get(i));
            if (view != null) {
                c0035a2.put(arrayList2.get(i), view);
            }
        }
        return c0035a2;
    }

    private static Object m12a(Object obj, C0013l c0013l, ArrayList arrayList, C0035a c0035a, View view) {
        if (obj == null) {
            return obj;
        }
        View view2 = c0013l.f275S;
        if (obj == null) {
            return obj;
        }
        ah.m44a(arrayList, view2);
        if (c0035a != null) {
            arrayList.removeAll(c0035a.values());
        }
        if (arrayList.isEmpty()) {
            return null;
        }
        arrayList.add(view);
        ah.m49b((Transition) obj, arrayList);
        return obj;
    }

    static /* synthetic */ void m14a(C0003a c0003a, C0035a c0035a, C0008f c0008f) {
        if (c0003a.f55v != null && !c0035a.isEmpty()) {
            View view = (View) c0035a.get(c0003a.f55v.get(0));
            if (view != null) {
                c0008f.f250c.f85a = view;
            }
        }
    }

    private void m15a(C0008f c0008f, int i, Object obj) {
        if (this.f35b.f346g != null) {
            for (int i2 = 0; i2 < this.f35b.f346g.size(); i2++) {
                C0013l c0013l = (C0013l) this.f35b.f346g.get(i2);
                if (!(c0013l.f275S == null || c0013l.f274R == null || c0013l.f264H != i)) {
                    if (!c0013l.f266J) {
                        ah.m41a(obj, c0013l.f275S, false);
                        c0008f.f249b.remove(c0013l.f275S);
                    } else if (!c0008f.f249b.contains(c0013l.f275S)) {
                        ah.m41a(obj, c0013l.f275S, true);
                        c0008f.f249b.add(c0013l.f275S);
                    }
                }
            }
        }
    }

    private void m16a(C0008f c0008f, C0035a c0035a, boolean z) {
        int size = this.f55v == null ? 0 : this.f55v.size();
        for (int i = 0; i < size; i++) {
            String str = (String) this.f54u.get(i);
            View view = (View) c0035a.get((String) this.f55v.get(i));
            if (view != null) {
                String transitionName = view.getTransitionName();
                if (z) {
                    C0003a.m19a(c0008f.f248a, str, transitionName);
                } else {
                    C0003a.m19a(c0008f.f248a, transitionName, str);
                }
            }
        }
    }

    private static void m17a(C0008f c0008f, ArrayList arrayList, ArrayList arrayList2) {
        if (arrayList != null) {
            for (int i = 0; i < arrayList.size(); i++) {
                C0003a.m19a(c0008f.f248a, (String) arrayList.get(i), (String) arrayList2.get(i));
            }
        }
    }

    static /* synthetic */ void m18a(C0013l c0013l, C0013l c0013l2, boolean z, C0035a c0035a) {
        if ((z ? c0013l2.ah : c0013l.ah) != null) {
            ArrayList arrayList = new ArrayList(c0035a.keySet());
            arrayList = new ArrayList(c0035a.values());
        }
    }

    private static void m19a(C0035a c0035a, String str, String str2) {
        if (str != null && str2 != null) {
            for (int i = 0; i < c0035a.size(); i++) {
                if (str.equals(c0035a.m306c(i))) {
                    c0035a.m302a(i, (Object) str2);
                    return;
                }
            }
            c0035a.put(str, str2);
        }
    }

    private static void m20a(SparseArray sparseArray, SparseArray sparseArray2, C0013l c0013l) {
        if (c0013l != null) {
            int i = c0013l.f264H;
            if (i != 0 && !c0013l.f266J) {
                if (c0013l.m186g() && c0013l.f275S != null && sparseArray.get(i) == null) {
                    sparseArray.put(i, c0013l);
                }
                if (sparseArray2.get(i) == c0013l) {
                    sparseArray2.remove(i);
                }
            }
        }
    }

    private boolean m21a(int i, C0008f c0008f, boolean z, SparseArray sparseArray, SparseArray sparseArray2) {
        View view = (ViewGroup) this.f35b.f355p.mo37a(i);
        if (view == null) {
            return false;
        }
        Object obj;
        Object obj2;
        Transition transition;
        Object obj3;
        C0035a c0035a;
        Object obj4;
        C0013l c0013l = (C0013l) sparseArray2.get(i);
        C0013l c0013l2 = (C0013l) sparseArray.get(i);
        if (c0013l == null) {
            obj = null;
        } else {
            Object obj5 = z ? c0013l.ac == C0013l.f256j ? c0013l.ab : c0013l.ac : c0013l.f282Z;
            obj = ah.m37a(obj5);
        }
        if (c0013l == null || c0013l2 == null) {
            obj2 = null;
        } else {
            obj5 = z ? c0013l2.ae == C0013l.f256j ? c0013l2.ad : c0013l2.ae : c0013l.ad;
            if (obj5 == null) {
                obj2 = null;
            } else {
                transition = (Transition) obj5;
                if (transition == null) {
                    obj2 = null;
                } else {
                    obj2 = new TransitionSet();
                    obj2.addTransition(transition);
                }
            }
        }
        if (c0013l2 == null) {
            obj3 = null;
        } else {
            obj5 = z ? c0013l2.aa == C0013l.f256j ? c0013l2.f282Z : c0013l2.aa : c0013l2.ab;
            obj3 = ah.m37a(obj5);
        }
        ArrayList arrayList = new ArrayList();
        if (obj2 != null) {
            C0035a a = m10a(c0008f, c0013l2, z);
            if (a.isEmpty()) {
                c0035a = null;
                obj4 = null;
            } else {
                if ((z ? c0013l2.ah : c0013l.ah) != null) {
                    ArrayList arrayList2 = new ArrayList(a.keySet());
                    arrayList2 = new ArrayList(a.values());
                }
                if (obj2 != null) {
                    view.getViewTreeObserver().addOnPreDrawListener(new C0005c(this, view, obj2, arrayList, c0008f, obj, obj3, z, c0013l, c0013l2));
                }
                c0035a = a;
                obj4 = obj2;
            }
        } else {
            c0035a = null;
            obj4 = obj2;
        }
        if (obj == null && obj4 == null && obj3 == null) {
            return false;
        }
        boolean z2;
        Object obj6;
        ArrayList arrayList3 = new ArrayList();
        obj2 = C0003a.m12a(obj3, c0013l2, arrayList3, c0035a, c0008f.f251d);
        if (!(this.f55v == null || c0035a == null)) {
            View view2 = (View) c0035a.get(this.f55v.get(0));
            if (view2 != null) {
                if (obj2 != null) {
                    ah.m39a(obj2, view2);
                }
                if (obj4 != null) {
                    ah.m39a(obj4, view2);
                }
            }
        }
        an c0004b = new C0004b(this, c0013l);
        ArrayList arrayList4 = new ArrayList();
        Map c0035a2 = new C0035a();
        if (c0013l != null) {
            boolean booleanValue = z ? c0013l.af == null ? true : c0013l.af.booleanValue() : c0013l.ag == null ? true : c0013l.ag.booleanValue();
            z2 = booleanValue;
        } else {
            z2 = true;
        }
        transition = (Transition) obj;
        Transition transition2 = (Transition) obj2;
        Transition transition3 = (Transition) obj4;
        if (transition == null || transition2 == null) {
            z2 = true;
        }
        if (z2) {
            TransitionSet transitionSet = new TransitionSet();
            if (transition != null) {
                transitionSet.addTransition(transition);
            }
            if (transition2 != null) {
                transitionSet.addTransition(transition2);
            }
            if (transition3 != null) {
                transitionSet.addTransition(transition3);
            }
            obj6 = transitionSet;
        } else {
            if (transition2 != null && transition != null) {
                transition = new TransitionSet().addTransition(transition2).addTransition(transition).setOrdering(1);
            } else if (transition2 != null) {
                transition = transition2;
            } else if (transition == null) {
                transition = null;
            }
            if (transition3 != null) {
                obj6 = new TransitionSet();
                if (transition != null) {
                    obj6.addTransition(transition);
                }
                obj6.addTransition(transition3);
            } else {
                transition2 = transition;
            }
        }
        if (obj6 != null) {
            View view3 = c0008f.f251d;
            am amVar = c0008f.f250c;
            Map map = c0008f.f248a;
            Transition transition4 = (Transition) obj;
            Transition transition5 = (Transition) obj2;
            transition = (Transition) obj4;
            ah.m38a(transition4, transition5, arrayList3, true);
            if (!(obj == null && obj4 == null)) {
                if (transition4 != null) {
                    transition4.addTarget(view3);
                }
                if (obj4 != null) {
                    ah.m40a((Object) transition, view3, (Map) c0035a, arrayList);
                    ah.m38a(transition4, transition, arrayList, true);
                    ah.m38a(transition5, transition, arrayList, true);
                }
                view.getViewTreeObserver().addOnPreDrawListener(new aj(view, transition4, view3, c0004b, map, c0035a2, arrayList4, transition5));
                if (transition4 != null) {
                    transition4.setEpicenterCallback(new ak(amVar));
                }
            }
            view.getViewTreeObserver().addOnPreDrawListener(new C0006d(this, view, c0008f, i, obj6));
            ah.m41a(obj6, c0008f.f251d, true);
            m15a(c0008f, i, obj6);
            TransitionManager.beginDelayedTransition(view, (Transition) obj6);
            View view4 = c0008f.f251d;
            ArrayList arrayList5 = c0008f.f249b;
            Transition transition6 = (Transition) obj;
            Transition transition7 = (Transition) obj2;
            Transition transition8 = (Transition) obj4;
            Transition transition9 = (Transition) obj6;
            if (transition9 != null) {
                view.getViewTreeObserver().addOnPreDrawListener(new al(view, transition6, arrayList4, transition7, arrayList3, transition8, arrayList, c0035a2, arrayList5, transition9, view4));
            }
        }
        return obj6 != null;
    }

    private static void m22b(C0008f c0008f, C0035a c0035a, boolean z) {
        int size = c0035a.size();
        for (int i = 0; i < size; i++) {
            String str = (String) c0035a.m305b(i);
            String transitionName = ((View) c0035a.m306c(i)).getTransitionName();
            if (z) {
                C0003a.m19a(c0008f.f248a, str, transitionName);
            } else {
                C0003a.m19a(c0008f.f248a, transitionName, str);
            }
        }
    }

    private void m23b(SparseArray sparseArray, SparseArray sparseArray2) {
        if (this.f35b.f355p.mo38a()) {
            for (C0007e c0007e = this.f36c; c0007e != null; c0007e = c0007e.f239a) {
                switch (c0007e.f241c) {
                    case 1:
                        m24b(sparseArray, sparseArray2, c0007e.f242d);
                        break;
                    case 2:
                        C0013l c0013l = c0007e.f242d;
                        if (this.f35b.f346g != null) {
                            C0013l c0013l2 = c0013l;
                            for (int i = 0; i < this.f35b.f346g.size(); i++) {
                                C0013l c0013l3 = (C0013l) this.f35b.f346g.get(i);
                                if (c0013l2 == null || c0013l3.f264H == c0013l2.f264H) {
                                    if (c0013l3 == c0013l2) {
                                        c0013l2 = null;
                                        sparseArray2.remove(c0013l3.f264H);
                                    } else {
                                        C0003a.m20a(sparseArray, sparseArray2, c0013l3);
                                    }
                                }
                            }
                        }
                        m24b(sparseArray, sparseArray2, c0007e.f242d);
                        break;
                    case 3:
                        C0003a.m20a(sparseArray, sparseArray2, c0007e.f242d);
                        break;
                    case 4:
                        C0003a.m20a(sparseArray, sparseArray2, c0007e.f242d);
                        break;
                    case 5:
                        m24b(sparseArray, sparseArray2, c0007e.f242d);
                        break;
                    case 6:
                        C0003a.m20a(sparseArray, sparseArray2, c0007e.f242d);
                        break;
                    case 7:
                        m24b(sparseArray, sparseArray2, c0007e.f242d);
                        break;
                    default:
                        break;
                }
            }
        }
    }

    private void m24b(SparseArray sparseArray, SparseArray sparseArray2, C0013l c0013l) {
        if (c0013l != null) {
            int i = c0013l.f264H;
            if (i != 0) {
                if (!c0013l.m186g()) {
                    sparseArray2.put(i, c0013l);
                }
                if (sparseArray.get(i) == c0013l) {
                    sparseArray.remove(i);
                }
            }
            if (c0013l.f283k <= 0 && this.f35b.f353n > 0) {
                this.f35b.m262a(c0013l);
                this.f35b.m264a(c0013l, 1, 0, 0, false);
            }
        }
    }

    public final int mo1a() {
        return m7a(false);
    }

    public final ag mo2a(C0013l c0013l) {
        C0007e c0007e = new C0007e();
        c0007e.f241c = 3;
        c0007e.f242d = c0013l;
        m30a(c0007e);
        return this;
    }

    public final ag mo3a(C0013l c0013l, String str) {
        Class cls = c0013l.getClass();
        int modifiers = cls.getModifiers();
        if (cls.isAnonymousClass() || !Modifier.isPublic(modifiers) || (cls.isMemberClass() && !Modifier.isStatic(modifiers))) {
            throw new IllegalStateException("Fragment " + cls.getCanonicalName() + " must be a public static class to be  properly recreated from instance state.");
        }
        c0013l.f258B = this.f35b;
        if (str != null) {
            if (c0013l.f265I == null || str.equals(c0013l.f265I)) {
                c0013l.f265I = str;
            } else {
                throw new IllegalStateException("Can't change tag of fragment " + c0013l + ": was " + c0013l.f265I + " now " + str);
            }
        }
        C0007e c0007e = new C0007e();
        c0007e.f241c = 1;
        c0007e.f242d = c0013l;
        m30a(c0007e);
        return this;
    }

    public final C0008f m28a(boolean z, C0008f c0008f, SparseArray sparseArray, SparseArray sparseArray2) {
        if (C0025w.f339a) {
            Log.v("FragmentManager", "popFromBackStack: " + this);
            m32a("  ", new PrintWriter(new C0040e("FragmentManager")));
        }
        if (f34a && this.f35b.f353n > 0) {
            if (c0008f == null) {
                if (!(sparseArray.size() == 0 && sparseArray2.size() == 0)) {
                    c0008f = m8a(sparseArray, sparseArray2, true);
                }
            } else if (!z) {
                C0003a.m17a(c0008f, this.f55v, this.f54u);
            }
        }
        m29a(-1);
        int i = c0008f != null ? 0 : this.f44k;
        int i2 = c0008f != null ? 0 : this.f43j;
        C0007e c0007e = this.f37d;
        while (c0007e != null) {
            int i3 = c0008f != null ? 0 : c0007e.f245g;
            int i4 = c0008f != null ? 0 : c0007e.f246h;
            C0013l c0013l;
            C0013l c0013l2;
            switch (c0007e.f241c) {
                case 1:
                    c0013l = c0007e.f242d;
                    c0013l.f273Q = i4;
                    this.f35b.m263a(c0013l, C0025w.m248c(i2), i);
                    break;
                case 2:
                    c0013l = c0007e.f242d;
                    if (c0013l != null) {
                        c0013l.f273Q = i4;
                        this.f35b.m263a(c0013l, C0025w.m248c(i2), i);
                    }
                    if (c0007e.f247i == null) {
                        break;
                    }
                    for (int i5 = 0; i5 < c0007e.f247i.size(); i5++) {
                        c0013l2 = (C0013l) c0007e.f247i.get(i5);
                        c0013l2.f273Q = i3;
                        this.f35b.m265a(c0013l2, false);
                    }
                    break;
                case 3:
                    c0013l2 = c0007e.f242d;
                    c0013l2.f273Q = i3;
                    this.f35b.m265a(c0013l2, false);
                    break;
                case 4:
                    c0013l2 = c0007e.f242d;
                    c0013l2.f273Q = i3;
                    this.f35b.m280c(c0013l2, C0025w.m248c(i2), i);
                    break;
                case 5:
                    c0013l = c0007e.f242d;
                    c0013l.f273Q = i4;
                    this.f35b.m275b(c0013l, C0025w.m248c(i2), i);
                    break;
                case 6:
                    c0013l2 = c0007e.f242d;
                    c0013l2.f273Q = i3;
                    this.f35b.m285e(c0013l2, C0025w.m248c(i2), i);
                    break;
                case 7:
                    c0013l2 = c0007e.f242d;
                    c0013l2.f273Q = i3;
                    this.f35b.m283d(c0013l2, C0025w.m248c(i2), i);
                    break;
                default:
                    throw new IllegalArgumentException("Unknown cmd: " + c0007e.f241c);
            }
            c0007e = c0007e.f240b;
        }
        if (z) {
            this.f35b.m259a(this.f35b.f353n, C0025w.m248c(i2), i, true);
            c0008f = null;
        }
        if (this.f49p >= 0) {
            C0025w c0025w = this.f35b;
            i4 = this.f49p;
            synchronized (c0025w) {
                c0025w.f350k.set(i4, null);
                if (c0025w.f351l == null) {
                    c0025w.f351l = new ArrayList();
                }
                if (C0025w.f339a) {
                    Log.v("FragmentManager", "Freeing back stack index " + i4);
                }
                c0025w.f351l.add(Integer.valueOf(i4));
            }
            this.f49p = -1;
        }
        return c0008f;
    }

    final void m29a(int i) {
        if (this.f45l) {
            if (C0025w.f339a) {
                Log.v("FragmentManager", "Bump nesting in " + this + " by " + i);
            }
            for (C0007e c0007e = this.f36c; c0007e != null; c0007e = c0007e.f239a) {
                C0013l c0013l;
                if (c0007e.f242d != null) {
                    c0013l = c0007e.f242d;
                    c0013l.f257A += i;
                    if (C0025w.f339a) {
                        Log.v("FragmentManager", "Bump nesting of " + c0007e.f242d + " to " + c0007e.f242d.f257A);
                    }
                }
                if (c0007e.f247i != null) {
                    for (int size = c0007e.f247i.size() - 1; size >= 0; size--) {
                        c0013l = (C0013l) c0007e.f247i.get(size);
                        c0013l.f257A += i;
                        if (C0025w.f339a) {
                            Log.v("FragmentManager", "Bump nesting of " + c0013l + " to " + c0013l.f257A);
                        }
                    }
                }
            }
        }
    }

    final void m30a(C0007e c0007e) {
        if (this.f36c == null) {
            this.f37d = c0007e;
            this.f36c = c0007e;
        } else {
            c0007e.f240b = this.f37d;
            this.f37d.f239a = c0007e;
            this.f37d = c0007e;
        }
        c0007e.f243e = this.f39f;
        c0007e.f244f = this.f40g;
        c0007e.f245g = this.f41h;
        c0007e.f246h = this.f42i;
        this.f38e++;
    }

    public final void m31a(SparseArray sparseArray, SparseArray sparseArray2) {
        if (this.f35b.f355p.mo38a()) {
            for (C0007e c0007e = this.f37d; c0007e != null; c0007e = c0007e.f240b) {
                switch (c0007e.f241c) {
                    case 1:
                        C0003a.m20a(sparseArray, sparseArray2, c0007e.f242d);
                        break;
                    case 2:
                        if (c0007e.f247i != null) {
                            for (int size = c0007e.f247i.size() - 1; size >= 0; size--) {
                                m24b(sparseArray, sparseArray2, (C0013l) c0007e.f247i.get(size));
                            }
                        }
                        C0003a.m20a(sparseArray, sparseArray2, c0007e.f242d);
                        break;
                    case 3:
                        m24b(sparseArray, sparseArray2, c0007e.f242d);
                        break;
                    case 4:
                        m24b(sparseArray, sparseArray2, c0007e.f242d);
                        break;
                    case 5:
                        C0003a.m20a(sparseArray, sparseArray2, c0007e.f242d);
                        break;
                    case 6:
                        m24b(sparseArray, sparseArray2, c0007e.f242d);
                        break;
                    case 7:
                        C0003a.m20a(sparseArray, sparseArray2, c0007e.f242d);
                        break;
                    default:
                        break;
                }
            }
        }
    }

    public final void m32a(String str, PrintWriter printWriter) {
        m33a(str, printWriter, true);
    }

    public final void m33a(String str, PrintWriter printWriter, boolean z) {
        if (z) {
            printWriter.print(str);
            printWriter.print("mName=");
            printWriter.print(this.f47n);
            printWriter.print(" mIndex=");
            printWriter.print(this.f49p);
            printWriter.print(" mCommitted=");
            printWriter.println(this.f48o);
            if (this.f43j != 0) {
                printWriter.print(str);
                printWriter.print("mTransition=#");
                printWriter.print(Integer.toHexString(this.f43j));
                printWriter.print(" mTransitionStyle=#");
                printWriter.println(Integer.toHexString(this.f44k));
            }
            if (!(this.f39f == 0 && this.f40g == 0)) {
                printWriter.print(str);
                printWriter.print("mEnterAnim=#");
                printWriter.print(Integer.toHexString(this.f39f));
                printWriter.print(" mExitAnim=#");
                printWriter.println(Integer.toHexString(this.f40g));
            }
            if (!(this.f41h == 0 && this.f42i == 0)) {
                printWriter.print(str);
                printWriter.print("mPopEnterAnim=#");
                printWriter.print(Integer.toHexString(this.f41h));
                printWriter.print(" mPopExitAnim=#");
                printWriter.println(Integer.toHexString(this.f42i));
            }
            if (!(this.f50q == 0 && this.f51r == null)) {
                printWriter.print(str);
                printWriter.print("mBreadCrumbTitleRes=#");
                printWriter.print(Integer.toHexString(this.f50q));
                printWriter.print(" mBreadCrumbTitleText=");
                printWriter.println(this.f51r);
            }
            if (!(this.f52s == 0 && this.f53t == null)) {
                printWriter.print(str);
                printWriter.print("mBreadCrumbShortTitleRes=#");
                printWriter.print(Integer.toHexString(this.f52s));
                printWriter.print(" mBreadCrumbShortTitleText=");
                printWriter.println(this.f53t);
            }
        }
        if (this.f36c != null) {
            printWriter.print(str);
            printWriter.println("Operations:");
            String str2 = str + "    ";
            int i = 0;
            C0007e c0007e = this.f36c;
            while (c0007e != null) {
                String str3;
                switch (c0007e.f241c) {
                    case 0:
                        str3 = "NULL";
                        break;
                    case 1:
                        str3 = "ADD";
                        break;
                    case 2:
                        str3 = "REPLACE";
                        break;
                    case 3:
                        str3 = "REMOVE";
                        break;
                    case 4:
                        str3 = "HIDE";
                        break;
                    case 5:
                        str3 = "SHOW";
                        break;
                    case 6:
                        str3 = "DETACH";
                        break;
                    case 7:
                        str3 = "ATTACH";
                        break;
                    default:
                        str3 = "cmd=" + c0007e.f241c;
                        break;
                }
                printWriter.print(str);
                printWriter.print("  Op #");
                printWriter.print(i);
                printWriter.print(": ");
                printWriter.print(str3);
                printWriter.print(" ");
                printWriter.println(c0007e.f242d);
                if (z) {
                    if (!(c0007e.f243e == 0 && c0007e.f244f == 0)) {
                        printWriter.print(str);
                        printWriter.print("enterAnim=#");
                        printWriter.print(Integer.toHexString(c0007e.f243e));
                        printWriter.print(" exitAnim=#");
                        printWriter.println(Integer.toHexString(c0007e.f244f));
                    }
                    if (!(c0007e.f245g == 0 && c0007e.f246h == 0)) {
                        printWriter.print(str);
                        printWriter.print("popEnterAnim=#");
                        printWriter.print(Integer.toHexString(c0007e.f245g));
                        printWriter.print(" popExitAnim=#");
                        printWriter.println(Integer.toHexString(c0007e.f246h));
                    }
                }
                if (c0007e.f247i != null && c0007e.f247i.size() > 0) {
                    for (int i2 = 0; i2 < c0007e.f247i.size(); i2++) {
                        printWriter.print(str2);
                        if (c0007e.f247i.size() == 1) {
                            printWriter.print("Removed: ");
                        } else {
                            if (i2 == 0) {
                                printWriter.println("Removed:");
                            }
                            printWriter.print(str2);
                            printWriter.print("  #");
                            printWriter.print(i2);
                            printWriter.print(": ");
                        }
                        printWriter.println(c0007e.f247i.get(i2));
                    }
                }
                c0007e = c0007e.f239a;
                i++;
            }
        }
    }

    public final int mo4b() {
        return m7a(true);
    }

    public final void run() {
        if (C0025w.f339a) {
            Log.v("FragmentManager", "Run: " + this);
        }
        if (!this.f45l || this.f49p >= 0) {
            C0008f c0008f;
            m29a(1);
            if (!f34a || this.f35b.f353n <= 0) {
                c0008f = null;
            } else {
                SparseArray sparseArray = new SparseArray();
                SparseArray sparseArray2 = new SparseArray();
                m23b(sparseArray, sparseArray2);
                c0008f = m8a(sparseArray, sparseArray2, false);
            }
            int i = c0008f != null ? 0 : this.f44k;
            int i2 = c0008f != null ? 0 : this.f43j;
            C0007e c0007e = this.f36c;
            while (c0007e != null) {
                int i3 = c0008f != null ? 0 : c0007e.f243e;
                int i4 = c0008f != null ? 0 : c0007e.f244f;
                C0013l c0013l;
                switch (c0007e.f241c) {
                    case 1:
                        c0013l = c0007e.f242d;
                        c0013l.f273Q = i3;
                        this.f35b.m265a(c0013l, false);
                        break;
                    case 2:
                        C0013l c0013l2 = c0007e.f242d;
                        int i5 = c0013l2.f264H;
                        if (this.f35b.f346g != null) {
                            int size = this.f35b.f346g.size() - 1;
                            while (size >= 0) {
                                c0013l = (C0013l) this.f35b.f346g.get(size);
                                if (C0025w.f339a) {
                                    Log.v("FragmentManager", "OP_REPLACE: adding=" + c0013l2 + " old=" + c0013l);
                                }
                                if (c0013l.f264H == i5) {
                                    if (c0013l == c0013l2) {
                                        c0013l = null;
                                        c0007e.f242d = null;
                                        size--;
                                        c0013l2 = c0013l;
                                    } else {
                                        if (c0007e.f247i == null) {
                                            c0007e.f247i = new ArrayList();
                                        }
                                        c0007e.f247i.add(c0013l);
                                        c0013l.f273Q = i4;
                                        if (this.f45l) {
                                            c0013l.f257A++;
                                            if (C0025w.f339a) {
                                                Log.v("FragmentManager", "Bump nesting of " + c0013l + " to " + c0013l.f257A);
                                            }
                                        }
                                        this.f35b.m263a(c0013l, i2, i);
                                    }
                                }
                                c0013l = c0013l2;
                                size--;
                                c0013l2 = c0013l;
                            }
                        }
                        if (c0013l2 == null) {
                            break;
                        }
                        c0013l2.f273Q = i3;
                        this.f35b.m265a(c0013l2, false);
                        break;
                    case 3:
                        c0013l = c0007e.f242d;
                        c0013l.f273Q = i4;
                        this.f35b.m263a(c0013l, i2, i);
                        break;
                    case 4:
                        c0013l = c0007e.f242d;
                        c0013l.f273Q = i4;
                        this.f35b.m275b(c0013l, i2, i);
                        break;
                    case 5:
                        c0013l = c0007e.f242d;
                        c0013l.f273Q = i3;
                        this.f35b.m280c(c0013l, i2, i);
                        break;
                    case 6:
                        c0013l = c0007e.f242d;
                        c0013l.f273Q = i4;
                        this.f35b.m283d(c0013l, i2, i);
                        break;
                    case 7:
                        c0013l = c0007e.f242d;
                        c0013l.f273Q = i3;
                        this.f35b.m285e(c0013l, i2, i);
                        break;
                    default:
                        throw new IllegalArgumentException("Unknown cmd: " + c0007e.f241c);
                }
                c0007e = c0007e.f239a;
            }
            this.f35b.m259a(this.f35b.f353n, i2, i, true);
            if (this.f45l) {
                C0025w c0025w = this.f35b;
                if (c0025w.f348i == null) {
                    c0025w.f348i = new ArrayList();
                }
                c0025w.f348i.add(this);
                c0025w.m282d();
                return;
            }
            return;
        }
        throw new IllegalStateException("addToBackStack() called after commit()");
    }

    public final String toString() {
        StringBuilder stringBuilder = new StringBuilder(128);
        stringBuilder.append("BackStackEntry{");
        stringBuilder.append(Integer.toHexString(System.identityHashCode(this)));
        if (this.f49p >= 0) {
            stringBuilder.append(" #");
            stringBuilder.append(this.f49p);
        }
        if (this.f47n != null) {
            stringBuilder.append(" ");
            stringBuilder.append(this.f47n);
        }
        stringBuilder.append("}");
        return stringBuilder.toString();
    }
}
