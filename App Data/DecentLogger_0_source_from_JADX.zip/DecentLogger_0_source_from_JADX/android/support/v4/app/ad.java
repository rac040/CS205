package android.support.v4.app;

import java.util.List;

public final class ad {
    final List f61a;
    final List f62b;

    ad(List list, List list2) {
        this.f61a = list;
        this.f62b = list2;
    }
}
