package android.support.v4.app;

public abstract class ag {
    public abstract int mo1a();

    public abstract ag mo2a(C0013l c0013l);

    public abstract ag mo3a(C0013l c0013l, String str);

    public abstract int mo4b();
}
