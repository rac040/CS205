package android.support.v4.app;

final class ac {
    public static final int[] f60a = new int[]{16842755, 16842960, 16842961};
}
