package android.support.v4.app;

public final class C0017n extends RuntimeException {
    public C0017n(String str, Exception exception) {
        super(str, exception);
    }
}
