package android.support.v4.app;

import android.os.Bundle;

public final class cj {
    public final String f228a;
    public CharSequence f229b;
    public CharSequence[] f230c;
    public boolean f231d = true;
    public Bundle f232e = new Bundle();

    public cj(String str) {
        this.f228a = str;
    }
}
