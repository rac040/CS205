package android.support.v4.app;

import android.app.Notification;

class bj extends bi {
    bj() {
    }

    public Notification mo14a(bb bbVar) {
        au bvVar = new bv(bbVar.f138a, bbVar.f136F, bbVar.f139b, bbVar.f140c, bbVar.f145h, bbVar.f143f, bbVar.f146i, bbVar.f141d, bbVar.f142e, bbVar.f144g, bbVar.f153p, bbVar.f154q, bbVar.f155r, bbVar.f148k, bbVar.f149l, bbVar.f147j, bbVar.f151n, bbVar.f160w, bbVar.f161x, bbVar.f137G, bbVar.f162y, bbVar.f163z, bbVar.f131A, bbVar.f132B, bbVar.f156s, bbVar.f157t, bbVar.f158u, bbVar.f133C, bbVar.f134D, bbVar.f135E);
        av.m71a((at) bvVar, bbVar.f159v);
        av.m74c(bvVar, bbVar.f150m);
        Notification b = bvVar.mo20b();
        if (bbVar.f150m != null) {
            bbVar.f150m.mo13a(b.extras);
        }
        return b;
    }
}
