package android.support.v4.app;

import android.transition.Transition;
import android.view.View;
import android.view.ViewTreeObserver.OnPreDrawListener;
import java.util.ArrayList;
import java.util.Map;
import java.util.Map.Entry;

final class aj implements OnPreDrawListener {
    final /* synthetic */ View f64a;
    final /* synthetic */ Transition f65b;
    final /* synthetic */ View f66c;
    final /* synthetic */ an f67d;
    final /* synthetic */ Map f68e;
    final /* synthetic */ Map f69f;
    final /* synthetic */ ArrayList f70g;
    final /* synthetic */ Transition f71h;

    aj(View view, Transition transition, View view2, an anVar, Map map, Map map2, ArrayList arrayList, Transition transition2) {
        this.f64a = view;
        this.f65b = transition;
        this.f66c = view2;
        this.f67d = anVar;
        this.f68e = map;
        this.f69f = map2;
        this.f70g = arrayList;
        this.f71h = transition2;
    }

    public final boolean onPreDraw() {
        this.f64a.getViewTreeObserver().removeOnPreDrawListener(this);
        if (this.f65b != null) {
            this.f65b.removeTarget(this.f66c);
        }
        if (this.f67d != null) {
            View a = this.f67d.mo12a();
            if (a != null) {
                if (!this.f68e.isEmpty()) {
                    ah.m45a(this.f69f, a);
                    this.f69f.keySet().retainAll(this.f68e.values());
                    for (Entry entry : this.f68e.entrySet()) {
                        View view = (View) this.f69f.get((String) entry.getValue());
                        if (view != null) {
                            view.setTransitionName((String) entry.getKey());
                        }
                    }
                }
                if (this.f65b != null) {
                    ah.m44a(this.f70g, a);
                    this.f70g.removeAll(this.f69f.values());
                    this.f70g.add(this.f66c);
                    ah.m49b(this.f65b, this.f70g);
                }
            }
        }
        ah.m38a(this.f71h, this.f65b, this.f70g, true);
        return true;
    }
}
