package android.support.v4.app;

import android.view.View;
import android.view.animation.Animation;

final class C0028z extends aa {
    final /* synthetic */ C0013l f369a;
    final /* synthetic */ C0025w f370b;

    C0028z(C0025w c0025w, View view, Animation animation, C0013l c0013l) {
        this.f370b = c0025w;
        this.f369a = c0013l;
        super(view, animation);
    }

    public final void onAnimationEnd(Animation animation) {
        super.onAnimationEnd(animation);
        if (this.f369a.f284l != null) {
            this.f369a.f284l = null;
            this.f370b.m264a(this.f369a, this.f369a.f285m, 0, 0, false);
        }
    }
}
