package android.support.v4.app;

import android.app.Notification;
import java.util.ArrayList;

class bi extends bp {
    bi() {
    }

    public Notification mo14a(bb bbVar) {
        au btVar = new bt(bbVar.f138a, bbVar.f136F, bbVar.f139b, bbVar.f140c, bbVar.f145h, bbVar.f143f, bbVar.f146i, bbVar.f141d, bbVar.f142e, bbVar.f144g, bbVar.f153p, bbVar.f154q, bbVar.f155r, bbVar.f148k, bbVar.f149l, bbVar.f147j, bbVar.f151n, bbVar.f160w, bbVar.f137G, bbVar.f162y, bbVar.f156s, bbVar.f157t, bbVar.f158u, bbVar.f133C, bbVar.f134D);
        av.m71a((at) btVar, bbVar.f159v);
        av.m74c(btVar, bbVar.f150m);
        Notification b = btVar.mo20b();
        if (bbVar.f150m != null) {
            bbVar.f150m.mo13a(b.extras);
        }
        return b;
    }

    public final ArrayList mo15a(aw[] awVarArr) {
        if (awVarArr == null) {
            return null;
        }
        ArrayList arrayList = new ArrayList(awVarArr.length);
        for (bz a : awVarArr) {
            arrayList.add(bs.m116a(a));
        }
        return arrayList;
    }
}
