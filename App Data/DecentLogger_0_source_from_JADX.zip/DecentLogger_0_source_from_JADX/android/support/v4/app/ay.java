package android.support.v4.app;

import android.app.PendingIntent;
import android.os.Bundle;
import blueguy.decentlogger.R;
import java.util.ArrayList;

public final class ay {
    public final int f116a;
    public final CharSequence f117b;
    public final PendingIntent f118c;
    public boolean f119d;
    public final Bundle f120e;
    public ArrayList f121f;

    public ay(CharSequence charSequence, PendingIntent pendingIntent) {
        this(charSequence, pendingIntent, new Bundle());
    }

    private ay(CharSequence charSequence, PendingIntent pendingIntent, Bundle bundle) {
        this.f116a = R.drawable.open_on_phone;
        this.f117b = bb.m89d(charSequence);
        this.f118c = pendingIntent;
        this.f120e = bundle;
    }
}
