package android.support.v4.app;

import android.app.Activity;
import android.content.Context;
import android.os.Handler;
import android.support.v4.p002c.C0034l;
import android.view.LayoutInflater;
import android.view.View;
import java.io.PrintWriter;

public abstract class C0020u extends C0015s {
    final Activity f320b;
    final Context f321c;
    final Handler f322d;
    final int f323e;
    public final C0025w f324f;
    C0034l f325g;
    boolean f326h;
    aq f327i;
    boolean f328j;
    boolean f329k;

    private C0020u(Activity activity, Context context, Handler handler) {
        this.f324f = new C0025w();
        this.f320b = activity;
        this.f321c = context;
        this.f322d = handler;
        this.f323e = 0;
    }

    C0020u(C0018o c0018o) {
        this(c0018o, c0018o, c0018o.f309c);
    }

    public View mo37a(int i) {
        return null;
    }

    final void m212a(String str) {
        if (this.f325g != null) {
            aq aqVar = (aq) this.f325g.get(str);
            if (aqVar != null && !aqVar.f91f) {
                aqVar.m61g();
                this.f325g.remove(str);
            }
        }
    }

    public void mo46a(String str, PrintWriter printWriter, String[] strArr) {
    }

    public boolean mo38a() {
        return true;
    }

    final aq m215b(String str) {
        if (this.f325g == null) {
            this.f325g = new C0034l();
        }
        aq aqVar = (aq) this.f325g.get(str);
        if (aqVar != null) {
            aqVar.f92g = this;
        }
        return aqVar;
    }

    public boolean mo47b() {
        return true;
    }

    public LayoutInflater mo48c() {
        return (LayoutInflater) this.f321c.getSystemService("layout_inflater");
    }

    public void mo49d() {
    }

    public boolean mo50e() {
        return true;
    }

    public int mo51f() {
        return this.f323e;
    }
}
