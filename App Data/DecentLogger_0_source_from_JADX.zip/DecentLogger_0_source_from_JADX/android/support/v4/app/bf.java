package android.support.v4.app;

import android.os.Bundle;
import android.os.Parcelable;
import java.util.ArrayList;
import java.util.List;

public final class bf extends bq {
    CharSequence f165a;
    CharSequence f166b;
    List f167c = new ArrayList();

    bf() {
    }

    public final void mo13a(Bundle bundle) {
        super.mo13a(bundle);
        if (this.f165a != null) {
            bundle.putCharSequence("android.selfDisplayName", this.f165a);
        }
        if (this.f166b != null) {
            bundle.putCharSequence("android.conversationTitle", this.f166b);
        }
        if (!this.f167c.isEmpty()) {
            String str = "android.messages";
            List list = this.f167c;
            Parcelable[] parcelableArr = new Bundle[list.size()];
            int size = list.size();
            for (int i = 0; i < size; i++) {
                bg bgVar = (bg) list.get(i);
                Bundle bundle2 = new Bundle();
                if (bgVar.f168a != null) {
                    bundle2.putCharSequence("text", bgVar.f168a);
                }
                bundle2.putLong("time", bgVar.f169b);
                if (bgVar.f170c != null) {
                    bundle2.putCharSequence("sender", bgVar.f170c);
                }
                if (bgVar.f171d != null) {
                    bundle2.putString("type", bgVar.f171d);
                }
                if (bgVar.f172e != null) {
                    bundle2.putParcelable("uri", bgVar.f172e);
                }
                parcelableArr[i] = bundle2;
            }
            bundle.putParcelableArray(str, parcelableArr);
        }
    }
}
