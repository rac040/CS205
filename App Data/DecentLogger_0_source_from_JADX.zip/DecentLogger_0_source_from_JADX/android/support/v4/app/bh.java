package android.support.v4.app;

import android.app.Notification;
import java.util.ArrayList;

interface bh {
    Notification mo14a(bb bbVar);

    ArrayList mo15a(aw[] awVarArr);
}
