package android.support.v4.app;

import android.view.View;
import android.view.ViewTreeObserver.OnPreDrawListener;

final class C0006d implements OnPreDrawListener {
    final /* synthetic */ View f234a;
    final /* synthetic */ C0008f f235b;
    final /* synthetic */ int f236c;
    final /* synthetic */ Object f237d;
    final /* synthetic */ C0003a f238e;

    C0006d(C0003a c0003a, View view, C0008f c0008f, int i, Object obj) {
        this.f238e = c0003a;
        this.f234a = view;
        this.f235b = c0008f;
        this.f236c = i;
        this.f237d = obj;
    }

    public final boolean onPreDraw() {
        this.f234a.getViewTreeObserver().removeOnPreDrawListener(this);
        this.f238e.m15a(this.f235b, this.f236c, this.f237d);
        return true;
    }
}
