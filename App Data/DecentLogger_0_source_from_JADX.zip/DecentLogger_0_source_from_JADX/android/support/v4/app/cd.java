package android.support.v4.app;

import android.app.Notification;
import android.app.Notification.BigPictureStyle;
import android.app.Notification.BigTextStyle;
import android.app.Notification.Builder;
import android.app.Notification.InboxStyle;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.util.Log;
import android.util.SparseArray;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

final class cd {
    private static final Object f207a = new Object();
    private static Field f208b;
    private static boolean f209c;
    private static final Object f210d = new Object();

    public static Bundle m130a(Builder builder, bz bzVar) {
        builder.addAction(bzVar.mo6a(), bzVar.mo7b(), bzVar.mo8c());
        Bundle bundle = new Bundle(bzVar.mo9d());
        if (bzVar.mo11f() != null) {
            bundle.putParcelableArray("android.support.remoteInputs", cs.m159a(bzVar.mo11f()));
        }
        bundle.putBoolean("android.support.allowGeneratedReplies", bzVar.mo10e());
        return bundle;
    }

    public static Bundle m131a(Notification notification) {
        synchronized (f207a) {
            if (f209c) {
                return null;
            }
            try {
                if (f208b == null) {
                    Field declaredField = Notification.class.getDeclaredField("extras");
                    if (Bundle.class.isAssignableFrom(declaredField.getType())) {
                        declaredField.setAccessible(true);
                        f208b = declaredField;
                    } else {
                        Log.e("NotificationCompat", "Notification.extras field is not of type Bundle");
                        f209c = true;
                        return null;
                    }
                }
                Bundle bundle = (Bundle) f208b.get(notification);
                if (bundle == null) {
                    bundle = new Bundle();
                    f208b.set(notification, bundle);
                }
                return bundle;
            } catch (Throwable e) {
                Log.e("NotificationCompat", "Unable to access notification extras", e);
                f209c = true;
                return null;
            } catch (Throwable e2) {
                Log.e("NotificationCompat", "Unable to access notification extras", e2);
                f209c = true;
                return null;
            }
        }
    }

    public static SparseArray m132a(List list) {
        SparseArray sparseArray = null;
        int size = list.size();
        for (int i = 0; i < size; i++) {
            Bundle bundle = (Bundle) list.get(i);
            if (bundle != null) {
                if (sparseArray == null) {
                    sparseArray = new SparseArray();
                }
                sparseArray.put(i, bundle);
            }
        }
        return sparseArray;
    }

    public static ArrayList m133a(bz[] bzVarArr) {
        if (bzVarArr == null) {
            return null;
        }
        ArrayList arrayList = new ArrayList(bzVarArr.length);
        for (bz bzVar : bzVarArr) {
            Bundle bundle = new Bundle();
            bundle.putInt("icon", bzVar.mo6a());
            bundle.putCharSequence("title", bzVar.mo7b());
            bundle.putParcelable("actionIntent", bzVar.mo8c());
            bundle.putBundle("extras", bzVar.mo9d());
            bundle.putParcelableArray("remoteInputs", cs.m159a(bzVar.mo11f()));
            arrayList.add(bundle);
        }
        return arrayList;
    }

    public static void m134a(au auVar, CharSequence charSequence, boolean z, CharSequence charSequence2, Bitmap bitmap, Bitmap bitmap2, boolean z2) {
        BigPictureStyle bigPicture = new BigPictureStyle(auVar.mo18a()).setBigContentTitle(charSequence).bigPicture(bitmap);
        if (z2) {
            bigPicture.bigLargeIcon(bitmap2);
        }
        if (z) {
            bigPicture.setSummaryText(charSequence2);
        }
    }

    public static void m135a(au auVar, CharSequence charSequence, boolean z, CharSequence charSequence2, CharSequence charSequence3) {
        BigTextStyle bigText = new BigTextStyle(auVar.mo18a()).setBigContentTitle(charSequence).bigText(charSequence3);
        if (z) {
            bigText.setSummaryText(charSequence2);
        }
    }

    public static void m136a(au auVar, CharSequence charSequence, boolean z, CharSequence charSequence2, ArrayList arrayList) {
        InboxStyle bigContentTitle = new InboxStyle(auVar.mo18a()).setBigContentTitle(charSequence);
        if (z) {
            bigContentTitle.setSummaryText(charSequence2);
        }
        Iterator it = arrayList.iterator();
        while (it.hasNext()) {
            bigContentTitle.addLine((CharSequence) it.next());
        }
    }
}
