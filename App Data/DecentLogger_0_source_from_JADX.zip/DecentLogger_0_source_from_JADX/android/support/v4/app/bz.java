package android.support.v4.app;

import android.app.PendingIntent;
import android.os.Bundle;

public abstract class bz {
    public abstract int mo6a();

    public abstract CharSequence mo7b();

    public abstract PendingIntent mo8c();

    public abstract Bundle mo9d();

    public abstract boolean mo10e();

    public abstract cq[] mo11f();
}
