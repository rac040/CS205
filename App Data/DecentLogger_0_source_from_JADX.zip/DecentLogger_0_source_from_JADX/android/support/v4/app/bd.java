package android.support.v4.app;

public interface bd {
    bb mo17a(bb bbVar);
}
