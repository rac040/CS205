package android.support.v4.app;

import android.transition.Transition;
import android.view.View;
import android.view.ViewTreeObserver.OnPreDrawListener;
import java.util.ArrayList;
import java.util.Map;
import java.util.Map.Entry;

final class al implements OnPreDrawListener {
    final /* synthetic */ View f74a;
    final /* synthetic */ Transition f75b;
    final /* synthetic */ ArrayList f76c;
    final /* synthetic */ Transition f77d;
    final /* synthetic */ ArrayList f78e;
    final /* synthetic */ Transition f79f;
    final /* synthetic */ ArrayList f80g;
    final /* synthetic */ Map f81h;
    final /* synthetic */ ArrayList f82i;
    final /* synthetic */ Transition f83j;
    final /* synthetic */ View f84k;

    al(View view, Transition transition, ArrayList arrayList, Transition transition2, ArrayList arrayList2, Transition transition3, ArrayList arrayList3, Map map, ArrayList arrayList4, Transition transition4, View view2) {
        this.f74a = view;
        this.f75b = transition;
        this.f76c = arrayList;
        this.f77d = transition2;
        this.f78e = arrayList2;
        this.f79f = transition3;
        this.f80g = arrayList3;
        this.f81h = map;
        this.f82i = arrayList4;
        this.f83j = transition4;
        this.f84k = view2;
    }

    public final boolean onPreDraw() {
        this.f74a.getViewTreeObserver().removeOnPreDrawListener(this);
        if (this.f75b != null) {
            ah.m43a(this.f75b, this.f76c);
            ah.m38a(this.f75b, this.f77d, this.f78e, false);
            ah.m38a(this.f75b, this.f79f, this.f80g, false);
        }
        if (this.f77d != null) {
            ah.m43a(this.f77d, this.f78e);
            ah.m38a(this.f77d, this.f75b, this.f76c, false);
            ah.m38a(this.f77d, this.f79f, this.f80g, false);
        }
        if (this.f79f != null) {
            ah.m43a(this.f79f, this.f80g);
        }
        for (Entry entry : this.f81h.entrySet()) {
            ((View) entry.getValue()).setTransitionName((String) entry.getKey());
        }
        int size = this.f82i.size();
        for (int i = 0; i < size; i++) {
            this.f83j.excludeTarget((View) this.f82i.get(i), false);
        }
        this.f83j.excludeTarget(this.f84k, false);
        return true;
    }
}
