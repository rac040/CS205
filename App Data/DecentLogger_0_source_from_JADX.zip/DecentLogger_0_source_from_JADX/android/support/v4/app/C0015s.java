package android.support.v4.app;

import android.view.View;

public abstract class C0015s {
    public abstract View mo37a(int i);

    public abstract boolean mo38a();
}
