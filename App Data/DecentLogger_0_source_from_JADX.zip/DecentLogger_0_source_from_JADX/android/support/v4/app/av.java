package android.support.v4.app;

import android.os.Build.VERSION;
import android.support.v4.p001b.C0029a;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public final class av {
    private static final bh f108a;

    static {
        if (C0029a.m294a()) {
            f108a = new bk();
        } else if (VERSION.SDK_INT >= 21) {
            f108a = new bj();
        } else if (VERSION.SDK_INT >= 20) {
            f108a = new bi();
        } else if (VERSION.SDK_INT >= 19) {
            f108a = new bp();
        } else if (VERSION.SDK_INT >= 16) {
            f108a = new bo();
        } else if (VERSION.SDK_INT >= 14) {
            f108a = new bn();
        } else if (VERSION.SDK_INT >= 11) {
            f108a = new bm();
        } else {
            f108a = new bl();
        }
    }

    static /* synthetic */ void m71a(at atVar, ArrayList arrayList) {
        Iterator it = arrayList.iterator();
        while (it.hasNext()) {
            atVar.mo19a((aw) it.next());
        }
    }

    static /* synthetic */ void m73b(au auVar, bq bqVar) {
        if (bqVar == null) {
            return;
        }
        if (bqVar instanceof bf) {
            bf bfVar = (bf) bqVar;
            List arrayList = new ArrayList();
            List arrayList2 = new ArrayList();
            List arrayList3 = new ArrayList();
            List arrayList4 = new ArrayList();
            List arrayList5 = new ArrayList();
            for (bg bgVar : bfVar.f167c) {
                arrayList.add(bgVar.f168a);
                arrayList2.add(Long.valueOf(bgVar.f169b));
                arrayList3.add(bgVar.f170c);
                arrayList4.add(bgVar.f171d);
                arrayList5.add(bgVar.f172e);
            }
            bw.m124a(auVar, bfVar.f165a, bfVar.f166b, arrayList, arrayList2, arrayList3, arrayList4, arrayList5);
            return;
        }
        m74c(auVar, bqVar);
    }

    private static void m74c(au auVar, bq bqVar) {
        if (bqVar == null) {
            return;
        }
        if (bqVar instanceof ba) {
            ba baVar = (ba) bqVar;
            cd.m135a(auVar, baVar.d, baVar.f, baVar.e, baVar.f130a);
        } else if (bqVar instanceof be) {
            be beVar = (be) bqVar;
            cd.m136a(auVar, beVar.d, beVar.f, beVar.e, beVar.f164a);
        } else if (bqVar instanceof az) {
            az azVar = (az) bqVar;
            cd.m134a(auVar, azVar.d, azVar.f, azVar.e, azVar.f125a, azVar.f126b, azVar.f127c);
        }
    }
}
