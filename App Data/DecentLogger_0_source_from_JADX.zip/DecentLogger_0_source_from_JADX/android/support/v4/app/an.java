package android.support.v4.app;

import android.view.View;

public interface an {
    View mo12a();
}
