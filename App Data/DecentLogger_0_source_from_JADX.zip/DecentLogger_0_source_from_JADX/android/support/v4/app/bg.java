package android.support.v4.app;

import android.net.Uri;

public final class bg {
    final CharSequence f168a;
    final long f169b;
    final CharSequence f170c;
    String f171d;
    Uri f172e;
}
