package android.support.v4.app;

import android.support.v4.p001b.C0029a;
import android.support.v4.view.ao;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.Animation.AnimationListener;

class aa implements AnimationListener {
    private AnimationListener f56a;
    private boolean f57b;
    private View f58c;

    public aa(View view, Animation animation) {
        if (view != null && animation != null) {
            this.f58c = view;
        }
    }

    public aa(View view, Animation animation, AnimationListener animationListener) {
        if (view != null && animation != null) {
            this.f56a = animationListener;
            this.f58c = view;
            this.f57b = true;
        }
    }

    public void onAnimationEnd(Animation animation) {
        if (this.f58c != null && this.f57b) {
            if (ao.m529g(this.f58c) || C0029a.m294a()) {
                this.f58c.post(new ab(this));
            } else {
                ao.m524b(this.f58c, 0);
            }
        }
        if (this.f56a != null) {
            this.f56a.onAnimationEnd(animation);
        }
    }

    public void onAnimationRepeat(Animation animation) {
        if (this.f56a != null) {
            this.f56a.onAnimationRepeat(animation);
        }
    }

    public void onAnimationStart(Animation animation) {
        if (this.f56a != null) {
            this.f56a.onAnimationStart(animation);
        }
    }
}
