package android.support.v4.app;

import android.app.Notification;

final class bn extends bl {
    bn() {
    }

    public final Notification mo14a(bb bbVar) {
        Notification b = new cc(bbVar.f138a, bbVar.f136F, bbVar.f139b, bbVar.f140c, bbVar.f145h, bbVar.f143f, bbVar.f146i, bbVar.f141d, bbVar.f142e, bbVar.f144g, bbVar.f153p, bbVar.f154q, bbVar.f155r).mo20b();
        if (bbVar.f133C != null) {
            b.contentView = bbVar.f133C;
        }
        return b;
    }
}
