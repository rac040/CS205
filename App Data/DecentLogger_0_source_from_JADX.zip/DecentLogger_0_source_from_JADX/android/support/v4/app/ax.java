package android.support.v4.app;

final class ax implements ca {
    ax() {
    }
}
