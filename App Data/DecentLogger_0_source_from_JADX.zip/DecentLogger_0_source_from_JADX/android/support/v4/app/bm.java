package android.support.v4.app;

import android.app.Notification;
import android.app.Notification.Builder;
import android.app.PendingIntent;
import android.content.Context;
import android.widget.RemoteViews;

final class bm extends bl {
    bm() {
    }

    public final Notification mo14a(bb bbVar) {
        Context context = bbVar.f138a;
        Notification notification = bbVar.f136F;
        CharSequence charSequence = bbVar.f139b;
        CharSequence charSequence2 = bbVar.f140c;
        CharSequence charSequence3 = bbVar.f145h;
        RemoteViews remoteViews = bbVar.f143f;
        int i = bbVar.f146i;
        PendingIntent pendingIntent = bbVar.f141d;
        Notification notification2 = new Builder(context).setWhen(notification.when).setSmallIcon(notification.icon, notification.iconLevel).setContent(notification.contentView).setTicker(notification.tickerText, remoteViews).setSound(notification.sound, notification.audioStreamType).setVibrate(notification.vibrate).setLights(notification.ledARGB, notification.ledOnMS, notification.ledOffMS).setOngoing((notification.flags & 2) != 0).setOnlyAlertOnce((notification.flags & 8) != 0).setAutoCancel((notification.flags & 16) != 0).setDefaults(notification.defaults).setContentTitle(charSequence).setContentText(charSequence2).setContentInfo(charSequence3).setContentIntent(pendingIntent).setDeleteIntent(notification.deleteIntent).setFullScreenIntent(bbVar.f142e, (notification.flags & 128) != 0).setLargeIcon(bbVar.f144g).setNumber(i).getNotification();
        if (bbVar.f133C != null) {
            notification2.contentView = bbVar.f133C;
        }
        return notification2;
    }
}
