package android.support.v4.app;

import android.content.Intent;
import android.os.Bundle;

interface ck {
    Bundle mo26a(Intent intent);
}
