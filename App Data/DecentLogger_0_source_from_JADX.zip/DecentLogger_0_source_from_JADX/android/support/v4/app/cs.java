package android.support.v4.app;

import android.os.Bundle;

final class cs {
    static Bundle[] m159a(cq[] cqVarArr) {
        if (cqVarArr == null) {
            return null;
        }
        Bundle[] bundleArr = new Bundle[cqVarArr.length];
        for (int i = 0; i < cqVarArr.length; i++) {
            cq cqVar = cqVarArr[i];
            Bundle bundle = new Bundle();
            bundle.putString("resultKey", cqVar.mo21a());
            bundle.putCharSequence("label", cqVar.mo22b());
            bundle.putCharSequenceArray("choices", cqVar.mo23c());
            bundle.putBoolean("allowFreeFormInput", cqVar.mo24d());
            bundle.putBundle("extras", cqVar.mo25e());
            bundleArr[i] = bundle;
        }
        return bundleArr;
    }
}
