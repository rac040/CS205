package android.support.v4.app;

final class ci implements cr {
    ci() {
    }
}
