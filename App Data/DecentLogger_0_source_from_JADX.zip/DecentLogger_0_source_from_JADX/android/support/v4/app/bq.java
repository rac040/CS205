package android.support.v4.app;

import android.os.Bundle;

public abstract class bq {
    CharSequence f122d;
    CharSequence f123e;
    boolean f124f = false;

    public void mo13a(Bundle bundle) {
    }
}
