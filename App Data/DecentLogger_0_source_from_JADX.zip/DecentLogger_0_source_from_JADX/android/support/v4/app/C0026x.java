package android.support.v4.app;

final class C0026x implements Runnable {
    final /* synthetic */ C0025w f365a;

    C0026x(C0025w c0025w) {
        this.f365a = c0025w;
    }

    public final void run() {
        this.f365a.m281c();
    }
}
