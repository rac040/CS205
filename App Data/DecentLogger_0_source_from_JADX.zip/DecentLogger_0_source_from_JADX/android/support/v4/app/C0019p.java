package android.support.v4.app;

import android.os.Handler;
import android.os.Message;

final class C0019p extends Handler {
    final /* synthetic */ C0018o f319a;

    C0019p(C0018o c0018o) {
        this.f319a = c0018o;
    }

    public final void handleMessage(Message message) {
        switch (message.what) {
            case 1:
                if (this.f319a.f313g) {
                    this.f319a.m210a(false);
                    return;
                }
                return;
            case 2:
                this.f319a.m209a();
                this.f319a.f310d.m232b();
                return;
            default:
                super.handleMessage(message);
                return;
        }
    }
}
