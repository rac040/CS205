package android.support.v4.app;

import android.app.Notification;
import android.app.PendingIntent;
import android.content.Context;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.widget.RemoteViews;
import java.util.ArrayList;

public final class bb {
    int f131A = 0;
    Notification f132B;
    RemoteViews f133C;
    RemoteViews f134D;
    RemoteViews f135E;
    public Notification f136F = new Notification();
    public ArrayList f137G;
    public Context f138a;
    public CharSequence f139b;
    public CharSequence f140c;
    public PendingIntent f141d;
    PendingIntent f142e;
    RemoteViews f143f;
    public Bitmap f144g;
    public CharSequence f145h;
    public int f146i;
    public int f147j;
    boolean f148k = true;
    public boolean f149l;
    public bq f150m;
    public CharSequence f151n;
    public CharSequence[] f152o;
    int f153p;
    int f154q;
    boolean f155r;
    String f156s;
    boolean f157t;
    String f158u;
    public ArrayList f159v = new ArrayList();
    boolean f160w = false;
    String f161x;
    Bundle f162y;
    int f163z = 0;

    public bb(Context context) {
        this.f138a = context;
        this.f136F.when = System.currentTimeMillis();
        this.f136F.audioStreamType = -1;
        this.f147j = 0;
        this.f137G = new ArrayList();
    }

    protected static CharSequence m89d(CharSequence charSequence) {
        return (charSequence != null && charSequence.length() > 5120) ? charSequence.subSequence(0, 5120) : charSequence;
    }

    public final Notification m90a() {
        bh a = av.f108a;
        bc bcVar = new bc();
        return a.mo14a(this);
    }

    public final bb m91a(int i) {
        this.f136F.icon = i;
        return this;
    }

    public final bb m92a(long j) {
        this.f136F.when = j;
        return this;
    }

    public final bb m93a(CharSequence charSequence) {
        this.f139b = m89d(charSequence);
        return this;
    }

    public final bb m94b(CharSequence charSequence) {
        this.f140c = m89d(charSequence);
        return this;
    }

    public final bb m95c(CharSequence charSequence) {
        this.f136F.tickerText = m89d(charSequence);
        return this;
    }
}
