package android.support.v4.app;

public abstract class ct {
    private static int f233a = 1048576;
}
