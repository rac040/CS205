package android.support.v4.app;

import android.content.Intent;
import android.os.Build.VERSION;
import android.os.Bundle;

public final class ch extends cq {
    public static final cr f221a = new ci();
    private static final ck f222g;
    private final String f223b;
    private final CharSequence f224c;
    private final CharSequence[] f225d;
    private final boolean f226e;
    private final Bundle f227f;

    static {
        if (VERSION.SDK_INT >= 20) {
            f222g = new cl();
        } else if (VERSION.SDK_INT >= 16) {
            f222g = new cn();
        } else {
            f222g = new cm();
        }
    }

    private ch(String str, CharSequence charSequence, CharSequence[] charSequenceArr, boolean z, Bundle bundle) {
        this.f223b = str;
        this.f224c = charSequence;
        this.f225d = charSequenceArr;
        this.f226e = z;
        this.f227f = bundle;
    }

    public static Bundle m148a(Intent intent) {
        return f222g.mo26a(intent);
    }

    public final String mo21a() {
        return this.f223b;
    }

    public final CharSequence mo22b() {
        return this.f224c;
    }

    public final CharSequence[] mo23c() {
        return this.f225d;
    }

    public final boolean mo24d() {
        return this.f226e;
    }

    public final Bundle mo25e() {
        return this.f227f;
    }
}
