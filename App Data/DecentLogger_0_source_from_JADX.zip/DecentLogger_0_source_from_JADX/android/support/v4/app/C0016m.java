package android.support.v4.app;

import android.view.View;

final class C0016m extends C0015s {
    final /* synthetic */ C0013l f308a;

    C0016m(C0013l c0013l) {
        this.f308a = c0013l;
    }

    public final View mo37a(int i) {
        if (this.f308a.f275S != null) {
            return this.f308a.f275S.findViewById(i);
        }
        throw new IllegalStateException("Fragment does not have a view");
    }

    public final boolean mo38a() {
        return this.f308a.f275S != null;
    }
}
