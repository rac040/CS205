package android.support.v4.app;

import android.content.ComponentCallbacks;
import android.content.Context;
import android.content.res.Configuration;
import android.os.Bundle;
import android.os.Parcelable;
import android.support.v4.p002c.C0034l;
import android.support.v4.p002c.C0039d;
import android.support.v4.view.C0098s;
import android.util.SparseArray;
import android.view.ContextMenu;
import android.view.ContextMenu.ContextMenuInfo;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnCreateContextMenuListener;
import android.view.ViewGroup;
import android.view.animation.Animation;

public class C0013l implements ComponentCallbacks, OnCreateContextMenuListener {
    private static final C0034l f255a = new C0034l();
    static final Object f256j = new Object();
    int f257A;
    C0025w f258B;
    C0020u f259C;
    C0025w f260D;
    ad f261E;
    C0013l f262F;
    int f263G;
    int f264H;
    String f265I;
    boolean f266J;
    boolean f267K;
    boolean f268L;
    boolean f269M;
    boolean f270N;
    boolean f271O = true;
    boolean f272P;
    int f273Q;
    ViewGroup f274R;
    View f275S;
    View f276T;
    boolean f277U;
    boolean f278V = true;
    aq f279W;
    boolean f280X;
    boolean f281Y;
    Object f282Z = null;
    Object aa = f256j;
    Object ab = null;
    Object ac = f256j;
    Object ad = null;
    Object ae = f256j;
    Boolean af;
    Boolean ag;
    ct ah = null;
    ct ai = null;
    int f283k = 0;
    View f284l;
    int f285m;
    Bundle f286n;
    SparseArray f287o;
    int f288p = -1;
    String f289q;
    Bundle f290r;
    C0013l f291s;
    int f292t = -1;
    int f293u;
    boolean f294v;
    boolean f295w;
    boolean f296x;
    boolean f297y;
    boolean f298z;

    public static C0013l m162a(Context context, String str) {
        return C0013l.m163a(context, str, null);
    }

    public static C0013l m163a(Context context, String str, Bundle bundle) {
        try {
            Class cls = (Class) f255a.get(str);
            if (cls == null) {
                cls = context.getClassLoader().loadClass(str);
                f255a.put(str, cls);
            }
            C0013l c0013l = (C0013l) cls.newInstance();
            if (bundle != null) {
                bundle.setClassLoader(c0013l.getClass().getClassLoader());
                c0013l.f290r = bundle;
            }
            return c0013l;
        } catch (Exception e) {
            throw new C0017n("Unable to instantiate fragment " + str + ": make sure class name exists, is public, and has an empty constructor that is public", e);
        } catch (Exception e2) {
            throw new C0017n("Unable to instantiate fragment " + str + ": make sure class name exists, is public, and has an empty constructor that is public", e2);
        } catch (Exception e22) {
            throw new C0017n("Unable to instantiate fragment " + str + ": make sure class name exists, is public, and has an empty constructor that is public", e22);
        }
    }

    private void mo30b() {
        this.f260D = new C0025w();
        this.f260D.m266a(this.f259C, new C0016m(this), this);
    }

    static boolean m165b(Context context, String str) {
        try {
            Class cls = (Class) f255a.get(str);
            if (cls == null) {
                cls = context.getClassLoader().loadClass(str);
                f255a.put(str, cls);
            }
            return C0013l.class.isAssignableFrom(cls);
        } catch (ClassNotFoundException e) {
            return false;
        }
    }

    public static void m166h() {
    }

    public static void m167i() {
    }

    public static void m168j() {
    }

    public static void m169l() {
    }

    public static Animation m170m() {
        return null;
    }

    public static void m171n() {
    }

    public static void m172o() {
    }

    public void mo27a() {
        this.f272P = true;
    }

    final void m174a(int i, C0013l c0013l) {
        this.f288p = i;
        if (c0013l != null) {
            this.f289q = c0013l.f289q + ":" + this.f288p;
        } else {
            this.f289q = "android:fragment:" + this.f288p;
        }
    }

    public void mo28a(Context context) {
        this.f272P = true;
        if ((this.f259C == null ? null : this.f259C.f320b) != null) {
            this.f272P = false;
            this.f272P = true;
        }
    }

    public void mo29a(Bundle bundle) {
        boolean z = true;
        this.f272P = true;
        m183e(bundle);
        if (this.f260D != null) {
            if (this.f260D.f353n <= 0) {
                z = false;
            }
            if (!z) {
                this.f260D.m287g();
            }
        }
    }

    public LayoutInflater mo31b(Bundle bundle) {
        LayoutInflater c = this.f259C.mo48c();
        if (this.f260D == null) {
            mo30b();
            if (this.f283k >= 5) {
                this.f260D.m290j();
            } else if (this.f283k >= 4) {
                this.f260D.m289i();
            } else if (this.f283k >= 2) {
                this.f260D.m288h();
            } else if (this.f283k > 0) {
                this.f260D.m287g();
            }
        }
        C0098s.m698a(c, this.f260D);
        return c;
    }

    public void mo32c() {
        this.f272P = true;
        if (!this.f280X) {
            this.f280X = true;
            if (!this.f281Y) {
                this.f281Y = true;
                this.f279W = this.f259C.m215b(this.f289q);
            }
            if (this.f279W != null) {
                this.f279W.m56b();
            }
        }
    }

    public void mo33c(Bundle bundle) {
        this.f272P = true;
    }

    public void mo34d() {
        this.f272P = true;
    }

    public void mo35d(Bundle bundle) {
    }

    public void mo36e() {
        this.f272P = true;
    }

    final void m183e(Bundle bundle) {
        if (bundle != null) {
            Parcelable parcelable = bundle.getParcelable("android:support:fragments");
            if (parcelable != null) {
                if (this.f260D == null) {
                    mo30b();
                }
                this.f260D.m261a(parcelable, this.f261E);
                this.f261E = null;
                this.f260D.m287g();
            }
        }
    }

    public final boolean equals(Object obj) {
        return super.equals(obj);
    }

    public final C0018o m184f() {
        return this.f259C == null ? null : (C0018o) this.f259C.f320b;
    }

    final void m185f(Bundle bundle) {
        mo35d(bundle);
        if (this.f260D != null) {
            Parcelable f = this.f260D.m286f();
            if (f != null) {
                bundle.putParcelable("android:support:fragments", f);
            }
        }
    }

    public final boolean m186g() {
        return this.f259C != null && this.f294v;
    }

    public final int hashCode() {
        return super.hashCode();
    }

    public final void m187k() {
        this.f272P = true;
        if ((this.f259C == null ? null : this.f259C.f320b) != null) {
            this.f272P = false;
            this.f272P = true;
        }
    }

    public void onConfigurationChanged(Configuration configuration) {
        this.f272P = true;
    }

    public void onCreateContextMenu(ContextMenu contextMenu, View view, ContextMenuInfo contextMenuInfo) {
        m184f().onCreateContextMenu(contextMenu, view, contextMenuInfo);
    }

    public void onLowMemory() {
        this.f272P = true;
    }

    final View m188p() {
        if (this.f260D != null) {
            this.f260D.f358t = false;
        }
        return null;
    }

    final void m189q() {
        if (this.f260D != null) {
            this.f260D.m274b(2);
        }
        this.f283k = 2;
        if (this.f280X) {
            this.f280X = false;
            if (!this.f281Y) {
                this.f281Y = true;
                this.f279W = this.f259C.m215b(this.f289q);
            }
            if (this.f279W == null) {
                return;
            }
            if (this.f259C.f326h) {
                this.f279W.m58d();
            } else {
                this.f279W.m57c();
            }
        }
    }

    final void m190r() {
        if (this.f260D != null) {
            this.f260D.m292l();
        }
        this.f283k = 0;
        this.f272P = false;
        this.f272P = true;
        if (!this.f281Y) {
            this.f281Y = true;
            this.f279W = this.f259C.m215b(this.f289q);
        }
        if (this.f279W != null) {
            this.f279W.m61g();
        }
        if (this.f272P) {
            this.f260D = null;
            return;
        }
        throw new cu("Fragment " + this + " did not call through to super.onDestroy()");
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder(128);
        C0039d.m334a(this, stringBuilder);
        if (this.f288p >= 0) {
            stringBuilder.append(" #");
            stringBuilder.append(this.f288p);
        }
        if (this.f263G != 0) {
            stringBuilder.append(" id=0x");
            stringBuilder.append(Integer.toHexString(this.f263G));
        }
        if (this.f265I != null) {
            stringBuilder.append(" ");
            stringBuilder.append(this.f265I);
        }
        stringBuilder.append('}');
        return stringBuilder.toString();
    }
}
