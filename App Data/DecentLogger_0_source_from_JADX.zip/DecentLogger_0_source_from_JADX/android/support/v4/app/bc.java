package android.support.v4.app;

public final class bc {
    protected bc() {
    }
}
