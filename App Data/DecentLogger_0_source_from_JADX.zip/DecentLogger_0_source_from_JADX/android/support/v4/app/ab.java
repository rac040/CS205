package android.support.v4.app;

import android.support.v4.view.ao;

final class ab implements Runnable {
    final /* synthetic */ aa f59a;

    ab(aa aaVar) {
        this.f59a = aaVar;
    }

    public final void run() {
        ao.m524b(this.f59a.f58c, 0);
    }
}
