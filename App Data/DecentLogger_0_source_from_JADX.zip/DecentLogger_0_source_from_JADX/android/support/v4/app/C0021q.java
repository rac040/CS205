package android.support.v4.app;

import android.app.Activity;
import android.os.Build.VERSION;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import java.io.PrintWriter;

final class C0021q extends C0020u {
    final /* synthetic */ C0018o f330a;

    public C0021q(C0018o c0018o) {
        this.f330a = c0018o;
        super(c0018o);
    }

    public final View mo37a(int i) {
        return this.f330a.findViewById(i);
    }

    public final void mo46a(String str, PrintWriter printWriter, String[] strArr) {
        this.f330a.dump(str, null, printWriter, strArr);
    }

    public final boolean mo38a() {
        Window window = this.f330a.getWindow();
        return (window == null || window.peekDecorView() == null) ? false : true;
    }

    public final boolean mo47b() {
        return !this.f330a.isFinishing();
    }

    public final LayoutInflater mo48c() {
        return this.f330a.getLayoutInflater().cloneInContext(this.f330a);
    }

    public final void mo49d() {
        Activity activity = this.f330a;
        if (VERSION.SDK_INT >= 11) {
            activity.invalidateOptionsMenu();
        } else {
            activity.f316j = true;
        }
    }

    public final boolean mo50e() {
        return this.f330a.getWindow() != null;
    }

    public final int mo51f() {
        Window window = this.f330a.getWindow();
        return window == null ? 0 : window.getAttributes().windowAnimations;
    }
}
