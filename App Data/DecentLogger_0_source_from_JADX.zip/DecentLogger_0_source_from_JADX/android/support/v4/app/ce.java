package android.support.v4.app;

import android.app.Notification;
import android.app.Notification.Builder;
import android.app.PendingIntent;
import android.content.Context;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.util.SparseArray;
import android.widget.RemoteViews;
import java.util.ArrayList;
import java.util.List;

public final class ce implements at, au {
    private Builder f211a;
    private final Bundle f212b;
    private List f213c = new ArrayList();
    private RemoteViews f214d;
    private RemoteViews f215e;

    public ce(Context context, Notification notification, CharSequence charSequence, CharSequence charSequence2, CharSequence charSequence3, RemoteViews remoteViews, int i, PendingIntent pendingIntent, PendingIntent pendingIntent2, Bitmap bitmap, int i2, int i3, boolean z, boolean z2, int i4, CharSequence charSequence4, boolean z3, Bundle bundle, String str, boolean z4, String str2, RemoteViews remoteViews2, RemoteViews remoteViews3) {
        this.f211a = new Builder(context).setWhen(notification.when).setSmallIcon(notification.icon, notification.iconLevel).setContent(notification.contentView).setTicker(notification.tickerText, remoteViews).setSound(notification.sound, notification.audioStreamType).setVibrate(notification.vibrate).setLights(notification.ledARGB, notification.ledOnMS, notification.ledOffMS).setOngoing((notification.flags & 2) != 0).setOnlyAlertOnce((notification.flags & 8) != 0).setAutoCancel((notification.flags & 16) != 0).setDefaults(notification.defaults).setContentTitle(charSequence).setContentText(charSequence2).setSubText(charSequence4).setContentInfo(charSequence3).setContentIntent(pendingIntent).setDeleteIntent(notification.deleteIntent).setFullScreenIntent(pendingIntent2, (notification.flags & 128) != 0).setLargeIcon(bitmap).setNumber(i).setUsesChronometer(z2).setPriority(i4).setProgress(i2, i3, z);
        this.f212b = new Bundle();
        if (bundle != null) {
            this.f212b.putAll(bundle);
        }
        if (z3) {
            this.f212b.putBoolean("android.support.localOnly", true);
        }
        if (str != null) {
            this.f212b.putString("android.support.groupKey", str);
            if (z4) {
                this.f212b.putBoolean("android.support.isGroupSummary", true);
            } else {
                this.f212b.putBoolean("android.support.useSideChannel", true);
            }
        }
        if (str2 != null) {
            this.f212b.putString("android.support.sortKey", str2);
        }
        this.f214d = remoteViews2;
        this.f215e = remoteViews3;
    }

    public final Builder mo18a() {
        return this.f211a;
    }

    public final void mo19a(bz bzVar) {
        this.f213c.add(cd.m130a(this.f211a, bzVar));
    }

    public final Notification mo20b() {
        Notification build = this.f211a.build();
        Bundle a = cd.m131a(build);
        Bundle bundle = new Bundle(this.f212b);
        for (String str : this.f212b.keySet()) {
            if (a.containsKey(str)) {
                bundle.remove(str);
            }
        }
        a.putAll(bundle);
        SparseArray a2 = cd.m132a(this.f213c);
        if (a2 != null) {
            cd.m131a(build).putSparseParcelableArray("android.support.actionExtras", a2);
        }
        if (this.f214d != null) {
            build.contentView = this.f214d;
        }
        if (this.f215e != null) {
            build.bigContentView = this.f215e;
        }
        return build;
    }
}
