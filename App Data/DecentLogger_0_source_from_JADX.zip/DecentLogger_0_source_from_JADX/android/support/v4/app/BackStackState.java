package android.support.v4.app;

import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import android.text.TextUtils;
import android.util.Log;
import java.util.ArrayList;

final class BackStackState implements Parcelable {
    public static final Creator CREATOR = new C0009g();
    final int[] f8a;
    final int f9b;
    final int f10c;
    final String f11d;
    final int f12e;
    final int f13f;
    final CharSequence f14g;
    final int f15h;
    final CharSequence f16i;
    final ArrayList f17j;
    final ArrayList f18k;

    public BackStackState(Parcel parcel) {
        this.f8a = parcel.createIntArray();
        this.f9b = parcel.readInt();
        this.f10c = parcel.readInt();
        this.f11d = parcel.readString();
        this.f12e = parcel.readInt();
        this.f13f = parcel.readInt();
        this.f14g = (CharSequence) TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(parcel);
        this.f15h = parcel.readInt();
        this.f16i = (CharSequence) TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(parcel);
        this.f17j = parcel.createStringArrayList();
        this.f18k = parcel.createStringArrayList();
    }

    public BackStackState(C0003a c0003a) {
        int i = 0;
        for (C0007e c0007e = c0003a.f36c; c0007e != null; c0007e = c0007e.f239a) {
            if (c0007e.f247i != null) {
                i += c0007e.f247i.size();
            }
        }
        this.f8a = new int[(i + (c0003a.f38e * 7))];
        if (c0003a.f45l) {
            i = 0;
            for (C0007e c0007e2 = c0003a.f36c; c0007e2 != null; c0007e2 = c0007e2.f239a) {
                int i2 = i + 1;
                this.f8a[i] = c0007e2.f241c;
                int i3 = i2 + 1;
                this.f8a[i2] = c0007e2.f242d != null ? c0007e2.f242d.f288p : -1;
                int i4 = i3 + 1;
                this.f8a[i3] = c0007e2.f243e;
                i2 = i4 + 1;
                this.f8a[i4] = c0007e2.f244f;
                i4 = i2 + 1;
                this.f8a[i2] = c0007e2.f245g;
                i2 = i4 + 1;
                this.f8a[i4] = c0007e2.f246h;
                if (c0007e2.f247i != null) {
                    int size = c0007e2.f247i.size();
                    i4 = i2 + 1;
                    this.f8a[i2] = size;
                    i2 = 0;
                    while (i2 < size) {
                        i3 = i4 + 1;
                        this.f8a[i4] = ((C0013l) c0007e2.f247i.get(i2)).f288p;
                        i2++;
                        i4 = i3;
                    }
                    i = i4;
                } else {
                    i = i2 + 1;
                    this.f8a[i2] = 0;
                }
            }
            this.f9b = c0003a.f43j;
            this.f10c = c0003a.f44k;
            this.f11d = c0003a.f47n;
            this.f12e = c0003a.f49p;
            this.f13f = c0003a.f50q;
            this.f14g = c0003a.f51r;
            this.f15h = c0003a.f52s;
            this.f16i = c0003a.f53t;
            this.f17j = c0003a.f54u;
            this.f18k = c0003a.f55v;
            return;
        }
        throw new IllegalStateException("Not on back stack");
    }

    public final C0003a m2a(C0025w c0025w) {
        C0003a c0003a = new C0003a(c0025w);
        int i = 0;
        int i2 = 0;
        while (i2 < this.f8a.length) {
            C0007e c0007e = new C0007e();
            int i3 = i2 + 1;
            c0007e.f241c = this.f8a[i2];
            if (C0025w.f339a) {
                Log.v("FragmentManager", "Instantiate " + c0003a + " op #" + i + " base fragment #" + this.f8a[i3]);
            }
            int i4 = i3 + 1;
            i2 = this.f8a[i3];
            if (i2 >= 0) {
                c0007e.f242d = (C0013l) c0025w.f345f.get(i2);
            } else {
                c0007e.f242d = null;
            }
            i3 = i4 + 1;
            c0007e.f243e = this.f8a[i4];
            i4 = i3 + 1;
            c0007e.f244f = this.f8a[i3];
            i3 = i4 + 1;
            c0007e.f245g = this.f8a[i4];
            int i5 = i3 + 1;
            c0007e.f246h = this.f8a[i3];
            i4 = i5 + 1;
            int i6 = this.f8a[i5];
            if (i6 > 0) {
                c0007e.f247i = new ArrayList(i6);
                i3 = 0;
                while (i3 < i6) {
                    if (C0025w.f339a) {
                        Log.v("FragmentManager", "Instantiate " + c0003a + " set remove fragment #" + this.f8a[i4]);
                    }
                    i5 = i4 + 1;
                    c0007e.f247i.add((C0013l) c0025w.f345f.get(this.f8a[i4]));
                    i3++;
                    i4 = i5;
                }
            }
            c0003a.f39f = c0007e.f243e;
            c0003a.f40g = c0007e.f244f;
            c0003a.f41h = c0007e.f245g;
            c0003a.f42i = c0007e.f246h;
            c0003a.m30a(c0007e);
            i++;
            i2 = i4;
        }
        c0003a.f43j = this.f9b;
        c0003a.f44k = this.f10c;
        c0003a.f47n = this.f11d;
        c0003a.f49p = this.f12e;
        c0003a.f45l = true;
        c0003a.f50q = this.f13f;
        c0003a.f51r = this.f14g;
        c0003a.f52s = this.f15h;
        c0003a.f53t = this.f16i;
        c0003a.f54u = this.f17j;
        c0003a.f55v = this.f18k;
        c0003a.m29a(1);
        return c0003a;
    }

    public final int describeContents() {
        return 0;
    }

    public final void writeToParcel(Parcel parcel, int i) {
        parcel.writeIntArray(this.f8a);
        parcel.writeInt(this.f9b);
        parcel.writeInt(this.f10c);
        parcel.writeString(this.f11d);
        parcel.writeInt(this.f12e);
        parcel.writeInt(this.f13f);
        TextUtils.writeToParcel(this.f14g, parcel, 0);
        parcel.writeInt(this.f15h);
        TextUtils.writeToParcel(this.f16i, parcel, 0);
        parcel.writeStringList(this.f17j);
        parcel.writeStringList(this.f18k);
    }
}
