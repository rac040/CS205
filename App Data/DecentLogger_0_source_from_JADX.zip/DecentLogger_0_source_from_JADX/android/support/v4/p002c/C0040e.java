package android.support.v4.p002c;

import android.util.Log;
import java.io.Writer;

public final class C0040e extends Writer {
    private final String f388a;
    private StringBuilder f389b = new StringBuilder(128);

    public C0040e(String str) {
        this.f388a = str;
    }

    private void m335a() {
        if (this.f389b.length() > 0) {
            Log.d(this.f388a, this.f389b.toString());
            this.f389b.delete(0, this.f389b.length());
        }
    }

    public final void close() {
        m335a();
    }

    public final void flush() {
        m335a();
    }

    public final void write(char[] cArr, int i, int i2) {
        for (int i3 = 0; i3 < i2; i3++) {
            char c = cArr[i + i3];
            if (c == '\n') {
                m335a();
            } else {
                this.f389b.append(c);
            }
        }
    }
}
