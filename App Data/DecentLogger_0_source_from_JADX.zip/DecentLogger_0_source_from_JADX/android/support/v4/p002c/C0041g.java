package android.support.v4.p002c;

import java.util.Iterator;

final class C0041g implements Iterator {
    final int f390a;
    int f391b;
    int f392c;
    boolean f393d = false;
    final /* synthetic */ C0036f f394e;

    C0041g(C0036f c0036f, int i) {
        this.f394e = c0036f;
        this.f390a = i;
        this.f391b = c0036f.mo58a();
    }

    public final boolean hasNext() {
        return this.f392c < this.f391b;
    }

    public final Object next() {
        Object a = this.f394e.mo60a(this.f392c, this.f390a);
        this.f392c++;
        this.f393d = true;
        return a;
    }

    public final void remove() {
        if (this.f393d) {
            this.f392c--;
            this.f391b--;
            this.f393d = false;
            this.f394e.mo62a(this.f392c);
            return;
        }
        throw new IllegalStateException();
    }
}
