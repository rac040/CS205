package android.support.v4.p002c;

import java.util.Iterator;
import java.util.Map.Entry;

final class C0044j implements Iterator, Entry {
    int f397a;
    int f398b;
    boolean f399c = false;
    final /* synthetic */ C0036f f400d;

    C0044j(C0036f c0036f) {
        this.f400d = c0036f;
        this.f397a = c0036f.mo58a() - 1;
        this.f398b = -1;
    }

    public final boolean equals(Object obj) {
        if (!this.f399c) {
            throw new IllegalStateException("This container does not support retaining Map.Entry objects");
        } else if (!(obj instanceof Entry)) {
            return false;
        } else {
            Entry entry = (Entry) obj;
            return C0038c.m333a(entry.getKey(), this.f400d.mo60a(this.f398b, 0)) && C0038c.m333a(entry.getValue(), this.f400d.mo60a(this.f398b, 1));
        }
    }

    public final Object getKey() {
        if (this.f399c) {
            return this.f400d.mo60a(this.f398b, 0);
        }
        throw new IllegalStateException("This container does not support retaining Map.Entry objects");
    }

    public final Object getValue() {
        if (this.f399c) {
            return this.f400d.mo60a(this.f398b, 1);
        }
        throw new IllegalStateException("This container does not support retaining Map.Entry objects");
    }

    public final boolean hasNext() {
        return this.f398b < this.f397a;
    }

    public final int hashCode() {
        int i = 0;
        if (this.f399c) {
            Object a = this.f400d.mo60a(this.f398b, 0);
            Object a2 = this.f400d.mo60a(this.f398b, 1);
            int hashCode = a == null ? 0 : a.hashCode();
            if (a2 != null) {
                i = a2.hashCode();
            }
            return i ^ hashCode;
        }
        throw new IllegalStateException("This container does not support retaining Map.Entry objects");
    }

    public final /* bridge */ /* synthetic */ Object next() {
        this.f398b++;
        this.f399c = true;
        return this;
    }

    public final void remove() {
        if (this.f399c) {
            this.f400d.mo62a(this.f398b);
            this.f398b--;
            this.f397a--;
            this.f399c = false;
            return;
        }
        throw new IllegalStateException();
    }

    public final Object setValue(Object obj) {
        if (this.f399c) {
            return this.f400d.mo61a(this.f398b, obj);
        }
        throw new IllegalStateException("This container does not support retaining Map.Entry objects");
    }

    public final String toString() {
        return getKey() + "=" + getValue();
    }
}
