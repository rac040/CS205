package android.support.v4.p002c;

import java.lang.reflect.Array;
import java.util.Collection;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public abstract class C0036f {
    C0042h f381b;
    C0043i f382c;
    C0045k f383d;

    C0036f() {
    }

    public static boolean m309a(Map map, Collection collection) {
        int size = map.size();
        Iterator it = map.keySet().iterator();
        while (it.hasNext()) {
            if (!collection.contains(it.next())) {
                it.remove();
            }
        }
        return size != map.size();
    }

    public static boolean m310a(Set set, Object obj) {
        if (set == obj) {
            return true;
        }
        if (!(obj instanceof Set)) {
            return false;
        }
        Set set2 = (Set) obj;
        try {
            return set.size() == set2.size() && set.containsAll(set2);
        } catch (NullPointerException e) {
            return false;
        } catch (ClassCastException e2) {
            return false;
        }
    }

    protected abstract int mo58a();

    protected abstract int mo59a(Object obj);

    protected abstract Object mo60a(int i, int i2);

    protected abstract Object mo61a(int i, Object obj);

    protected abstract void mo62a(int i);

    protected abstract void mo63a(Object obj, Object obj2);

    public final Object[] m317a(Object[] objArr, int i) {
        int a = mo58a();
        Object[] objArr2 = objArr.length < a ? (Object[]) Array.newInstance(objArr.getClass().getComponentType(), a) : objArr;
        for (int i2 = 0; i2 < a; i2++) {
            objArr2[i2] = mo60a(i2, i);
        }
        if (objArr2.length > a) {
            objArr2[a] = null;
        }
        return objArr2;
    }

    protected abstract int mo64b(Object obj);

    protected abstract Map mo65b();

    public final Object[] m320b(int i) {
        int a = mo58a();
        Object[] objArr = new Object[a];
        for (int i2 = 0; i2 < a; i2++) {
            objArr[i2] = mo60a(i2, i);
        }
        return objArr;
    }

    protected abstract void mo66c();
}
