package android.support.v4.p002c;

import java.util.Map;

public class C0034l {
    static Object[] f373b;
    static int f374c;
    static Object[] f375d;
    static int f376e;
    int[] f377f;
    Object[] f378g;
    int f379h;

    public C0034l() {
        this.f377f = C0038c.f385a;
        this.f378g = C0038c.f387c;
        this.f379h = 0;
    }

    public C0034l(int i) {
        if (i == 0) {
            this.f377f = C0038c.f385a;
            this.f378g = C0038c.f387c;
        } else {
            m303a(i);
        }
        this.f379h = 0;
    }

    private int m298a() {
        int i = this.f379h;
        if (i == 0) {
            return -1;
        }
        int a = C0038c.m332a(this.f377f, i, 0);
        if (a < 0 || this.f378g[a << 1] == null) {
            return a;
        }
        int i2 = a + 1;
        while (i2 < i && this.f377f[i2] == 0) {
            if (this.f378g[i2 << 1] == null) {
                return i2;
            }
            i2++;
        }
        a--;
        while (a >= 0 && this.f377f[a] == 0) {
            if (this.f378g[a << 1] == null) {
                return a;
            }
            a--;
        }
        return i2 ^ -1;
    }

    private int m299a(Object obj, int i) {
        int i2 = this.f379h;
        if (i2 == 0) {
            return -1;
        }
        int a = C0038c.m332a(this.f377f, i2, i);
        if (a < 0 || obj.equals(this.f378g[a << 1])) {
            return a;
        }
        int i3 = a + 1;
        while (i3 < i2 && this.f377f[i3] == i) {
            if (obj.equals(this.f378g[i3 << 1])) {
                return i3;
            }
            i3++;
        }
        a--;
        while (a >= 0 && this.f377f[a] == i) {
            if (obj.equals(this.f378g[a << 1])) {
                return a;
            }
            a--;
        }
        return i3 ^ -1;
    }

    static void m300a(int[] iArr, Object[] objArr, int i) {
        int i2;
        if (iArr.length == 8) {
            synchronized (C0035a.class) {
                if (f376e < 10) {
                    objArr[0] = f375d;
                    objArr[1] = iArr;
                    for (i2 = (i << 1) - 1; i2 >= 2; i2--) {
                        objArr[i2] = null;
                    }
                    f375d = objArr;
                    f376e++;
                }
            }
        } else if (iArr.length == 4) {
            synchronized (C0035a.class) {
                if (f374c < 10) {
                    objArr[0] = f373b;
                    objArr[1] = iArr;
                    for (i2 = (i << 1) - 1; i2 >= 2; i2--) {
                        objArr[i2] = null;
                    }
                    f373b = objArr;
                    f374c++;
                }
            }
        }
    }

    public final int m301a(Object obj) {
        return obj == null ? m298a() : m299a(obj, obj.hashCode());
    }

    public final Object m302a(int i, Object obj) {
        int i2 = (i << 1) + 1;
        Object obj2 = this.f378g[i2];
        this.f378g[i2] = obj;
        return obj2;
    }

    final void m303a(int i) {
        Object[] objArr;
        if (i == 8) {
            synchronized (C0035a.class) {
                if (f375d != null) {
                    objArr = f375d;
                    this.f378g = objArr;
                    f375d = (Object[]) objArr[0];
                    this.f377f = (int[]) objArr[1];
                    objArr[1] = null;
                    objArr[0] = null;
                    f376e--;
                    return;
                }
            }
        } else if (i == 4) {
            synchronized (C0035a.class) {
                if (f373b != null) {
                    objArr = f373b;
                    this.f378g = objArr;
                    f373b = (Object[]) objArr[0];
                    this.f377f = (int[]) objArr[1];
                    objArr[1] = null;
                    objArr[0] = null;
                    f374c--;
                    return;
                }
            }
        }
        this.f377f = new int[i];
        this.f378g = new Object[(i << 1)];
    }

    final int m304b(Object obj) {
        int i = 1;
        int i2 = this.f379h * 2;
        Object[] objArr = this.f378g;
        if (obj == null) {
            while (i < i2) {
                if (objArr[i] == null) {
                    return i >> 1;
                }
                i += 2;
            }
        } else {
            while (i < i2) {
                if (obj.equals(objArr[i])) {
                    return i >> 1;
                }
                i += 2;
            }
        }
        return -1;
    }

    public final Object m305b(int i) {
        return this.f378g[i << 1];
    }

    public final Object m306c(int i) {
        return this.f378g[(i << 1) + 1];
    }

    public void clear() {
        if (this.f379h != 0) {
            C0034l.m300a(this.f377f, this.f378g, this.f379h);
            this.f377f = C0038c.f385a;
            this.f378g = C0038c.f387c;
            this.f379h = 0;
        }
    }

    public boolean containsKey(Object obj) {
        return m301a(obj) >= 0;
    }

    public boolean containsValue(Object obj) {
        return m304b(obj) >= 0;
    }

    public final Object m307d(int i) {
        int i2 = 8;
        Object obj = this.f378g[(i << 1) + 1];
        if (this.f379h <= 1) {
            C0034l.m300a(this.f377f, this.f378g, this.f379h);
            this.f377f = C0038c.f385a;
            this.f378g = C0038c.f387c;
            this.f379h = 0;
        } else if (this.f377f.length <= 8 || this.f379h >= this.f377f.length / 3) {
            this.f379h--;
            if (i < this.f379h) {
                System.arraycopy(this.f377f, i + 1, this.f377f, i, this.f379h - i);
                System.arraycopy(this.f378g, (i + 1) << 1, this.f378g, i << 1, (this.f379h - i) << 1);
            }
            this.f378g[this.f379h << 1] = null;
            this.f378g[(this.f379h << 1) + 1] = null;
        } else {
            if (this.f379h > 8) {
                i2 = this.f379h + (this.f379h >> 1);
            }
            Object obj2 = this.f377f;
            Object obj3 = this.f378g;
            m303a(i2);
            this.f379h--;
            if (i > 0) {
                System.arraycopy(obj2, 0, this.f377f, 0, i);
                System.arraycopy(obj3, 0, this.f378g, 0, i << 1);
            }
            if (i < this.f379h) {
                System.arraycopy(obj2, i + 1, this.f377f, i, this.f379h - i);
                System.arraycopy(obj3, (i + 1) << 1, this.f378g, i << 1, (this.f379h - i) << 1);
            }
        }
        return obj;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        int i;
        Object b;
        Object c;
        Object obj2;
        if (obj instanceof C0034l) {
            C0034l c0034l = (C0034l) obj;
            if (size() != c0034l.size()) {
                return false;
            }
            i = 0;
            while (i < this.f379h) {
                try {
                    b = m305b(i);
                    c = m306c(i);
                    obj2 = c0034l.get(b);
                    if (c == null) {
                        if (obj2 != null || !c0034l.containsKey(b)) {
                            return false;
                        }
                    } else if (!c.equals(obj2)) {
                        return false;
                    }
                    i++;
                } catch (NullPointerException e) {
                    return false;
                } catch (ClassCastException e2) {
                    return false;
                }
            }
            return true;
        } else if (!(obj instanceof Map)) {
            return false;
        } else {
            Map map = (Map) obj;
            if (size() != map.size()) {
                return false;
            }
            i = 0;
            while (i < this.f379h) {
                try {
                    b = m305b(i);
                    c = m306c(i);
                    obj2 = map.get(b);
                    if (c == null) {
                        if (obj2 != null || !map.containsKey(b)) {
                            return false;
                        }
                    } else if (!c.equals(obj2)) {
                        return false;
                    }
                    i++;
                } catch (NullPointerException e3) {
                    return false;
                } catch (ClassCastException e4) {
                    return false;
                }
            }
            return true;
        }
    }

    public Object get(Object obj) {
        int a = m301a(obj);
        return a >= 0 ? this.f378g[(a << 1) + 1] : null;
    }

    public int hashCode() {
        int[] iArr = this.f377f;
        Object[] objArr = this.f378g;
        int i = this.f379h;
        int i2 = 1;
        int i3 = 0;
        int i4 = 0;
        while (i3 < i) {
            Object obj = objArr[i2];
            i4 += (obj == null ? 0 : obj.hashCode()) ^ iArr[i3];
            i3++;
            i2 += 2;
        }
        return i4;
    }

    public boolean isEmpty() {
        return this.f379h <= 0;
    }

    public Object put(Object obj, Object obj2) {
        int a;
        int i;
        int i2 = 8;
        if (obj == null) {
            a = m298a();
            i = 0;
        } else {
            i = obj.hashCode();
            a = m299a(obj, i);
        }
        if (a >= 0) {
            int i3 = (a << 1) + 1;
            Object obj3 = this.f378g[i3];
            this.f378g[i3] = obj2;
            return obj3;
        }
        a ^= -1;
        if (this.f379h >= this.f377f.length) {
            if (this.f379h >= 8) {
                i2 = this.f379h + (this.f379h >> 1);
            } else if (this.f379h < 4) {
                i2 = 4;
            }
            Object obj4 = this.f377f;
            Object obj5 = this.f378g;
            m303a(i2);
            if (this.f377f.length > 0) {
                System.arraycopy(obj4, 0, this.f377f, 0, obj4.length);
                System.arraycopy(obj5, 0, this.f378g, 0, obj5.length);
            }
            C0034l.m300a(obj4, obj5, this.f379h);
        }
        if (a < this.f379h) {
            System.arraycopy(this.f377f, a, this.f377f, a + 1, this.f379h - a);
            System.arraycopy(this.f378g, a << 1, this.f378g, (a + 1) << 1, (this.f379h - a) << 1);
        }
        this.f377f[a] = i;
        this.f378g[a << 1] = obj;
        this.f378g[(a << 1) + 1] = obj2;
        this.f379h++;
        return null;
    }

    public Object remove(Object obj) {
        int a = m301a(obj);
        return a >= 0 ? m307d(a) : null;
    }

    public int size() {
        return this.f379h;
    }

    public String toString() {
        if (isEmpty()) {
            return "{}";
        }
        StringBuilder stringBuilder = new StringBuilder(this.f379h * 28);
        stringBuilder.append('{');
        for (int i = 0; i < this.f379h; i++) {
            if (i > 0) {
                stringBuilder.append(", ");
            }
            C0034l b = m305b(i);
            if (b != this) {
                stringBuilder.append(b);
            } else {
                stringBuilder.append("(this Map)");
            }
            stringBuilder.append('=');
            b = m306c(i);
            if (b != this) {
                stringBuilder.append(b);
            } else {
                stringBuilder.append("(this Map)");
            }
        }
        stringBuilder.append('}');
        return stringBuilder.toString();
    }
}
