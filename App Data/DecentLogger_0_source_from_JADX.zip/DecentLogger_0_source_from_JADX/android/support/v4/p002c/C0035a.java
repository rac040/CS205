package android.support.v4.p002c;

import java.util.Collection;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class C0035a extends C0034l implements Map {
    C0036f f380a;

    public C0035a(byte b) {
        super(1);
    }

    private C0036f m308a() {
        if (this.f380a == null) {
            this.f380a = new C0037b(this);
        }
        return this.f380a;
    }

    public Set entrySet() {
        C0036f a = m308a();
        if (a.f381b == null) {
            a.f381b = new C0042h(a);
        }
        return a.f381b;
    }

    public Set keySet() {
        C0036f a = m308a();
        if (a.f382c == null) {
            a.f382c = new C0043i(a);
        }
        return a.f382c;
    }

    public void putAll(Map map) {
        int size = this.h + map.size();
        if (this.f377f.length < size) {
            Object obj = this.f377f;
            Object obj2 = this.f378g;
            super.m303a(size);
            if (this.f379h > 0) {
                System.arraycopy(obj, 0, this.f377f, 0, this.f379h);
                System.arraycopy(obj2, 0, this.f378g, 0, this.f379h << 1);
            }
            C0034l.m300a(obj, obj2, this.f379h);
        }
        for (Entry entry : map.entrySet()) {
            put(entry.getKey(), entry.getValue());
        }
    }

    public Collection values() {
        C0036f a = m308a();
        if (a.f383d == null) {
            a.f383d = new C0045k(a);
        }
        return a.f383d;
    }
}
