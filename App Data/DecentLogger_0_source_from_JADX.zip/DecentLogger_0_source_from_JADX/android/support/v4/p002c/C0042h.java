package android.support.v4.p002c;

import java.util.Collection;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Set;

final class C0042h implements Set {
    final /* synthetic */ C0036f f395a;

    C0042h(C0036f c0036f) {
        this.f395a = c0036f;
    }

    public final /* synthetic */ boolean add(Object obj) {
        throw new UnsupportedOperationException();
    }

    public final boolean addAll(Collection collection) {
        int a = this.f395a.mo58a();
        for (Entry entry : collection) {
            this.f395a.mo63a(entry.getKey(), entry.getValue());
        }
        return a != this.f395a.mo58a();
    }

    public final void clear() {
        this.f395a.mo66c();
    }

    public final boolean contains(Object obj) {
        if (!(obj instanceof Entry)) {
            return false;
        }
        Entry entry = (Entry) obj;
        int a = this.f395a.mo59a(entry.getKey());
        return a >= 0 ? C0038c.m333a(this.f395a.mo60a(a, 1), entry.getValue()) : false;
    }

    public final boolean containsAll(Collection collection) {
        for (Object contains : collection) {
            if (!contains(contains)) {
                return false;
            }
        }
        return true;
    }

    public final boolean equals(Object obj) {
        return C0036f.m310a((Set) this, obj);
    }

    public final int hashCode() {
        int a = this.f395a.mo58a() - 1;
        int i = 0;
        while (a >= 0) {
            Object a2 = this.f395a.mo60a(a, 0);
            Object a3 = this.f395a.mo60a(a, 1);
            a--;
            i += (a3 == null ? 0 : a3.hashCode()) ^ (a2 == null ? 0 : a2.hashCode());
        }
        return i;
    }

    public final boolean isEmpty() {
        return this.f395a.mo58a() == 0;
    }

    public final Iterator iterator() {
        return new C0044j(this.f395a);
    }

    public final boolean remove(Object obj) {
        throw new UnsupportedOperationException();
    }

    public final boolean removeAll(Collection collection) {
        throw new UnsupportedOperationException();
    }

    public final boolean retainAll(Collection collection) {
        throw new UnsupportedOperationException();
    }

    public final int size() {
        return this.f395a.mo58a();
    }

    public final Object[] toArray() {
        throw new UnsupportedOperationException();
    }

    public final Object[] toArray(Object[] objArr) {
        throw new UnsupportedOperationException();
    }
}
