package android.support.v4.p002c;

public final class C0046m implements Cloneable {
    public static final Object f402a = new Object();
    public boolean f403b;
    public int[] f404c;
    public Object[] f405d;
    public int f406e;

    public C0046m() {
        this(10);
    }

    public C0046m(int i) {
        this.f403b = false;
        if (i == 0) {
            this.f404c = C0038c.f385a;
            this.f405d = C0038c.f387c;
        } else {
            int a = C0038c.m331a(i);
            this.f404c = new int[a];
            this.f405d = new Object[a];
        }
        this.f406e = 0;
    }

    private C0046m m336d() {
        try {
            C0046m c0046m = (C0046m) super.clone();
            try {
                c0046m.f404c = (int[]) this.f404c.clone();
                c0046m.f405d = (Object[]) this.f405d.clone();
                return c0046m;
            } catch (CloneNotSupportedException e) {
                return c0046m;
            }
        } catch (CloneNotSupportedException e2) {
            return null;
        }
    }

    public final Object m337a(int i) {
        int a = C0038c.m332a(this.f404c, this.f406e, i);
        return (a < 0 || this.f405d[a] == f402a) ? null : this.f405d[a];
    }

    public final void m338a() {
        int i = this.f406e;
        int[] iArr = this.f404c;
        Object[] objArr = this.f405d;
        int i2 = 0;
        for (int i3 = 0; i3 < i; i3++) {
            Object obj = objArr[i3];
            if (obj != f402a) {
                if (i3 != i2) {
                    iArr[i2] = iArr[i3];
                    objArr[i2] = obj;
                    objArr[i3] = null;
                }
                i2++;
            }
        }
        this.f403b = false;
        this.f406e = i2;
    }

    public final int m339b() {
        if (this.f403b) {
            m338a();
        }
        return this.f406e;
    }

    public final void m340b(int i) {
        int a = C0038c.m332a(this.f404c, this.f406e, i);
        if (a >= 0 && this.f405d[a] != f402a) {
            this.f405d[a] = f402a;
            this.f403b = true;
        }
    }

    public final int m341c(int i) {
        if (this.f403b) {
            m338a();
        }
        return this.f404c[i];
    }

    public final void m342c() {
        int i = this.f406e;
        Object[] objArr = this.f405d;
        for (int i2 = 0; i2 < i; i2++) {
            objArr[i2] = null;
        }
        this.f406e = 0;
        this.f403b = false;
    }

    public final /* synthetic */ Object clone() {
        return m336d();
    }

    public final Object m343d(int i) {
        if (this.f403b) {
            m338a();
        }
        return this.f405d[i];
    }

    public final String toString() {
        if (m339b() <= 0) {
            return "{}";
        }
        StringBuilder stringBuilder = new StringBuilder(this.f406e * 28);
        stringBuilder.append('{');
        for (int i = 0; i < this.f406e; i++) {
            if (i > 0) {
                stringBuilder.append(", ");
            }
            stringBuilder.append(m341c(i));
            stringBuilder.append('=');
            C0046m d = m343d(i);
            if (d != this) {
                stringBuilder.append(d);
            } else {
                stringBuilder.append("(this Map)");
            }
        }
        stringBuilder.append('}');
        return stringBuilder.toString();
    }
}
