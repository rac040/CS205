package android.support.v4.p002c;

import java.util.Collection;
import java.util.Iterator;

final class C0045k implements Collection {
    final /* synthetic */ C0036f f401a;

    C0045k(C0036f c0036f) {
        this.f401a = c0036f;
    }

    public final boolean add(Object obj) {
        throw new UnsupportedOperationException();
    }

    public final boolean addAll(Collection collection) {
        throw new UnsupportedOperationException();
    }

    public final void clear() {
        this.f401a.mo66c();
    }

    public final boolean contains(Object obj) {
        return this.f401a.mo64b(obj) >= 0;
    }

    public final boolean containsAll(Collection collection) {
        for (Object contains : collection) {
            if (!contains(contains)) {
                return false;
            }
        }
        return true;
    }

    public final boolean isEmpty() {
        return this.f401a.mo58a() == 0;
    }

    public final Iterator iterator() {
        return new C0041g(this.f401a, 1);
    }

    public final boolean remove(Object obj) {
        int b = this.f401a.mo64b(obj);
        if (b < 0) {
            return false;
        }
        this.f401a.mo62a(b);
        return true;
    }

    public final boolean removeAll(Collection collection) {
        int i = 0;
        int a = this.f401a.mo58a();
        boolean z = false;
        while (i < a) {
            if (collection.contains(this.f401a.mo60a(i, 1))) {
                this.f401a.mo62a(i);
                i--;
                a--;
                z = true;
            }
            i++;
        }
        return z;
    }

    public final boolean retainAll(Collection collection) {
        int i = 0;
        int a = this.f401a.mo58a();
        boolean z = false;
        while (i < a) {
            if (!collection.contains(this.f401a.mo60a(i, 1))) {
                this.f401a.mo62a(i);
                i--;
                a--;
                z = true;
            }
            i++;
        }
        return z;
    }

    public final int size() {
        return this.f401a.mo58a();
    }

    public final Object[] toArray() {
        return this.f401a.m320b(1);
    }

    public final Object[] toArray(Object[] objArr) {
        return this.f401a.m317a(objArr, 1);
    }
}
