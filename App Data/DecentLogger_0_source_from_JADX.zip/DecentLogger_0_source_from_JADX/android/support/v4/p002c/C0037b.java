package android.support.v4.p002c;

import java.util.Map;

final class C0037b extends C0036f {
    final /* synthetic */ C0035a f384a;

    C0037b(C0035a c0035a) {
        this.f384a = c0035a;
    }

    protected final int mo58a() {
        return this.f384a.h;
    }

    protected final int mo59a(Object obj) {
        return this.f384a.m301a(obj);
    }

    protected final Object mo60a(int i, int i2) {
        return this.f384a.g[(i << 1) + i2];
    }

    protected final Object mo61a(int i, Object obj) {
        return this.f384a.m302a(i, obj);
    }

    protected final void mo62a(int i) {
        this.f384a.m307d(i);
    }

    protected final void mo63a(Object obj, Object obj2) {
        this.f384a.put(obj, obj2);
    }

    protected final int mo64b(Object obj) {
        return this.f384a.m304b(obj);
    }

    protected final Map mo65b() {
        return this.f384a;
    }

    protected final void mo66c() {
        this.f384a.clear();
    }
}
