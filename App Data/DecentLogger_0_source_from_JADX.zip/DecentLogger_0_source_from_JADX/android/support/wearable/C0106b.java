package android.support.wearable;

public final class C0106b {
    public static final int CardText = 2131558400;
    public static final int CardTextBase = 2131558401;
    public static final int CardTitle = 2131558402;
    public static final int CardTitleBase = 2131558403;
    public static final int ConfirmationActivity = 2131558428;
    public static final int DismissOverlayText = 2131558404;
    public static final int DotsPageIndicatorStyle = 2131558405;
    public static final int PageIndicatorViewStyle = 2131558406;
    public static final int TextAppearance_WearDiag = 2131558418;
    public static final int TextAppearance_WearDiag_Button = 2131558419;
    public static final int TextAppearance_WearDiag_Message = 2131558420;
    public static final int TextAppearance_WearDiag_Title = 2131558421;
    public static final int TextAppearance_Wearable_Large = 2131558407;
    public static final int TextAppearance_Wearable_Medium = 2131558408;
    public static final int TextAppearance_Wearable_Small = 2131558409;
    public static final int TextView_Large = 2131558410;
    public static final int TextView_Large_Light = 2131558411;
    public static final int TextView_Medium = 2131558412;
    public static final int TextView_Medium_Light = 2131558413;
    public static final int TextView_Small = 2131558414;
    public static final int TextView_Small_Light = 2131558415;
    public static final int Theme_WearDiag = 2131558422;
    public static final int Theme_Wearable = 2131558416;
    public static final int Theme_Wearable_Modal = 2131558417;
    public static final int WearableActionDrawerItemText = 2131558430;
    public static final int WearableProgressSpinner = 2131558431;
    public static final int WearableProgressSpinnerFullScreenText = 2131558434;
    public static final int WearableProgressSpinner_FullScreen = 2131558432;
    public static final int WearableProgressSpinner_Inline = 2131558433;
    public static final int Widget_ActionPage = 2131558423;
    public static final int Widget_WearDiag_Button = 2131558424;
    public static final int Widget_WearDiag_TextView = 2131558425;
    public static final int Widget_WearDiag_TextView_Message = 2131558426;
    public static final int Widget_WearDiag_TextView_Title = 2131558427;
}
