package android.support.wearable.view;

import android.graphics.Outline;
import android.view.View;
import android.view.ViewOutlineProvider;

final class C0111d extends ViewOutlineProvider {
    final /* synthetic */ C0110c f559a;

    private C0111d(C0110c c0110c) {
        this.f559a = c0110c;
    }

    public final void getOutline(View view, Outline outline) {
        outline.setOval(0, 0, this.f559a.f557h, this.f559a.f557h);
    }
}
