package android.support.wearable.view;

import android.animation.Animator;
import android.animation.ObjectAnimator;
import android.animation.StateListAnimator;
import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.RippleDrawable;
import android.graphics.drawable.ShapeDrawable;
import android.graphics.drawable.shapes.OvalShape;
import android.support.wearable.C0107c;
import android.util.TypedValue;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.MeasureSpec;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.Interpolator;

@SuppressLint({"ClickableViewAccessibility"})
@TargetApi(21)
public final class C0110c extends View {
    private static final double f550a = Math.sqrt(2.0d);
    private int f551b;
    private ShapeDrawable f552c;
    private RippleDrawable f553d;
    private Interpolator f554e;
    private ColorStateList f555f;
    private Drawable f556g;
    private int f557h;
    private int f558i;

    public C0110c(Context context) {
        this(context, (byte) 0);
    }

    private C0110c(Context context, byte b) {
        this(context, '\u0000');
    }

    private C0110c(Context context, char c) {
        this(context, (short) 0);
    }

    private C0110c(Context context, short s) {
        int i = 0;
        super(context, null, 0, 0);
        this.f551b = -1;
        this.f552c = new ShapeDrawable(new OvalShape());
        this.f552c.getPaint().setColor(-3355444);
        super.setBackgroundDrawable(this.f552c);
        setOutlineProvider(new C0111d());
        this.f554e = new AccelerateInterpolator(2.0f);
        this.f558i = 0;
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(null, C0107c.CircularButton, 0, 0);
        while (i < obtainStyledAttributes.getIndexCount()) {
            int index = obtainStyledAttributes.getIndex(i);
            if (index == C0107c.CircularButton_android_color) {
                this.f555f = obtainStyledAttributes.getColorStateList(index);
                this.f552c.getPaint().setColor(this.f555f.getDefaultColor());
            } else if (index == C0107c.CircularButton_android_src) {
                this.f556g = obtainStyledAttributes.getDrawable(index);
            } else if (index == C0107c.CircularButton_buttonRippleColor) {
                setRippleColor(obtainStyledAttributes.getColor(index, -1));
            } else if (index == C0107c.CircularButton_pressedButtonTranslationZ) {
                setPressedTranslationZ(obtainStyledAttributes.getDimension(index, 0.0f));
            } else if (index == C0107c.CircularButton_imageScaleMode) {
                this.f558i = obtainStyledAttributes.getInt(index, this.f558i);
            }
            i++;
        }
        obtainStyledAttributes.recycle();
        setClickable(true);
    }

    private Animator m710a(Animator animator) {
        animator.setInterpolator(this.f554e);
        return animator;
    }

    private static boolean m711a(Drawable drawable) {
        return drawable != null && drawable.getIntrinsicHeight() > 0 && drawable.getIntrinsicWidth() > 0;
    }

    protected final void drawableStateChanged() {
        super.drawableStateChanged();
        if (this.f555f != null && this.f555f.isStateful()) {
            this.f552c.getPaint().setColor(this.f555f.getColorForState(getDrawableState(), this.f555f.getDefaultColor()));
            this.f552c.invalidateSelf();
        }
    }

    public final Drawable getImageDrawable() {
        return this.f556g;
    }

    public final int getImageScaleMode() {
        return this.f558i;
    }

    protected final void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (this.f556g != null) {
            this.f556g.draw(canvas);
        }
    }

    protected final void onLayout(boolean z, int i, int i2, int i3, int i4) {
        super.onLayout(z, i, i2, i3, i4);
        int i5 = i3 - i;
        int i6 = i4 - i2;
        if (this.f556g != null) {
            int intrinsicWidth = this.f556g.getIntrinsicWidth();
            int intrinsicHeight = this.f556g.getIntrinsicHeight();
            if (this.f558i == 0 || !C0110c.m711a(this.f556g)) {
                int floor = (int) Math.floor(((double) (this.f557h / 2)) * f550a);
                i5 = (this.f557h - floor) / 2;
                if (C0110c.m711a(this.f556g)) {
                    if (intrinsicWidth == intrinsicHeight) {
                        i6 = floor;
                        intrinsicWidth = i5;
                    } else {
                        float f = ((float) intrinsicWidth) / ((float) intrinsicHeight);
                        if (intrinsicWidth > intrinsicHeight) {
                            i6 = (int) (((float) floor) / f);
                            intrinsicWidth = (int) (((float) (floor - i6)) / 2.0f);
                        } else {
                            intrinsicWidth = (int) (f * ((float) floor));
                            int i7 = (int) (((float) (floor - intrinsicWidth)) / 2.0f);
                            i6 = floor;
                            floor = intrinsicWidth;
                            intrinsicWidth = i5;
                            i5 = i7;
                        }
                    }
                    this.f556g.setBounds(i5, intrinsicWidth, floor + i5, i6 + intrinsicWidth);
                    return;
                }
                this.f556g.setBounds(i5, i5, i5 + floor, floor + i5);
                return;
            }
            i5 = (int) (((float) (i5 - intrinsicWidth)) / 2.0f);
            i6 = (int) (((float) (i6 - intrinsicHeight)) / 2.0f);
            this.f556g.setBounds(i5, i6, intrinsicWidth + i5, intrinsicHeight + i6);
        }
    }

    protected final void onMeasure(int i, int i2) {
        int mode = MeasureSpec.getMode(i);
        int size = MeasureSpec.getSize(i);
        int mode2 = MeasureSpec.getMode(i2);
        int size2 = MeasureSpec.getSize(i2);
        if (mode == 1073741824 && mode2 == 1073741824) {
            this.f557h = Math.min(size, size2);
        } else if (mode == 1073741824) {
            this.f557h = size;
        } else if (mode2 == 1073741824) {
            this.f557h = size2;
        } else {
            int max = C0110c.m711a(this.f556g) ? Math.max(this.f556g.getIntrinsicHeight(), this.f556g.getIntrinsicWidth()) : (int) Math.ceil((double) TypedValue.applyDimension(1, 48.0f, getResources().getDisplayMetrics()));
            if (mode == Integer.MIN_VALUE || mode2 == Integer.MIN_VALUE) {
                if (mode == Integer.MIN_VALUE) {
                    size2 = mode2 == Integer.MIN_VALUE ? Math.min(size, size2) : size;
                }
                this.f557h = Math.min(size2, ((int) Math.floor(((double) max) / f550a)) * 2);
            } else {
                this.f557h = max;
            }
        }
        setMeasuredDimension(this.f557h, this.f557h);
    }

    public final boolean onTouchEvent(MotionEvent motionEvent) {
        boolean onTouchEvent = super.onTouchEvent(motionEvent);
        if (onTouchEvent) {
            switch (motionEvent.getAction() & 255) {
                case 0:
                    getBackground().setHotspot(motionEvent.getX(), motionEvent.getY());
                    break;
            }
        }
        return onTouchEvent;
    }

    public final void setBackgroundDrawable(Drawable drawable) {
    }

    public final void setColor(int i) {
        this.f555f = ColorStateList.valueOf(i);
        this.f552c.getPaint().setColor(this.f555f.getDefaultColor());
    }

    public final void setColor(ColorStateList colorStateList) {
        this.f555f = colorStateList;
        this.f552c.getPaint().setColor(this.f555f.getDefaultColor());
    }

    public final void setImageDrawable(Drawable drawable) {
        if (this.f556g != null) {
            this.f556g.setCallback(null);
        }
        if (this.f556g != drawable) {
            this.f556g = drawable;
            requestLayout();
            invalidate();
        }
        if (this.f556g != null) {
            this.f556g.setCallback(this);
        }
    }

    public final void setImageResource(int i) {
        setImageDrawable(getResources().getDrawable(i, null));
    }

    public final void setImageScaleMode(int i) {
        this.f558i = i;
        if (this.f556g != null) {
            invalidate();
            requestLayout();
        }
    }

    public final void setPressedTranslationZ(float f) {
        StateListAnimator stateListAnimator = new StateListAnimator();
        stateListAnimator.addState(PRESSED_ENABLED_STATE_SET, m710a(ObjectAnimator.ofFloat(this, "translationZ", new float[]{f})));
        stateListAnimator.addState(ENABLED_FOCUSED_STATE_SET, m710a(ObjectAnimator.ofFloat(this, "translationZ", new float[]{f})));
        stateListAnimator.addState(EMPTY_STATE_SET, m710a(ObjectAnimator.ofFloat(this, "translationZ", new float[]{getElevation()})));
        setStateListAnimator(stateListAnimator);
    }

    public final void setRippleColor(int i) {
        this.f551b = i;
        if (this.f553d != null) {
            this.f553d.setColor(ColorStateList.valueOf(i));
        } else if (this.f551b == -1 || isInEditMode()) {
            this.f553d = null;
            super.setBackgroundDrawable(this.f552c);
        } else {
            this.f553d = new RippleDrawable(ColorStateList.valueOf(i), this.f552c, this.f552c);
            super.setBackgroundDrawable(this.f553d);
        }
    }

    protected final boolean verifyDrawable(Drawable drawable) {
        return this.f556g == drawable || super.verifyDrawable(drawable);
    }
}
