package android.support.wearable.view;

import android.annotation.TargetApi;
import android.content.Context;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build.VERSION;
import android.support.wearable.C0107c;
import android.util.AttributeSet;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup.LayoutParams;
import android.view.WindowInsets;
import android.widget.FrameLayout;

@TargetApi(20)
public class BoxInsetLayout extends FrameLayout {
    private static float f528a = 0.146467f;
    private Rect f529b;
    private boolean f530c;
    private Rect f531d;

    public BoxInsetLayout(Context context) {
        this(context, null);
    }

    public BoxInsetLayout(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public BoxInsetLayout(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        if (this.f529b == null) {
            this.f529b = new Rect();
        }
        if (this.f531d == null) {
            this.f531d = new Rect();
        }
    }

    private C0109b m704a(AttributeSet attributeSet) {
        return new C0109b(getContext(), attributeSet);
    }

    protected boolean checkLayoutParams(LayoutParams layoutParams) {
        return layoutParams instanceof C0109b;
    }

    public /* synthetic */ LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return m704a(attributeSet);
    }

    protected LayoutParams generateLayoutParams(LayoutParams layoutParams) {
        return new C0109b(layoutParams);
    }

    public /* synthetic */ FrameLayout.LayoutParams m1161generateLayoutParams(AttributeSet attributeSet) {
        return m704a(attributeSet);
    }

    public Rect getInsets() {
        return this.f531d;
    }

    public WindowInsets onApplyWindowInsets(WindowInsets windowInsets) {
        WindowInsets onApplyWindowInsets = super.onApplyWindowInsets(windowInsets);
        if (VERSION.SDK_INT < 23) {
            boolean isRound = onApplyWindowInsets.isRound();
            if (isRound != this.f530c) {
                this.f530c = isRound;
                requestLayout();
            }
            this.f531d.set(onApplyWindowInsets.getSystemWindowInsetLeft(), onApplyWindowInsets.getSystemWindowInsetTop(), onApplyWindowInsets.getSystemWindowInsetRight(), onApplyWindowInsets.getSystemWindowInsetBottom());
        }
        return onApplyWindowInsets;
    }

    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        if (VERSION.SDK_INT < 23) {
            requestApplyInsets();
            return;
        }
        this.f530c = getResources().getConfiguration().isScreenRound();
        WindowInsets rootWindowInsets = getRootWindowInsets();
        this.f531d.set(rootWindowInsets.getSystemWindowInsetLeft(), rootWindowInsets.getSystemWindowInsetTop(), rootWindowInsets.getSystemWindowInsetRight(), rootWindowInsets.getSystemWindowInsetBottom());
    }

    protected void onLayout(boolean z, int i, int i2, int i3, int i4) {
        int childCount = getChildCount();
        int paddingLeft = getPaddingLeft() + this.f529b.left;
        int paddingRight = ((i3 - i) - getPaddingRight()) - this.f529b.right;
        int paddingTop = getPaddingTop() + this.f529b.top;
        int paddingBottom = ((i4 - i2) - getPaddingBottom()) - this.f529b.bottom;
        for (int i5 = 0; i5 < childCount; i5++) {
            View childAt = getChildAt(i5);
            if (childAt.getVisibility() != 8) {
                int i6;
                C0109b c0109b = (C0109b) childAt.getLayoutParams();
                int measuredWidth = childAt.getMeasuredWidth();
                int measuredHeight = childAt.getMeasuredHeight();
                int i7 = c0109b.gravity;
                if (i7 == -1) {
                    i7 = 8388659;
                }
                int absoluteGravity = Gravity.getAbsoluteGravity(i7, getLayoutDirection());
                int i8 = i7 & 112;
                if (c0109b.width != -1) {
                    switch (absoluteGravity & 7) {
                        case 1:
                            i7 = (((((paddingRight - paddingLeft) - measuredWidth) / 2) + paddingLeft) + c0109b.leftMargin) - c0109b.rightMargin;
                            break;
                        case 5:
                            i7 = (paddingRight - measuredWidth) - c0109b.rightMargin;
                            break;
                    }
                }
                i7 = c0109b.leftMargin + paddingLeft;
                if (c0109b.height != -1) {
                    switch (i8) {
                        case C0107c.ActionPage_buttonRippleColor /*16*/:
                            i6 = (((((paddingBottom - paddingTop) - measuredHeight) / 2) + paddingTop) + c0109b.topMargin) - c0109b.bottomMargin;
                            break;
                        case 80:
                            i6 = (paddingBottom - measuredHeight) - c0109b.bottomMargin;
                            break;
                    }
                }
                i6 = c0109b.topMargin + paddingTop;
                childAt.layout(i7, i6, measuredWidth + i7, measuredHeight + i6);
            }
        }
    }

    protected void onMeasure(int i, int i2) {
        int i3;
        int i4;
        int combineMeasuredStates;
        int i5;
        int childCount = getChildCount();
        int i6 = 0;
        int i7 = 0;
        int i8 = 0;
        int i9 = 0;
        while (i9 < childCount) {
            C0109b c0109b;
            int i10;
            int i11;
            int i12;
            int i13;
            View childAt = getChildAt(i9);
            if (childAt.getVisibility() != 8) {
                int i14;
                c0109b = (C0109b) childAt.getLayoutParams();
                i10 = 0;
                i11 = 0;
                i3 = 0;
                if (this.f530c) {
                    if ((c0109b.f549a & 1) == 0) {
                        i10 = c0109b.leftMargin;
                    }
                    if ((c0109b.f549a & 4) == 0) {
                        i11 = c0109b.rightMargin;
                    }
                    if ((c0109b.f549a & 2) == 0) {
                        i3 = c0109b.topMargin;
                    }
                    if ((c0109b.f549a & 8) == 0) {
                        i4 = c0109b.bottomMargin;
                        i14 = i3;
                        i12 = i11;
                        i13 = i10;
                    } else {
                        i4 = 0;
                        i14 = i3;
                        i12 = i11;
                        i13 = i10;
                    }
                } else {
                    i10 = c0109b.leftMargin;
                    i3 = c0109b.topMargin;
                    i11 = c0109b.rightMargin;
                    i4 = c0109b.bottomMargin;
                    i14 = i3;
                    i12 = i11;
                    i13 = i10;
                }
                measureChildWithMargins(childAt, i, 0, i2, 0);
                i11 = Math.max(i6, (childAt.getMeasuredWidth() + i13) + i12);
                i10 = Math.max(i7, (childAt.getMeasuredHeight() + i14) + i4);
                combineMeasuredStates = combineMeasuredStates(i8, childAt.getMeasuredState());
                i5 = i10;
                i10 = i11;
            } else {
                combineMeasuredStates = i8;
                i5 = i7;
                i10 = i6;
            }
            i9++;
            i8 = combineMeasuredStates;
            i7 = i5;
            i6 = i10;
        }
        i5 = i6 + (((getPaddingLeft() + this.f529b.left) + getPaddingRight()) + this.f529b.right);
        combineMeasuredStates = Math.max((((getPaddingTop() + this.f529b.top) + getPaddingBottom()) + this.f529b.bottom) + i7, getSuggestedMinimumHeight());
        i5 = Math.max(i5, getSuggestedMinimumWidth());
        Drawable foreground = getForeground();
        if (foreground != null) {
            combineMeasuredStates = Math.max(combineMeasuredStates, foreground.getMinimumHeight());
            i5 = Math.max(i5, foreground.getMinimumWidth());
        }
        setMeasuredDimension(resolveSizeAndState(i5, i, i8), resolveSizeAndState(combineMeasuredStates, i2, i8 << 16));
        i4 = (int) (f528a * ((float) Math.max(getMeasuredWidth(), getMeasuredHeight())));
        for (int i15 = 0; i15 < childCount; i15++) {
            View childAt2 = getChildAt(i15);
            c0109b = (C0109b) childAt2.getLayoutParams();
            i5 = c0109b.gravity;
            if (i5 == -1) {
                i5 = 8388659;
            }
            i12 = i5 & 112;
            i13 = i5 & 7;
            i8 = (c0109b.leftMargin + getPaddingLeft()) + this.f529b.left;
            i7 = (c0109b.rightMargin + getPaddingRight()) + this.f529b.right;
            i6 = (c0109b.topMargin + getPaddingTop()) + this.f529b.top;
            i9 = (c0109b.bottomMargin + getPaddingBottom()) + this.f529b.bottom;
            i5 = childAt2.getPaddingLeft();
            i10 = childAt2.getPaddingRight();
            i3 = childAt2.getPaddingBottom();
            i11 = childAt2.getPaddingTop();
            if (this.f530c && (c0109b.f549a & 1) != 0 && (c0109b.width == -1 || i13 == 3)) {
                i5 = Math.max(Math.max(0, i4 - i8), i5);
            }
            i8 += 0;
            if (this.f530c && (c0109b.f549a & 4) != 0 && (c0109b.width == -1 || i13 == 5)) {
                i10 = Math.max(Math.max(0, i4 - i7), i10);
            }
            i13 = getChildMeasureSpec(i, i8 + i7, c0109b.width);
            if (this.f530c && (c0109b.f549a & 2) != 0 && (c0109b.height == -1 || i12 == 48)) {
                i11 = Math.max(Math.max(0, i4 - i6), i11);
            }
            i8 = i6 + 0;
            if (this.f530c && (c0109b.f549a & 8) != 0 && (c0109b.height == -1 || i12 == 80)) {
                i3 = Math.max(Math.max(0, i4 - i9), i3);
            }
            combineMeasuredStates = getChildMeasureSpec(i2, i8 + i9, c0109b.height);
            childAt2.setPadding(i5, i11, i10, i3);
            childAt2.measure(i13, combineMeasuredStates);
        }
    }

    public void setForeground(Drawable drawable) {
        super.setForeground(drawable);
        if (this.f529b == null) {
            this.f529b = new Rect();
        }
        drawable.getPadding(this.f529b);
    }
}
