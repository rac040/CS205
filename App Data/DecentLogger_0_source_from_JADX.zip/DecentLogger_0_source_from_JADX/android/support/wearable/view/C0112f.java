package android.support.wearable.view;

import android.animation.Animator;
import android.animation.Animator.AnimatorListener;
import android.annotation.TargetApi;

@TargetApi(20)
public class C0112f implements AnimatorListener {
    private boolean f581a;

    public void mo171a() {
    }

    public void onAnimationCancel(Animator animator) {
        this.f581a = true;
    }

    public void onAnimationEnd(Animator animator) {
        if (!this.f581a) {
            mo171a();
        }
    }

    public void onAnimationRepeat(Animator animator) {
    }

    public void onAnimationStart(Animator animator) {
        this.f581a = false;
    }
}
