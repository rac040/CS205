package android.support.wearable.view;

import android.content.Context;
import android.content.res.TypedArray;
import android.support.wearable.C0107c;
import android.util.AttributeSet;
import android.view.ViewGroup;
import android.widget.FrameLayout.LayoutParams;

public final class C0109b extends LayoutParams {
    public int f549a = 0;

    public C0109b(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, C0107c.BoxInsetLayout_Layout, 0, 0);
        this.f549a = obtainStyledAttributes.getInt(C0107c.BoxInsetLayout_Layout_layout_box, 0);
        obtainStyledAttributes.recycle();
    }

    public C0109b(ViewGroup.LayoutParams layoutParams) {
        super(layoutParams);
    }
}
