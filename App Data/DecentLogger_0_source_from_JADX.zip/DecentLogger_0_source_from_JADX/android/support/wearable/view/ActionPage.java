package android.support.wearable.view;

import android.animation.AnimatorInflater;
import android.animation.StateListAnimator;
import android.annotation.TargetApi;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.Point;
import android.graphics.drawable.Drawable;
import android.support.wearable.C0106b;
import android.support.wearable.C0107c;
import android.util.AttributeSet;
import android.view.View.MeasureSpec;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.WindowInsets;

@TargetApi(21)
public class ActionPage extends ViewGroup {
    public static int f516a = 1;
    public static int f517b = 0;
    private final C0108a f518c;
    private C0110c f519d;
    private int f520e;
    private float f521f;
    private final Point f522g;
    private int f523h;
    private int f524i;
    private boolean f525j;
    private int f526k;
    private boolean f527l;

    public ActionPage(Context context) {
        this(context, null);
    }

    public ActionPage(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public ActionPage(Context context, AttributeSet attributeSet, int i) {
        this(context, attributeSet, i, C0106b.Widget_ActionPage);
    }

    public ActionPage(Context context, AttributeSet attributeSet, int i, int i2) {
        super(context, attributeSet, i, i2);
        this.f522g = new Point();
        this.f519d = new C0110c(context);
        this.f518c = new C0108a(context);
        this.f518c.setGravity(17);
        this.f518c.setMaxLines(2);
        float f = 1.0f;
        float f2 = 0.0f;
        String str = null;
        int i3 = 1;
        int i4 = 0;
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, C0107c.ActionPage, i, i2);
        for (int i5 = 0; i5 < obtainStyledAttributes.getIndexCount(); i5++) {
            int index = obtainStyledAttributes.getIndex(i5);
            if (index == C0107c.ActionPage_android_color) {
                this.f519d.setColor(obtainStyledAttributes.getColorStateList(index));
            } else if (index == C0107c.ActionPage_android_src) {
                this.f519d.setImageDrawable(obtainStyledAttributes.getDrawable(index));
            } else if (index == C0107c.ActionPage_imageScaleMode) {
                this.f519d.setImageScaleMode(obtainStyledAttributes.getInt(index, 0));
            } else if (index == C0107c.ActionPage_buttonRippleColor) {
                this.f519d.setRippleColor(obtainStyledAttributes.getColor(index, -1));
            } else if (index == C0107c.ActionPage_pressedButtonTranslationZ) {
                this.f519d.setPressedTranslationZ(obtainStyledAttributes.getDimension(index, 0.0f));
            } else if (index == C0107c.ActionPage_android_text) {
                this.f518c.setText(obtainStyledAttributes.getText(index));
            } else if (index == C0107c.ActionPage_minTextSize) {
                this.f518c.m706a(0, obtainStyledAttributes.getDimension(index, 10.0f));
            } else if (index == C0107c.ActionPage_maxTextSize) {
                this.f518c.m708b(0, obtainStyledAttributes.getDimension(index, 60.0f));
            } else if (index == C0107c.ActionPage_android_textColor) {
                this.f518c.setTextColor(obtainStyledAttributes.getColorStateList(index));
            } else if (index == C0107c.ActionPage_android_maxLines) {
                this.f518c.setMaxLines(obtainStyledAttributes.getInt(index, 2));
            } else if (index == C0107c.ActionPage_android_fontFamily) {
                str = obtainStyledAttributes.getString(index);
            } else if (index == C0107c.ActionPage_android_typeface) {
                i3 = obtainStyledAttributes.getInt(index, i3);
            } else if (index == C0107c.ActionPage_android_textStyle) {
                i4 = obtainStyledAttributes.getInt(index, i4);
            } else if (index == C0107c.ActionPage_android_gravity) {
                this.f518c.setGravity(obtainStyledAttributes.getInt(index, 17));
            } else if (index == C0107c.ActionPage_android_lineSpacingExtra) {
                f2 = obtainStyledAttributes.getDimension(index, f2);
            } else if (index == C0107c.ActionPage_android_lineSpacingMultiplier) {
                f = obtainStyledAttributes.getDimension(index, f);
            } else if (index == C0107c.ActionPage_android_stateListAnimator) {
                this.f519d.setStateListAnimator(AnimatorInflater.loadStateListAnimator(context, obtainStyledAttributes.getResourceId(index, 0)));
            }
        }
        obtainStyledAttributes.recycle();
        C0108a c0108a = this.f518c;
        if (!(c0108a.f535c == f2 && c0108a.f534b == f)) {
            c0108a.f535c = f2;
            c0108a.f534b = f;
            if (c0108a.f533a != null) {
                c0108a.f533a = null;
                c0108a.requestLayout();
                c0108a.invalidate();
            }
        }
        this.f518c.m707a(str, i3, i4);
        addView(this.f518c);
        addView(this.f519d);
    }

    public C0110c getButton() {
        return this.f519d;
    }

    public C0108a getLabel() {
        return this.f518c;
    }

    public WindowInsets onApplyWindowInsets(WindowInsets windowInsets) {
        this.f527l = true;
        if (this.f525j != windowInsets.isRound()) {
            this.f525j = windowInsets.isRound();
            requestLayout();
        }
        int systemWindowInsetBottom = windowInsets.getSystemWindowInsetBottom();
        if (this.f526k != systemWindowInsetBottom) {
            this.f526k = systemWindowInsetBottom;
            requestLayout();
        }
        if (this.f525j) {
            this.f526k = (int) Math.max((float) this.f526k, 0.09375f * ((float) getMeasuredHeight()));
        }
        return windowInsets;
    }

    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        if (!this.f527l) {
            requestApplyInsets();
        }
    }

    protected void onLayout(boolean z, int i, int i2, int i3, int i4) {
        int i5 = i3 - i;
        this.f519d.layout((int) (((float) this.f522g.x) - this.f521f), (int) (((float) this.f522g.y) - this.f521f), (int) (((float) this.f522g.x) + this.f521f), (int) (((float) this.f522g.y) + this.f521f));
        i5 = (int) (((float) (i5 - this.f523h)) / 2.0f);
        this.f518c.layout(i5, this.f519d.getBottom(), this.f523h + i5, this.f519d.getBottom() + this.f524i);
    }

    protected void onMeasure(int i, int i2) {
        super.onMeasure(i, i2);
        int measuredHeight = getMeasuredHeight();
        int measuredWidth = getMeasuredWidth();
        if (this.f519d.getImageScaleMode() != 1 || this.f519d.getImageDrawable() == null) {
            this.f520e = (int) (((float) Math.min(measuredWidth, measuredHeight)) * 0.45f);
            this.f521f = ((float) this.f520e) / 2.0f;
            this.f519d.measure(MeasureSpec.makeMeasureSpec(this.f520e, 1073741824), MeasureSpec.makeMeasureSpec(this.f520e, 1073741824));
        } else {
            this.f519d.measure(0, 0);
            this.f520e = Math.min(this.f519d.getMeasuredWidth(), this.f519d.getMeasuredHeight());
            this.f521f = ((float) this.f520e) / 2.0f;
        }
        if (this.f525j) {
            this.f522g.set(measuredWidth / 2, measuredHeight / 2);
            this.f523h = (int) (((float) measuredWidth) * 0.625f);
            this.f526k = (int) (((float) measuredHeight) * 0.09375f);
        } else {
            this.f522g.set(measuredWidth / 2, (int) (((float) measuredHeight) * 0.43f));
            this.f523h = (int) (((float) measuredWidth) * 0.892f);
        }
        this.f524i = (int) ((((float) measuredHeight) - (((float) this.f522g.y) + this.f521f)) - ((float) this.f526k));
        this.f518c.measure(MeasureSpec.makeMeasureSpec(this.f523h, 1073741824), MeasureSpec.makeMeasureSpec(this.f524i, 1073741824));
    }

    public void setColor(int i) {
        this.f519d.setColor(i);
    }

    public void setColor(ColorStateList colorStateList) {
        this.f519d.setColor(colorStateList);
    }

    public void setEnabled(boolean z) {
        super.setEnabled(z);
        if (this.f519d != null) {
            this.f519d.setEnabled(z);
        }
    }

    public void setImageDrawable(Drawable drawable) {
        this.f519d.setImageDrawable(drawable);
    }

    public void setImageResource(int i) {
        this.f519d.setImageResource(i);
    }

    public void setImageScaleMode(int i) {
        this.f519d.setImageScaleMode(i);
    }

    public void setOnClickListener(OnClickListener onClickListener) {
        if (this.f519d != null) {
            this.f519d.setOnClickListener(onClickListener);
        }
    }

    public void setStateListAnimator(StateListAnimator stateListAnimator) {
        if (this.f519d != null) {
            this.f519d.setStateListAnimator(stateListAnimator);
        }
    }

    public void setText(CharSequence charSequence) {
        this.f518c.setText(charSequence);
    }
}
