package android.support.wearable.view.drawer;

import android.annotation.TargetApi;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Paint.Style;
import android.graphics.RadialGradient;
import android.graphics.Shader.TileMode;
import android.support.v4.view.bn;
import android.support.wearable.C0106b;
import android.support.wearable.C0107c;
import android.util.AttributeSet;
import android.view.View;
import android.view.View.MeasureSpec;

@TargetApi(20)
class PageIndicatorView extends View implements bn {
    private int f560a;
    private float f561b;
    private float f562c;
    private int f563d;
    private int f564e;
    private boolean f565f;
    private int f566g;
    private int f567h;
    private int f568i;
    private float f569j;
    private float f570k;
    private float f571l;
    private int f572m;
    private int f573n;
    private int f574o;
    private int f575p;
    private final Paint f576q;
    private final Paint f577r;
    private final Paint f578s;
    private final Paint f579t;
    private boolean f580u;

    public PageIndicatorView(Context context) {
        this(context, null);
    }

    public PageIndicatorView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public PageIndicatorView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        TypedArray obtainStyledAttributes = getContext().obtainStyledAttributes(attributeSet, C0107c.PageIndicatorView, i, C0106b.PageIndicatorViewStyle);
        this.f560a = obtainStyledAttributes.getDimensionPixelOffset(C0107c.PageIndicatorView_pageIndicatorDotSpacing, 0);
        this.f561b = obtainStyledAttributes.getDimension(C0107c.PageIndicatorView_pageIndicatorDotRadius, 0.0f);
        this.f562c = obtainStyledAttributes.getDimension(C0107c.PageIndicatorView_pageIndicatorDotRadiusSelected, 0.0f);
        this.f563d = obtainStyledAttributes.getColor(C0107c.PageIndicatorView_pageIndicatorDotColor, 0);
        this.f564e = obtainStyledAttributes.getColor(C0107c.PageIndicatorView_pageIndicatorDotColorSelected, 0);
        this.f566g = obtainStyledAttributes.getInt(C0107c.PageIndicatorView_pageIndicatorDotFadeOutDelay, 0);
        this.f567h = obtainStyledAttributes.getInt(C0107c.PageIndicatorView_pageIndicatorDotFadeOutDuration, 0);
        this.f568i = obtainStyledAttributes.getInt(C0107c.PageIndicatorView_pageIndicatorDotFadeInDuration, 0);
        this.f565f = obtainStyledAttributes.getBoolean(C0107c.PageIndicatorView_pageIndicatorDotFadeWhenIdle, false);
        this.f569j = obtainStyledAttributes.getDimension(C0107c.PageIndicatorView_pageIndicatorDotShadowDx, 0.0f);
        this.f570k = obtainStyledAttributes.getDimension(C0107c.PageIndicatorView_pageIndicatorDotShadowDy, 0.0f);
        this.f571l = obtainStyledAttributes.getDimension(C0107c.PageIndicatorView_pageIndicatorDotShadowRadius, 0.0f);
        this.f572m = obtainStyledAttributes.getColor(C0107c.PageIndicatorView_pageIndicatorDotShadowColor, 0);
        obtainStyledAttributes.recycle();
        this.f576q = new Paint(1);
        this.f576q.setColor(this.f563d);
        this.f576q.setStyle(Style.FILL);
        this.f578s = new Paint(1);
        this.f578s.setColor(this.f564e);
        this.f578s.setStyle(Style.FILL);
        this.f577r = new Paint(1);
        this.f579t = new Paint(1);
        this.f575p = 0;
        if (isInEditMode()) {
            this.f573n = 5;
            this.f574o = 2;
            this.f565f = false;
        }
        if (this.f565f) {
            this.f580u = false;
            animate().alpha(0.0f).setStartDelay(2000).setDuration((long) this.f567h).start();
        } else {
            animate().cancel();
            setAlpha(1.0f);
        }
        m713a(this.f576q, this.f577r, this.f561b, this.f571l, this.f563d, this.f572m);
        m713a(this.f578s, this.f579t, this.f562c, this.f571l, this.f564e, this.f572m);
    }

    private void m712a(long j) {
        this.f580u = false;
        animate().cancel();
        animate().alpha(0.0f).setStartDelay(j).setDuration((long) this.f567h).start();
    }

    private static void m713a(Paint paint, Paint paint2, float f, float f2, int i, int i2) {
        float f3 = f + f2;
        float f4 = f / f3;
        float[] fArr = new float[]{0.0f, f4, 1.0f};
        f4 = 0.0f;
        paint2.setShader(new RadialGradient(0.0f, f4, f3, new int[]{i2, i2, 0}, fArr, TileMode.CLAMP));
        paint.setColor(i);
        paint.setStyle(Style.FILL);
    }

    public final void mo168a(float f) {
        if (!this.f565f || this.f575p != 1) {
            return;
        }
        if (f != 0.0f) {
            if (!this.f580u) {
                this.f580u = true;
                animate().cancel();
                animate().alpha(1.0f).setStartDelay(0).setDuration((long) this.f568i).start();
            }
        } else if (this.f580u) {
            m712a(0);
        }
    }

    public final void mo169a(int i) {
        if (i != this.f574o) {
            this.f574o = i;
            invalidate();
        }
    }

    public final void mo170b(int i) {
        if (this.f575p != i) {
            this.f575p = i;
            if (!this.f565f || i != 0) {
                return;
            }
            if (this.f580u) {
                m712a((long) this.f566g);
                return;
            }
            this.f580u = true;
            animate().cancel();
            animate().alpha(1.0f).setStartDelay(0).setDuration((long) this.f568i).setListener(new C0113a(this)).start();
        }
    }

    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (this.f573n > 1) {
            float paddingLeft = ((float) getPaddingLeft()) + (((float) this.f560a) / 2.0f);
            float height = ((float) getHeight()) / 2.0f;
            canvas.save();
            canvas.translate(paddingLeft, height);
            for (int i = 0; i < this.f573n; i++) {
                if (i == this.f574o) {
                    canvas.drawCircle(this.f569j, this.f570k, this.f562c + this.f571l, this.f579t);
                    canvas.drawCircle(0.0f, 0.0f, this.f562c, this.f578s);
                } else {
                    canvas.drawCircle(this.f569j, this.f570k, this.f561b + this.f571l, this.f577r);
                    canvas.drawCircle(0.0f, 0.0f, this.f561b, this.f576q);
                }
                canvas.translate((float) this.f560a, 0.0f);
            }
            canvas.restore();
        }
    }

    protected void onMeasure(int i, int i2) {
        setMeasuredDimension(resolveSizeAndState(MeasureSpec.getMode(i) == 1073741824 ? MeasureSpec.getSize(i) : ((this.f573n * this.f560a) + getPaddingLeft()) + getPaddingRight(), i, 0), resolveSizeAndState(MeasureSpec.getMode(i2) == 1073741824 ? MeasureSpec.getSize(i2) : (((int) (((float) ((int) Math.ceil((double) (Math.max(this.f561b + this.f571l, this.f562c + this.f571l) * 2.0f)))) + this.f570k)) + getPaddingTop()) + getPaddingBottom(), i2, 0));
    }
}
