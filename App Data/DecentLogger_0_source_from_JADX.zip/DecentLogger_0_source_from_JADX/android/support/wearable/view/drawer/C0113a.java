package android.support.wearable.view.drawer;

import android.support.wearable.view.C0112f;

final class C0113a extends C0112f {
    final /* synthetic */ PageIndicatorView f582a;

    C0113a(PageIndicatorView pageIndicatorView) {
        this.f582a = pageIndicatorView;
    }

    public final void mo171a() {
        this.f582a.f580u = false;
        this.f582a.animate().alpha(0.0f).setListener(null).setStartDelay((long) this.f582a.f566g).setDuration((long) this.f582a.f567h).start();
    }
}
