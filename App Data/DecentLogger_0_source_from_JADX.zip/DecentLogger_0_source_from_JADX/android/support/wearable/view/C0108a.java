package android.support.wearable.view;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Typeface;
import android.support.wearable.C0107c;
import android.text.Layout;
import android.text.Layout.Alignment;
import android.text.TextPaint;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.View;
import java.util.Objects;

@TargetApi(21)
public final class C0108a extends View {
    Layout f533a;
    float f534b;
    float f535c;
    private TextPaint f536d;
    private float f537e;
    private float f538f;
    private int f539g;
    private ColorStateList f540h;
    private int f541i;
    private CharSequence f542j;
    private float f543k;
    private float f544l;
    private float f545m;
    private float f546n;
    private int f547o;
    private int f548p;

    public C0108a(Context context) {
        this(context, (byte) 0);
    }

    private C0108a(Context context, byte b) {
        this(context, '\u0000');
    }

    private C0108a(Context context, char c) {
        this(context, (short) 0);
    }

    private C0108a(Context context, short s) {
        super(context, null, 0, 0);
        this.f539g = 8388659;
        this.f534b = 1.0f;
        this.f535c = 0.0f;
        this.f547o = Integer.MAX_VALUE;
        DisplayMetrics displayMetrics = getResources().getDisplayMetrics();
        float f = displayMetrics.density;
        float f2 = displayMetrics.scaledDensity;
        this.f545m = f2 / f;
        this.f543k = 10.0f * f2;
        this.f544l = f2 * 60.0f;
        this.f536d = new TextPaint(1);
        TypedArray obtainStyledAttributes = context.getTheme().obtainStyledAttributes(null, C0107c.ActionLabel, 0, 0);
        this.f542j = obtainStyledAttributes.getText(C0107c.ActionLabel_android_text);
        this.f543k = obtainStyledAttributes.getDimension(C0107c.ActionLabel_minTextSize, this.f543k);
        this.f544l = obtainStyledAttributes.getDimension(C0107c.ActionLabel_maxTextSize, this.f544l);
        this.f540h = obtainStyledAttributes.getColorStateList(C0107c.ActionLabel_android_textColor);
        this.f547o = obtainStyledAttributes.getInt(C0107c.ActionLabel_android_maxLines, 2);
        if (this.f540h != null) {
            m705a();
        }
        this.f536d.setTextSize(this.f544l);
        m707a(obtainStyledAttributes.getString(C0107c.ActionLabel_android_fontFamily), obtainStyledAttributes.getInt(C0107c.ActionLabel_android_typeface, -1), obtainStyledAttributes.getInt(C0107c.ActionLabel_android_textStyle, -1));
        this.f539g = obtainStyledAttributes.getInt(C0107c.ActionLabel_android_gravity, this.f539g);
        this.f538f = (float) obtainStyledAttributes.getDimensionPixelSize(C0107c.ActionLabel_android_lineSpacingExtra, (int) this.f538f);
        this.f537e = obtainStyledAttributes.getFloat(C0107c.ActionLabel_android_lineSpacingMultiplier, this.f537e);
        obtainStyledAttributes.recycle();
        if (this.f542j == null) {
            this.f542j = "";
        }
    }

    private void m705a() {
        int colorForState = this.f540h.getColorForState(getDrawableState(), 0);
        if (colorForState != this.f541i) {
            this.f541i = colorForState;
            invalidate();
        }
    }

    private int getAvailableHeight() {
        return getHeight() - (getPaddingTop() + getPaddingBottom());
    }

    @SuppressLint({"RtlHardcoded"})
    private Alignment getLayoutAlignment() {
        switch (getTextAlignment()) {
            case 1:
                switch (this.f539g & 8388615) {
                    case 1:
                        return Alignment.ALIGN_CENTER;
                    case 3:
                        return Alignment.ALIGN_NORMAL;
                    case 5:
                        return Alignment.ALIGN_OPPOSITE;
                    case 8388611:
                        return Alignment.ALIGN_NORMAL;
                    case 8388613:
                        return Alignment.ALIGN_OPPOSITE;
                    default:
                        return Alignment.ALIGN_NORMAL;
                }
            case 2:
                return Alignment.ALIGN_NORMAL;
            case 3:
                return Alignment.ALIGN_OPPOSITE;
            case 4:
                return Alignment.ALIGN_CENTER;
            default:
                return Alignment.ALIGN_NORMAL;
        }
    }

    public final void m706a(int i, float f) {
        float applyDimension = TypedValue.applyDimension(i, f, getContext().getResources().getDisplayMetrics());
        if (applyDimension != this.f543k) {
            this.f533a = null;
            this.f543k = applyDimension;
            requestLayout();
            invalidate();
        }
    }

    final void m707a(String str, int i, int i2) {
        boolean z = false;
        Typeface typeface = null;
        if (str != null) {
            typeface = Typeface.create(str, i2);
            if (typeface != null) {
                setTypeface(typeface);
                return;
            }
        }
        switch (i) {
            case 1:
                typeface = Typeface.SANS_SERIF;
                break;
            case 2:
                typeface = Typeface.SERIF;
                break;
            case 3:
                typeface = Typeface.MONOSPACE;
                break;
        }
        if (i2 > 0) {
            typeface = typeface == null ? Typeface.defaultFromStyle(i2) : Typeface.create(typeface, i2);
            setTypeface(typeface);
            int style = ((typeface != null ? typeface.getStyle() : 0) ^ -1) & i2;
            TextPaint textPaint = this.f536d;
            if ((style & 1) != 0) {
                z = true;
            }
            textPaint.setFakeBoldText(z);
            this.f536d.setTextSkewX((style & 2) != 0 ? -0.25f : 0.0f);
            return;
        }
        this.f536d.setFakeBoldText(false);
        this.f536d.setTextSkewX(0.0f);
        setTypeface(typeface);
    }

    public final void m708b(int i, float f) {
        float applyDimension = TypedValue.applyDimension(i, f, getContext().getResources().getDisplayMetrics());
        if (applyDimension != this.f544l) {
            this.f533a = null;
            this.f544l = applyDimension;
            requestLayout();
            invalidate();
        }
    }

    protected final void drawableStateChanged() {
        super.drawableStateChanged();
        if (this.f540h != null && this.f540h.isStateful()) {
            m705a();
        }
    }

    public final int getCurrentTextColor() {
        return this.f541i;
    }

    public final int getGravity() {
        return this.f539g;
    }

    public final float getLineSpacingExtra() {
        return this.f535c;
    }

    public final float getLineSpacingMultiplier() {
        return this.f534b;
    }

    public final int getMaxLines() {
        return this.f547o;
    }

    public final ColorStateList getTextColors() {
        return this.f540h;
    }

    public final Typeface getTypeface() {
        return this.f536d.getTypeface();
    }

    final int getVerticalOffset() {
        int availableHeight = getAvailableHeight();
        int lineTop = this.f533a.getLineTop(this.f548p);
        switch (this.f539g & 112) {
            case C0107c.ActionPage_buttonRippleColor /*16*/:
                return (availableHeight - lineTop) / 2;
            case 80:
                return availableHeight - lineTop;
            default:
                return 0;
        }
    }

    protected final void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (this.f533a != null) {
            canvas.save();
            this.f536d.setColor(this.f541i);
            this.f536d.drawableState = getDrawableState();
            canvas.translate((float) getPaddingLeft(), (float) (getPaddingTop() + getVerticalOffset()));
            canvas.clipRect(0, 0, getWidth() - getPaddingRight(), this.f533a.getLineTop(this.f548p));
            this.f533a.draw(canvas);
            canvas.restore();
        }
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    protected final void onMeasure(int r15, int r16) {
        /*
        r14 = this;
        r3 = android.view.View.MeasureSpec.getMode(r15);
        r11 = android.view.View.MeasureSpec.getMode(r16);
        r2 = android.view.View.MeasureSpec.getSize(r15);
        r9 = android.view.View.MeasureSpec.getSize(r16);
        r0 = -1;
        r1 = -1;
        r4 = 1073741824; // 0x40000000 float:2.0 double:5.304989477E-315;
        if (r3 != r4) goto L_0x0017;
    L_0x0016:
        r0 = r2;
    L_0x0017:
        r4 = 1073741824; // 0x40000000 float:2.0 double:5.304989477E-315;
        if (r11 != r4) goto L_0x001c;
    L_0x001b:
        r1 = r9;
    L_0x001c:
        r4 = -1;
        if (r0 != r4) goto L_0x003b;
    L_0x001f:
        r0 = r14.f536d;
        r4 = r14.f544l;
        r0.setTextSize(r4);
        r0 = r14.f542j;
        r4 = r14.f536d;
        r0 = android.text.Layout.getDesiredWidth(r0, r4);
        r4 = (double) r0;
        r4 = java.lang.Math.ceil(r4);
        r0 = (int) r4;
        r4 = r14.f536d;
        r5 = r14.f546n;
        r4.setTextSize(r5);
    L_0x003b:
        r4 = -2147483648; // 0xffffffff80000000 float:-0.0 double:NaN;
        if (r3 != r4) goto L_0x015b;
    L_0x003f:
        r0 = java.lang.Math.min(r0, r2);
        r8 = r0;
    L_0x0044:
        r4 = r14.getLayoutAlignment();
        r0 = -1;
        if (r1 != r0) goto L_0x0158;
    L_0x004b:
        r0 = -2147483648; // 0xffffffff80000000 float:-0.0 double:NaN;
        if (r11 != r0) goto L_0x007c;
    L_0x004f:
        r0 = r9;
    L_0x0050:
        r10 = r0;
    L_0x0051:
        r0 = r14.f533a;
        if (r0 == 0) goto L_0x006b;
    L_0x0055:
        r0 = r14.f533a;
        r0 = r0.getWidth();
        if (r0 == r8) goto L_0x0080;
    L_0x005d:
        r0 = 1;
    L_0x005e:
        r1 = r14.f533a;
        r1 = r1.getHeight();
        if (r1 == r10) goto L_0x0082;
    L_0x0066:
        r1 = 1;
    L_0x0067:
        if (r0 != 0) goto L_0x006b;
    L_0x0069:
        if (r1 == 0) goto L_0x0072;
    L_0x006b:
        if (r10 <= 0) goto L_0x006f;
    L_0x006d:
        if (r8 > 0) goto L_0x0084;
    L_0x006f:
        r0 = 0;
    L_0x0070:
        r14.f533a = r0;
    L_0x0072:
        r0 = r14.f533a;
        if (r0 != 0) goto L_0x0139;
    L_0x0076:
        r0 = 0;
        r1 = 0;
        r14.setMeasuredDimension(r0, r1);
    L_0x007b:
        return;
    L_0x007c:
        r0 = 2147483647; // 0x7fffffff float:NaN double:1.060997895E-314;
        goto L_0x0050;
    L_0x0080:
        r0 = 0;
        goto L_0x005e;
    L_0x0082:
        r1 = 0;
        goto L_0x0067;
    L_0x0084:
        r0 = r14.getPaddingTop();
        r1 = r14.getPaddingBottom();
        r0 = r0 + r1;
        r12 = r10 - r0;
        r0 = r14.getPaddingLeft();
        r1 = r14.getPaddingRight();
        r0 = r0 + r1;
        r3 = r8 - r0;
        r0 = r14.f544l;
        r14.f546n = r0;
        r0 = r14.f536d;
        r1 = r14.f544l;
        r0.setTextSize(r1);
        r0 = new android.text.StaticLayout;
        r1 = r14.f542j;
        r2 = r14.f536d;
        r5 = r14.f534b;
        r6 = r14.f535c;
        r7 = 1;
        r0.<init>(r1, r2, r3, r4, r5, r6, r7);
        r1 = r0.getLineCount();
        r2 = r14.f547o;
        if (r1 <= r2) goto L_0x011f;
    L_0x00bb:
        r1 = 1;
    L_0x00bc:
        r2 = r0.getLineCount();
        r2 = r0.getLineTop(r2);
        if (r2 <= r12) goto L_0x0121;
    L_0x00c6:
        r2 = 1;
    L_0x00c7:
        r5 = r14.f536d;
        r5 = r5.getTextSize();
        r6 = r14.f543k;
        r5 = (r5 > r6 ? 1 : (r5 == r6 ? 0 : -1));
        if (r5 <= 0) goto L_0x0123;
    L_0x00d3:
        r5 = 1;
    L_0x00d4:
        if (r1 != 0) goto L_0x00d8;
    L_0x00d6:
        if (r2 == 0) goto L_0x012b;
    L_0x00d8:
        if (r1 != 0) goto L_0x00dc;
    L_0x00da:
        if (r2 == 0) goto L_0x012b;
    L_0x00dc:
        if (r5 == 0) goto L_0x012b;
    L_0x00de:
        r0 = r14.f546n;
        r1 = 1065353216; // 0x3f800000 float:1.0 double:5.263544247E-315;
        r0 = r0 - r1;
        r14.f546n = r0;
        r0 = r14.f536d;
        r1 = r14.f546n;
        r0.setTextSize(r1);
        r0 = new android.text.StaticLayout;
        r1 = r14.f542j;
        r2 = r14.f536d;
        r5 = r14.f534b;
        r6 = r14.f535c;
        r7 = 1;
        r0.<init>(r1, r2, r3, r4, r5, r6, r7);
        r1 = r0.getLineCount();
        r1 = r0.getLineTop(r1);
        if (r1 <= r12) goto L_0x0125;
    L_0x0104:
        r1 = 1;
    L_0x0105:
        r2 = r0.getLineCount();
        r5 = r14.f547o;
        if (r2 <= r5) goto L_0x0127;
    L_0x010d:
        r2 = 1;
    L_0x010e:
        r5 = r14.f536d;
        r5 = r5.getTextSize();
        r6 = r14.f543k;
        r5 = (r5 > r6 ? 1 : (r5 == r6 ? 0 : -1));
        if (r5 <= 0) goto L_0x0129;
    L_0x011a:
        r5 = 1;
    L_0x011b:
        r13 = r1;
        r1 = r2;
        r2 = r13;
        goto L_0x00d8;
    L_0x011f:
        r1 = 0;
        goto L_0x00bc;
    L_0x0121:
        r2 = 0;
        goto L_0x00c7;
    L_0x0123:
        r5 = 0;
        goto L_0x00d4;
    L_0x0125:
        r1 = 0;
        goto L_0x0105;
    L_0x0127:
        r2 = 0;
        goto L_0x010e;
    L_0x0129:
        r5 = 0;
        goto L_0x011b;
    L_0x012b:
        r1 = r14.f547o;
        r2 = r0.getLineCount();
        r1 = java.lang.Math.min(r1, r2);
        r14.f548p = r1;
        goto L_0x0070;
    L_0x0139:
        r0 = 1073741824; // 0x40000000 float:2.0 double:5.304989477E-315;
        if (r11 == r0) goto L_0x0156;
    L_0x013d:
        r0 = r14.f533a;
        r1 = r14.f533a;
        r1 = r1.getLineCount();
        r0 = r0.getLineTop(r1);
    L_0x0149:
        r1 = -2147483648; // 0xffffffff80000000 float:-0.0 double:NaN;
        if (r11 != r1) goto L_0x0151;
    L_0x014d:
        r0 = java.lang.Math.min(r0, r9);
    L_0x0151:
        r14.setMeasuredDimension(r8, r0);
        goto L_0x007b;
    L_0x0156:
        r0 = r10;
        goto L_0x0149;
    L_0x0158:
        r10 = r1;
        goto L_0x0051;
    L_0x015b:
        r8 = r0;
        goto L_0x0044;
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.wearable.view.a.onMeasure(int, int):void");
    }

    public final void onRtlPropertiesChanged(int i) {
        super.onRtlPropertiesChanged(i);
        this.f533a = null;
        requestLayout();
        invalidate();
    }

    public final void setGravity(int i) {
        if (this.f539g != i) {
            this.f539g = i;
            invalidate();
        }
    }

    public final void setMaxLines(int i) {
        if (this.f547o != i) {
            this.f547o = i;
            this.f533a = null;
            requestLayout();
            invalidate();
        }
    }

    public final void setMaxTextSize(float f) {
        m708b(2, f);
    }

    public final void setMinTextSize(float f) {
        m706a(2, f);
    }

    public final void setText(CharSequence charSequence) {
        if (charSequence == null) {
            throw new RuntimeException("Can not set ActionLabel text to null");
        } else if (!Objects.equals(this.f542j, charSequence)) {
            this.f533a = null;
            this.f542j = charSequence;
            requestLayout();
            invalidate();
        }
    }

    public final void setTextColor(int i) {
        this.f540h = ColorStateList.valueOf(i);
        m705a();
    }

    public final void setTextColor(ColorStateList colorStateList) {
        if (colorStateList == null) {
            throw new NullPointerException();
        }
        this.f540h = colorStateList;
        m705a();
    }

    public final void setTypeface(Typeface typeface) {
        if (this.f536d.getTypeface() != typeface) {
            this.f536d.setTypeface(typeface);
            if (this.f533a != null) {
                requestLayout();
                invalidate();
            }
        }
    }
}
